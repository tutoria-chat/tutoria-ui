<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Library callbacks for quiz_tutoria.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Legacy footer callback for Moodle 4.2–4.3: adds the floating assistant panel to
 * Moodle's manual grading pages. On 4.4+ db/hooks.php replaces it and core skips this.
 *
 * @return string
 */
function quiz_tutoria_before_footer() {
    return \quiz_tutoria\local\panel::render_for_page();
}
