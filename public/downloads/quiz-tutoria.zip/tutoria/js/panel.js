// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Floating assistant panel on Moodle's own manual grading pages.
 *
 * Moodle renders one grading block per attempt and question, with form fields
 * named q{usageid}:{slot}_-comment and q{usageid}:{slot}_-mark. The panel reads the
 * saved AI drafts for this quiz (ajax.php?action=drafts), shows the one for each
 * block on the page, and on request FILLS those fields: the comment always, the
 * mark only in score mode (corporate training) and only when the teacher clicks.
 * Nothing is saved until the teacher clicks Moodle's own Save button.
 *
 * Plain (non-AMD) JavaScript: no build step.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
(function () {
    'use strict';

    var POLL_INTERVAL_MS = 4000;
    var POLL_MAX_MS = 10 * 60 * 1000;
    var STATE_KEY = 'quiz_tutoria_panel';
    // From this width up the panel docks as a sidebar and pushes Moodle's page left,
    // so it never covers the comment editor or Moodle's Save button.
    var DOCK_MIN_WIDTH = 992;
    var FIELD_RE = /^q(\d+):(\d+)_-mark$/;

    var root, cfg, STR, panel, launcher, statusEl, listEl, toolsEl, noticeEl, generateBtn, criteriaEl, dockBtn;
    var docked = true;
    var data = {mode: 'feedback', items: [], job: null};
    var byKey = {};
    var blocks = [];
    var polling = false;

    // ---- helpers --------------------------------------------------------------

    function fmt(tpl, a) {
        if (typeof tpl !== 'string') {
            return '';
        }
        if (a === undefined) {
            return tpl;
        }
        if (typeof a === 'object') {
            return tpl.replace(/\{\$a->([a-zA-Z0-9_]+)\}/g, function (m, k) {
                return a[k] !== undefined ? a[k] : m;
            });
        }
        return tpl.replace(/\{\$a\}/g, a);
    }

    function el(tag, cls, text) {
        var e = document.createElement(tag);
        if (cls) {
            e.className = cls;
        }
        if (text !== undefined && text !== null) {
            e.textContent = text;
        }
        return e;
    }

    function escapeHtml(s) {
        return String(s === null || s === undefined ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function loadState() {
        try {
            return JSON.parse(window.localStorage.getItem(STATE_KEY) || '{}') || {};
        } catch (e) {
            return {};
        }
    }

    function saveState(patch) {
        try {
            var s = loadState();
            Object.keys(patch).forEach(function (k) {
                s[k] = patch[k];
            });
            window.localStorage.setItem(STATE_KEY, JSON.stringify(s));
        } catch (e) {
            // Storage blocked: the panel just forgets its position.
        }
    }

    function setStatus(text, level) {
        statusEl.className = 'quiz-tutoria-panel-status alert alert-' + (level || 'info');
        statusEl.textContent = text;
        statusEl.hidden = !text;
    }

    function call(action, params) {
        var body = new URLSearchParams();
        body.set('action', action);
        body.set('cmid', cfg.cmid);
        body.set('sesskey', cfg.sesskey);
        Object.keys(params || {}).forEach(function (k) {
            body.set(k, params[k]);
        });
        return fetch(cfg.ajaxurl, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: body.toString()
        }).then(function (resp) {
            return resp.text().then(function (text) {
                var json;
                try {
                    json = text ? JSON.parse(text) : {};
                } catch (e) {
                    throw new Error(STR.js_error);
                }
                if (!resp.ok) {
                    throw new Error(json.message || STR.js_error);
                }
                return json;
            });
        });
    }

    // ---- Moodle's grading form ------------------------------------------------

    /**
     * Every grading block on the page: one per attempt (usage) and question slot.
     * @returns {Array<Object>}
     */
    function scanBlocks() {
        var out = [];
        document.querySelectorAll('input[name$="_-mark"]').forEach(function (input) {
            var m = FIELD_RE.exec(input.name);
            if (!m) {
                return;
            }
            var prefix = 'q' + m[1] + ':' + m[2] + '_';
            var form = input.form || document;
            out.push({
                key: m[1] + '|' + m[2],
                uniqueid: parseInt(m[1], 10),
                slot: parseInt(m[2], 10),
                mark: input,
                comment: form.querySelector('[name="' + prefix + '-comment"]'),
                format: form.querySelector('[name="' + prefix + '-commentformat"]'),
                block: document.getElementById('question-' + m[1] + '-' + m[2]) || input.closest('.que') || input
            });
        });
        return out;
    }

    function tinyFor(textarea) {
        var tiny = window.tinymce || window.tinyMCE;
        if (!textarea || !textarea.id || !tiny || typeof tiny.get !== 'function') {
            return null;
        }
        return tiny.get(textarea.id) || null;
    }

    /** Current comment text (HTML or plain), whatever editor the site uses. */
    function getComment(b) {
        if (!b.comment) {
            return '';
        }
        var ed = tinyFor(b.comment);
        if (ed) {
            return ed.getContent() || '';
        }
        var atto = document.getElementById(b.comment.id + 'editable');
        if (atto) {
            return atto.innerHTML || '';
        }
        return b.comment.value || '';
    }

    function isBlank(html) {
        var d = document.createElement('div');
        d.innerHTML = html || '';
        return !(d.textContent || '').trim();
    }

    /**
     * Put text into Moodle's comment field. TinyMCE (4.3+ default), Atto, or a
     * plain textarea; plain-text formats get plain text.
     * @returns {boolean} whether a field was found.
     */
    function setComment(b, text) {
        if (!b.comment) {
            return false;
        }
        var paragraphs = String(text || '').split(/\n{2,}/).map(function (p) {
            return '<p>' + escapeHtml(p).replace(/\n/g, '<br>') + '</p>';
        }).join('');

        var ed = tinyFor(b.comment);
        if (ed) {
            ed.setContent(paragraphs);
            if (typeof ed.save === 'function') {
                ed.save();
            }
            // TinyMCE 7+ uses dispatch(); fire() is the older name.
            if (typeof ed.dispatch === 'function') {
                ed.dispatch('change');
            } else if (typeof ed.fire === 'function') {
                ed.fire('change');
            }
            return true;
        }
        var atto = document.getElementById(b.comment.id + 'editable');
        if (atto) {
            atto.innerHTML = paragraphs;
            b.comment.value = paragraphs;
            atto.dispatchEvent(new Event('input', {bubbles: true}));
            b.comment.dispatchEvent(new Event('change', {bubbles: true}));
            return true;
        }
        // Plain textarea: HTML only when the format is HTML (1).
        var html = !b.format || b.format.value === '1';
        b.comment.value = html ? paragraphs : String(text || '');
        b.comment.dispatchEvent(new Event('input', {bubbles: true}));
        b.comment.dispatchEvent(new Event('change', {bubbles: true}));
        return true;
    }

    function setMark(b, value) {
        b.mark.value = String(value);
        b.mark.dispatchEvent(new Event('input', {bubbles: true}));
        b.mark.dispatchEvent(new Event('change', {bubbles: true}));
    }

    function flash(b) {
        var target = b.block;
        var top = target.getBoundingClientRect().top + window.pageYOffset - 80;
        window.scrollTo({top: Math.max(0, top), behavior: 'smooth'});
        target.classList.add('quiz-tutoria-flash');
        setTimeout(function () {
            target.classList.remove('quiz-tutoria-flash');
        }, 1600);
    }

    /** The comment text to insert: feedback, plus the criteria in score mode. */
    function commentText(item) {
        var text = item.feedback || '';
        if (item.mode === 'score' && item.rationale) {
            text += '\n\n' + STR.criteria_rationale_label + ' ' + item.rationale;
        }
        return text;
    }

    function needsReview(item) {
        return (item.review && item.review.length) || item.suggestedmark === null || item.confidence !== 'alta';
    }

    // ---- rendering ------------------------------------------------------------

    function badge(text, cls) {
        return el('span', 'badge quiz-tutoria-badge ' + (cls || 'badge-secondary bg-secondary'), text);
    }

    function renderCard(b) {
        var item = byKey[b.key];
        var card = el('div', 'quiz-tutoria-card');

        var head = el('button', 'btn btn-link p-0 quiz-tutoria-card-title');
        head.type = 'button';
        head.textContent = (item ? item.name + ' — ' : '') + fmt(STR.panel_question, b.slot);
        head.title = STR.panel_goto;
        head.addEventListener('click', function () {
            flash(b);
        });
        card.appendChild(head);

        if (!item) {
            card.appendChild(el('div', 'text-muted small', STR.panel_nodraft_attempt));
            return card;
        }

        if (item.mode === 'score') {
            var line = el('div', 'quiz-tutoria-suggest');
            if (item.suggestedmark !== null) {
                line.appendChild(el('strong', '', fmt(STR.panel_suggested,
                    {mark: item.suggestedmark, max: item.maxmark})));
            }
            var conf = STR['conf_' + item.confidence];
            if (conf) {
                line.appendChild(badge(fmt(STR.panel_confidence, conf),
                    item.confidence === 'alta' ? 'badge-success bg-success' :
                        (item.confidence === 'media' ? 'badge-warning bg-warning text-dark' : 'badge-danger bg-danger')));
            }
            card.appendChild(line);
            if (item.review && item.review.length) {
                var reasons = el('div', 'quiz-tutoria-reasons');
                item.review.forEach(function (r) {
                    reasons.appendChild(badge(STR['review_' + r] || r, 'badge-warning bg-warning text-dark'));
                });
                card.appendChild(reasons);
            }
            if (item.rationale) {
                var det = el('details', 'quiz-tutoria-rationale');
                det.appendChild(el('summary', '', STR.panel_rationale));
                det.appendChild(el('div', 'small', item.rationale));
                card.appendChild(det);
            }
        }

        card.appendChild(el('div', 'quiz-tutoria-feedback', item.feedback || '—'));

        var actions = el('div', 'quiz-tutoria-card-actions');
        var msg = el('div', 'small text-success quiz-tutoria-card-msg');

        var ins = el('button', 'btn btn-sm btn-primary', STR.panel_insert);
        ins.type = 'button';
        ins.disabled = !b.comment;
        ins.title = b.comment ? '' : STR.panel_noeditor;
        ins.addEventListener('click', function () {
            if (!isBlank(getComment(b)) && !window.confirm(STR.panel_replacecomment)) {
                return;
            }
            if (setComment(b, commentText(item))) {
                msg.textContent = STR.panel_inserted;
                flash(b);
            }
        });
        actions.appendChild(ins);

        if (item.mode === 'score' && item.suggestedmark !== null) {
            var use = el('button', 'btn btn-sm btn-outline-primary', STR.panel_usemark);
            use.type = 'button';
            use.addEventListener('click', function () {
                setMark(b, item.suggestedmark);
                msg.textContent = STR.panel_markused;
                flash(b);
            });
            actions.appendChild(use);
        }
        card.appendChild(actions);
        card.appendChild(msg);
        return card;
    }

    function render() {
        byKey = {};
        (data.items || []).forEach(function (it) {
            byKey[it.uniqueid + '|' + it.slot] = it;
        });
        blocks = scanBlocks();

        noticeEl.textContent = data.mode === 'score' ? STR.panel_notice_score : STR.panel_notice_feedback;
        noticeEl.className = 'quiz-tutoria-panel-notice alert ' + (data.mode === 'score' ? 'alert-warning' : 'alert-info');

        var onpage = blocks.filter(function (b) {
            return !!byKey[b.key];
        }).length;
        generateBtn.textContent = (data.items && data.items.length) ? STR.panel_regenerate : STR.panel_generate;

        toolsEl.innerHTML = '';
        listEl.innerHTML = '';

        if (data.needsinstitutionkey) {
            listEl.appendChild(el('div', 'alert alert-warning small', STR.panel_needskey));
        }
        if (!data.items || !data.items.length) {
            listEl.appendChild(el('div', 'text-muted small', STR.panel_nodrafts));
            return;
        }
        toolsEl.appendChild(el('div', 'small text-muted', fmt(STR.panel_onpage, {n: onpage, total: blocks.length})));

        var insAll = el('button', 'btn btn-sm btn-secondary', STR.panel_insertall);
        insAll.type = 'button';
        insAll.addEventListener('click', function () {
            var n = 0;
            var skipped = 0;
            blocks.forEach(function (b) {
                var it = byKey[b.key];
                if (!it || !b.comment) {
                    return;
                }
                if (!isBlank(getComment(b))) {
                    skipped++;
                    return;
                }
                if (setComment(b, commentText(it))) {
                    n++;
                }
            });
            setStatus(fmt(STR.panel_insertedn, {n: n, skipped: skipped}) + ' ' + STR.panel_savehint, 'success');
        });
        toolsEl.appendChild(insAll);

        if (data.mode === 'score') {
            var fill = el('button', 'btn btn-sm btn-secondary', STR.panel_fillmarks);
            fill.type = 'button';
            fill.title = STR.panel_reviewonly;
            fill.addEventListener('click', function () {
                var n = 0;
                blocks.forEach(function (b) {
                    var it = byKey[b.key];
                    if (!it || needsReview(it) || String(b.mark.value || '').trim() !== '') {
                        return;
                    }
                    setMark(b, it.suggestedmark);
                    n++;
                });
                setStatus(fmt(STR.panel_filledn, n) + ' ' + STR.panel_savehint, 'success');
            });
            toolsEl.appendChild(fill);
        }

        if (!blocks.length) {
            listEl.appendChild(el('div', 'text-muted small', STR.panel_noeditor));
            return;
        }
        blocks.forEach(function (b) {
            listEl.appendChild(renderCard(b));
        });
    }

    // ---- data flow ------------------------------------------------------------

    function load() {
        return call('drafts', {}).then(function (d) {
            data = d;
            render();
            if (d.job && d.job.status === 'running' && !polling) {
                poll(d.job.jobid);
            }
        }).catch(function (err) {
            setStatus(err.message || STR.js_error, 'danger');
        });
    }

    function poll(jobid) {
        polling = true;
        generateBtn.disabled = true;
        setStatus(STR.panel_running, 'info');
        var deadline = Date.now() + POLL_MAX_MS;
        function tick() {
            return call('poll', {jobid: jobid}).then(function (r) {
                if (r.done) {
                    return true;
                }
                if (Date.now() > deadline) {
                    throw new Error(STR.js_error);
                }
                setStatus(r.total ? fmt(STR.js_gradingn, {processed: r.processed, total: r.total}) : STR.js_grading, 'info');
                return new Promise(function (resolve) {
                    setTimeout(resolve, POLL_INTERVAL_MS);
                }).then(tick);
            });
        }
        return tick().then(function () {
            setStatus('', 'info');
            return load();
        }).catch(function (err) {
            setStatus(err.message || STR.js_error, 'danger');
        }).then(function () {
            polling = false;
            generateBtn.disabled = false;
        });
    }

    function generate() {
        generateBtn.disabled = true;
        setStatus(STR.js_starting, 'info');
        call('start', {criteria: criteriaEl.value || ''}).then(function (r) {
            return poll(r.jobid);
        }).catch(function (err) {
            setStatus(err.message || STR.js_error, 'danger');
            generateBtn.disabled = false;
        });
    }

    // ---- the floating window --------------------------------------------------

    function open(show) {
        panel.hidden = !show;
        launcher.hidden = show;
        saveState({open: show});
        applyDock();
        if (show) {
            render();
        }
    }

    /** Docked sidebar on wide screens (page pushed left); floating window otherwise. */
    function applyDock() {
        var wide = window.innerWidth >= DOCK_MIN_WIDTH;
        var isDocked = docked && wide && !panel.hidden;
        panel.classList.toggle('is-docked', isDocked);
        document.documentElement.classList.toggle('quiz-tutoria-docked', isDocked);
        if (dockBtn) {
            dockBtn.hidden = !wide;
            dockBtn.textContent = docked ? '↗' : '⇥';
            dockBtn.title = docked ? STR.panel_undock : STR.panel_dock;
            dockBtn.setAttribute('aria-label', dockBtn.title);
        }
        if (isDocked || !wide) {
            panel.style.left = panel.style.top = panel.style.right = panel.style.bottom = '';
            return;
        }
        var st = loadState();
        if (st.left !== undefined && st.top !== undefined) {
            placePanel(st.left, st.top);
        }
    }

    function setDocked(value) {
        docked = value;
        saveState({docked: value});
        applyDock();
    }

    function placePanel(left, top) {
        var w = panel.offsetWidth || 380;
        var h = panel.offsetHeight || 300;
        left = Math.min(Math.max(8, left), Math.max(8, window.innerWidth - w - 8));
        top = Math.min(Math.max(8, top), Math.max(8, window.innerHeight - Math.min(h, 120)));
        panel.style.left = left + 'px';
        panel.style.top = top + 'px';
        panel.style.right = 'auto';
        panel.style.bottom = 'auto';
    }

    function enableDrag(handle) {
        var startX, startY, startL, startT, dragging = false;
        handle.addEventListener('pointerdown', function (e) {
            if (e.target.closest('button') || window.innerWidth < 576) {
                return;
            }
            var r = panel.getBoundingClientRect();
            if (docked) {
                // Pulling the docked panel turns it into a floating window.
                docked = false;
                saveState({docked: false});
                applyDock();
                placePanel(r.left, r.top);
            }
            dragging = true;
            startX = e.clientX;
            startY = e.clientY;
            startL = r.left;
            startT = r.top;
            handle.setPointerCapture(e.pointerId);
        });
        handle.addEventListener('pointermove', function (e) {
            if (dragging) {
                placePanel(startL + e.clientX - startX, startT + e.clientY - startY);
            }
        });
        handle.addEventListener('pointerup', function () {
            if (!dragging) {
                return;
            }
            dragging = false;
            var r = panel.getBoundingClientRect();
            saveState({left: Math.round(r.left), top: Math.round(r.top)});
        });
    }

    function build() {
        launcher = el('button', 'btn btn-primary quiz-tutoria-launcher', STR.panel_open);
        launcher.type = 'button';
        launcher.setAttribute('aria-controls', 'quiz-tutoria-panel');
        launcher.addEventListener('click', function () {
            open(true);
        });

        panel = el('section', 'quiz-tutoria-panel');
        panel.id = 'quiz-tutoria-panel';
        panel.setAttribute('role', 'complementary');
        panel.setAttribute('aria-label', STR.panel_title);

        var header = el('div', 'quiz-tutoria-panel-header');
        header.appendChild(el('strong', '', STR.panel_title));
        var headerBtns = el('div', 'quiz-tutoria-panel-headbtns');
        dockBtn = el('button', 'btn btn-sm btn-link quiz-tutoria-panel-close', '');
        dockBtn.type = 'button';
        dockBtn.addEventListener('click', function () {
            setDocked(!docked);
        });
        headerBtns.appendChild(dockBtn);
        var close = el('button', 'btn btn-sm btn-link quiz-tutoria-panel-close', '✕');
        close.type = 'button';
        close.setAttribute('aria-label', STR.panel_minimize);
        close.title = STR.panel_minimize;
        close.addEventListener('click', function () {
            open(false);
        });
        headerBtns.appendChild(close);
        header.appendChild(headerBtns);
        panel.appendChild(header);

        var body = el('div', 'quiz-tutoria-panel-body');
        noticeEl = el('div', 'quiz-tutoria-panel-notice alert alert-info');
        noticeEl.setAttribute('role', 'note');
        body.appendChild(noticeEl);

        var gen = el('details', 'quiz-tutoria-panel-generate');
        gen.appendChild(el('summary', '', STR.panel_criteria));
        criteriaEl = el('textarea', 'form-control form-control-sm');
        criteriaEl.rows = 3;
        criteriaEl.value = cfg.defaultcriteria || '';
        gen.appendChild(criteriaEl);
        body.appendChild(gen);

        generateBtn = el('button', 'btn btn-sm btn-primary quiz-tutoria-generate', STR.panel_generate);
        generateBtn.type = 'button';
        generateBtn.addEventListener('click', generate);
        body.appendChild(generateBtn);

        statusEl = el('div', 'quiz-tutoria-panel-status alert');
        statusEl.setAttribute('role', 'status');
        statusEl.hidden = true;
        body.appendChild(statusEl);

        toolsEl = el('div', 'quiz-tutoria-panel-tools');
        body.appendChild(toolsEl);
        listEl = el('div', 'quiz-tutoria-panel-list');
        body.appendChild(listEl);
        body.appendChild(el('div', 'small text-muted quiz-tutoria-panel-foot', STR.panel_savehint));
        panel.appendChild(body);

        enableDrag(header);
        document.body.appendChild(launcher);
        document.body.appendChild(panel);

        var state = loadState();
        docked = state.docked !== false;
        // Open by default the first time; afterwards remember the teacher's choice.
        open(state.open !== false);
        window.addEventListener('resize', applyDock);
    }

    function boot() {
        root = document.getElementById('quiz-tutoria-panel-root');
        if (!root || document.getElementById('quiz-tutoria-panel')) {
            return;
        }
        cfg = {
            cmid: root.getAttribute('data-cmid'),
            sesskey: root.getAttribute('data-sesskey'),
            ajaxurl: root.getAttribute('data-ajaxurl'),
            defaultcriteria: root.getAttribute('data-defaultcriteria') || ''
        };
        STR = JSON.parse(root.getAttribute('data-strings') || '{}');
        build();
        load();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
}());
