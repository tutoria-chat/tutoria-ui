// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Client for the Tutoria AI grading report.
 *
 * Plain (non-AMD) JavaScript loaded via $PAGE->requires->js(), so the plugin
 * needs no build step and works exactly as shipped. Flow: collect the essay
 * answers, start a Tutoria job, poll it, then show an editable table of the
 * AI's feedback drafts; the teacher reads each answer, types the grade and
 * applies.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
(function () {
    'use strict';

    var POLL_INTERVAL_MS = 4000;
    var POLL_MAX_MS = 10 * 60 * 1000;
    var HELP_STATE_KEY = 'quiz_tutoria_help';

    // Declared here, assigned in boot() once the DOM is ready — so the script is
    // correct whether it is loaded in the page footer or (defensively) the head.
    var root, cfg, STR, gradeBtn, applyBtn, statusEl, resultsEl, criteriaEl;

    // Holds the collected map: key "email|slot" and "matricula|slot" -> question row.
    var index = {};
    // The rows currently shown for review.
    var rows = [];

    // ---- small helpers ------------------------------------------------------

    /**
     * Format a string with {$a} or {$a->key} placeholders, Moodle style.
     * @param {string} tpl
     * @param {(Object|string|number)} a
     * @returns {string}
     */
    function fmt(tpl, a) {
        if (typeof tpl !== 'string') {
            return '';
        }
        if (a === undefined) {
            return tpl;
        }
        if (typeof a === 'object') {
            return tpl.replace(/\{\$a->([a-zA-Z0-9_]+)\}/g, function (m, k) {
                return a[k] !== undefined ? a[k] : m;
            });
        }
        return tpl.replace(/\{\$a\}/g, a);
    }

    /**
     * Set the status line.
     * @param {string} text
     * @param {string} [level] one of info|success|danger
     */
    function setStatus(text, level) {
        statusEl.className = 'quiz-tutoria-status alert alert-' + (level || 'info');
        statusEl.textContent = text;
    }

    /**
     * POST an action to the plugin's ajax endpoint.
     * @param {string} action
     * @param {Object} params
     * @returns {Promise<Object>}
     */
    function call(action, params) {
        var body = new URLSearchParams();
        body.set('action', action);
        body.set('cmid', cfg.cmid);
        body.set('sesskey', cfg.sesskey);
        Object.keys(params || {}).forEach(function (k) {
            body.set(k, params[k]);
        });

        return fetch(cfg.ajaxurl, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: body.toString()
        }).then(function (resp) {
            return resp.text().then(function (text) {
                var data;
                try {
                    data = text ? JSON.parse(text) : {};
                } catch (e) {
                    throw new Error(STR.error || 'Error');
                }
                if (!resp.ok) {
                    throw new Error(data.message || (STR.error || 'Error'));
                }
                return data;
            });
        });
    }

    /**
     * Parse a CSV string into an array of row objects keyed by header.
     * Handles quoted fields containing commas, quotes and newlines.
     * @param {string} text
     * @returns {Array<Object>}
     */
    function parseCsv(text) {
        var records = [];
        var field = '';
        var record = [];
        var inQuotes = false;
        for (var i = 0; i < text.length; i++) {
            var c = text[i];
            if (inQuotes) {
                if (c === '"') {
                    if (text[i + 1] === '"') {
                        field += '"';
                        i++;
                    } else {
                        inQuotes = false;
                    }
                } else {
                    field += c;
                }
            } else if (c === '"') {
                inQuotes = true;
            } else if (c === ',') {
                record.push(field);
                field = '';
            } else if (c === '\n' || c === '\r') {
                if (c === '\r' && text[i + 1] === '\n') {
                    i++;
                }
                record.push(field);
                field = '';
                if (record.length > 1 || record[0] !== '') {
                    records.push(record);
                }
                record = [];
            } else {
                field += c;
            }
        }
        if (field !== '' || record.length) {
            record.push(field);
            records.push(record);
        }
        if (!records.length) {
            return [];
        }
        var header = records.shift().map(function (h) {
            return h.trim().toLowerCase();
        });
        return records.map(function (r) {
            var obj = {};
            header.forEach(function (h, idx) {
                obj[h] = r[idx] !== undefined ? r[idx] : '';
            });
            return obj;
        });
    }

    function escapeHtml(s) {
        return String(s === null || s === undefined ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    /**
     * Normalize a numeric string from the API to a dot-decimal the browser and
     * parseFloat accept — the grader may return a locale decimal comma (e.g. 7,5).
     * @param {*} v
     * @returns {string}
     */
    function toNum(v) {
        return String(v === null || v === undefined ? '' : v).trim().replace(',', '.');
    }

    function truncate(s, n) {
        s = String(s || '');
        return s.length > n ? s.slice(0, n - 1) + '…' : s;
    }

    // ---- flow ---------------------------------------------------------------

    /**
     * Build the lookup index from the collected students.
     * @param {Array<Object>} students
     */
    function buildIndex(students) {
        index = {};
        students.forEach(function (st) {
            st.questions.forEach(function (q) {
                var meta = {
                    attemptid: q.attemptid,
                    slot: q.slot,
                    maxmark: q.max_mark,
                    question: q.question_text,
                    answer: q.answer,
                    name: st.name
                };
                if (st.email) {
                    index[st.email.toLowerCase() + '|' + q.slot] = meta;
                }
                if (st.id) {
                    index[String(st.id).toLowerCase() + '|' + q.slot] = meta;
                }
            });
        });
    }

    /**
     * Match a returned CSV row to a collected question.
     * @param {Object} row
     * @returns {(Object|null)}
     */
    function matchRow(row) {
        var slot = row.slot;
        var byEmail = row.email ? index[String(row.email).toLowerCase() + '|' + slot] : null;
        if (byEmail) {
            return byEmail;
        }
        var byMat = row.matricula ? index[String(row.matricula).toLowerCase() + '|' + slot] : null;
        return byMat || null;
    }

    /**
     * Render the editable review table.
     */
    function renderTable() {
        if (!rows.length) {
            resultsEl.innerHTML = '';
            applyBtn.style.display = 'none';
            setStatus(STR.nogrades, 'danger');
            return;
        }

        var html = '<p class="quiz-tutoria-hint">' + escapeHtml(STR.tablehint) + '</p>' +
            '<table class="table quiz-tutoria-table"><thead><tr>' +
            '<th style="width:14%;">' + escapeHtml(STR.colstudent) + '</th>' +
            '<th style="width:28%;">' + escapeHtml(STR.colquestion) + '</th>' +
            '<th style="width:10rem;">' + escapeHtml(STR.colmark) + '</th>' +
            '<th>' + escapeHtml(STR.colcomment) + '</th>' +
            '</tr></thead><tbody>';

        rows.forEach(function (r, i) {
            var detailid = 'quiz-tutoria-detail-' + i;
            var attempturl = cfg.reviewurl ?
                cfg.reviewurl + '?attempt=' + encodeURIComponent(r.attemptid) : '';
            html += '<tr id="quiz-tutoria-row-' + i + '">' +
                '<td>' + escapeHtml(r.name) + '</td>' +
                '<td><div title="' + escapeHtml(r.question) + '">' + escapeHtml(truncate(r.question, 80)) + '</div>' +
                    '<button type="button" class="btn btn-link btn-sm p-0 quiz-tutoria-toggle" data-i="' + i +
                    '" aria-expanded="false" aria-controls="' + detailid + '">' + escapeHtml(STR.viewanswer) +
                    '</button></td>' +
                '<td><div class="quiz-tutoria-markwrap"><input type="number" step="0.01" min="0" max="' +
                    escapeHtml(r.maxmark) + '" class="form-control quiz-tutoria-mark" data-i="' + i +
                    '" value="' + escapeHtml(r.mark) + '"> <small class="text-muted">/ ' +
                    escapeHtml(r.maxmark) + '</small></div>' +
                    '<div class="quiz-tutoria-rowerror-msg" id="quiz-tutoria-rowerror-' + i + '"></div></td>' +
                '<td><textarea class="form-control quiz-tutoria-comment" data-i="' + i + '" rows="3">' +
                    escapeHtml(r.comment) + '</textarea></td>' +
                '</tr>' +
                // What the student wrote — the teacher reads this before grading.
                '<tr class="quiz-tutoria-detail" id="' + detailid + '" hidden><td colspan="4">' +
                    '<div class="quiz-tutoria-detail-label">' + escapeHtml(STR.questionlabel) + '</div>' +
                    '<div class="quiz-tutoria-text">' + escapeHtml(r.question) + '</div>' +
                    '<div class="quiz-tutoria-detail-label">' + escapeHtml(STR.answerlabel) + '</div>' +
                    '<div class="quiz-tutoria-text quiz-tutoria-answer">' +
                        escapeHtml(r.answer ? r.answer : STR.noanswer) + '</div>' +
                    (attempturl ? '<a href="' + escapeHtml(attempturl) + '" target="_blank" rel="noopener">' +
                        escapeHtml(STR.openattempt) + ' \u2197</a>' : '') +
                '</td></tr>';
        });
        html += '</tbody></table>';
        resultsEl.innerHTML = html;

        resultsEl.querySelectorAll('.quiz-tutoria-toggle').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var detail = document.getElementById(btn.getAttribute('aria-controls'));
                var open = detail.hidden;
                detail.hidden = !open;
                btn.setAttribute('aria-expanded', open ? 'true' : 'false');
                btn.textContent = open ? STR.hideanswer : STR.viewanswer;
            });
        });

        // Keep the in-memory rows in sync with edits.
        resultsEl.querySelectorAll('.quiz-tutoria-mark').forEach(function (el) {
            el.addEventListener('input', function () {
                rows[parseInt(el.getAttribute('data-i'), 10)].mark = el.value;
            });
        });
        resultsEl.querySelectorAll('.quiz-tutoria-comment').forEach(function (el) {
            el.addEventListener('input', function () {
                rows[parseInt(el.getAttribute('data-i'), 10)].comment = el.value;
            });
        });

        applyBtn.style.display = '';
        setStatus(fmt(STR.done, rows.length), 'success');
    }

    /**
     * Poll a job until it is done or times out, then resolve with the CSV text.
     * @param {string} jobid
     * @returns {Promise<string>}
     */
    function poll(jobid) {
        var deadline = Date.now() + POLL_MAX_MS;
        function tick() {
            return call('poll', {jobid: jobid}).then(function (data) {
                if (data.done) {
                    return data.csv;
                }
                if (Date.now() > deadline) {
                    throw new Error(STR.error);
                }
                if (data.total) {
                    setStatus(fmt(STR.gradingn, {processed: data.processed, total: data.total}), 'info');
                } else {
                    setStatus(STR.grading, 'info');
                }
                return new Promise(function (resolve) {
                    setTimeout(resolve, POLL_INTERVAL_MS);
                }).then(tick);
            });
        }
        return tick();
    }

    /**
     * Run the whole grading flow.
     */
    function runGrading() {
        gradeBtn.disabled = true;
        applyBtn.style.display = 'none';
        resultsEl.innerHTML = '';
        setStatus(STR.collecting, 'info');

        call('collect', {}).then(function (data) {
            if (!data.studentcount) {
                setStatus(STR.nostudents, 'danger');
                throw {handled: true};
            }
            buildIndex(data.students);
            setStatus(STR.starting, 'info');
            return call('start', {criteria: criteriaEl ? criteriaEl.value : ''});
        }).then(function (data) {
            setStatus(STR.grading, 'info');
            return poll(data.jobid);
        }).then(function (csv) {
            var parsed = parseCsv(csv);
            rows = [];
            parsed.forEach(function (row) {
                var meta = matchRow(row);
                if (!meta) {
                    return;
                }
                rows.push({
                    attemptid: meta.attemptid,
                    slot: meta.slot,
                    maxmark: meta.maxmark,
                    name: meta.name,
                    question: meta.question,
                    answer: meta.answer,
                    // Compliant: the AI never supplies a grade. The mark starts empty
                    // for the teacher to decide; the AI text is only a feedback draft.
                    mark: '',
                    comment: row.comentario !== undefined ? row.comentario : ''
                });
            });
            renderTable();
        }).catch(function (err) {
            if (!err || !err.handled) {
                setStatus((err && err.message) ? err.message : STR.error, 'danger');
            }
        }).then(function () {
            gradeBtn.disabled = false;
        });
    }

    /**
     * Apply the reviewed grades.
     */
    function applyGrades() {
        // rowof[n] = the table row items[n] came from, to flag the rows that fail.
        var rowof = [];
        var items = [];
        rows.forEach(function (r, i) {
            if (r.mark === '' || r.mark === null || isNaN(parseFloat(toNum(r.mark)))) {
                return;
            }
            rowof.push(i);
            items.push({
                attemptid: r.attemptid,
                slot: r.slot,
                mark: parseFloat(toNum(r.mark)),
                comment: r.comment || ''
            });
        });

        if (!items.length) {
            setStatus(STR.nogrades, 'danger');
            return;
        }
        if (!window.confirm(fmt(STR.confirmapply, items.length))) {
            return;
        }

        applyBtn.disabled = true;
        setStatus(STR.applying, 'info');
        clearRowErrors();

        call('apply', {items: JSON.stringify(items)}).then(function (data) {
            var errors = data.errors ? Object.keys(data.errors).length : 0;
            Object.keys(data.errors || {}).forEach(function (n) {
                markRowError(rowof[parseInt(n, 10)], data.errors[n]);
            });
            if (errors) {
                setStatus(fmt(STR.applyerrors, {applied: data.applied, errors: errors}), 'danger');
            } else {
                setStatus(fmt(STR.applied, data.applied), 'success');
            }
        }).catch(function (err) {
            setStatus((err && err.message) ? err.message : STR.error, 'danger');
        }).then(function () {
            applyBtn.disabled = false;
        });
    }

    /**
     * Flag a table row whose grade could not be applied, with the reason.
     * @param {number} i row index
     * @param {string} message
     */
    function markRowError(i, message) {
        var tr = document.getElementById('quiz-tutoria-row-' + i);
        var msg = document.getElementById('quiz-tutoria-rowerror-' + i);
        if (tr) {
            tr.classList.add('quiz-tutoria-rowerror');
        }
        if (msg) {
            msg.textContent = fmt(STR.rowerror, message);
        }
    }

    function clearRowErrors() {
        resultsEl.querySelectorAll('.quiz-tutoria-rowerror').forEach(function (tr) {
            tr.classList.remove('quiz-tutoria-rowerror');
        });
        resultsEl.querySelectorAll('.quiz-tutoria-rowerror-msg').forEach(function (el) {
            el.textContent = '';
        });
    }

    /**
     * The how-to panel starts open; once a teacher closes it, keep it closed.
     */
    function bootHelp() {
        var help = document.getElementById('quiz-tutoria-help');
        if (!help) {
            return;
        }
        try {
            if (window.localStorage.getItem(HELP_STATE_KEY) === 'closed') {
                help.removeAttribute('open');
            }
        } catch (e) {
            // Storage blocked — the panel just stays open.
        }
        help.addEventListener('toggle', function () {
            try {
                window.localStorage.setItem(HELP_STATE_KEY, help.open ? 'open' : 'closed');
            } catch (e) {
                // Ignore.
            }
        });
    }

    /**
     * Wire everything up once the container is in the DOM.
     */
    function boot() {
        root = document.getElementById('quiz-tutoria-app');
        if (!root) {
            return;
        }
        cfg = {
            cmid: root.getAttribute('data-cmid'),
            sesskey: root.getAttribute('data-sesskey'),
            ajaxurl: root.getAttribute('data-ajaxurl'),
            reviewurl: root.getAttribute('data-reviewurl')
        };
        STR = JSON.parse(root.getAttribute('data-strings') || '{}');

        gradeBtn = document.getElementById('quiz-tutoria-grade');
        applyBtn = document.getElementById('quiz-tutoria-apply');
        statusEl = document.getElementById('quiz-tutoria-status');
        resultsEl = document.getElementById('quiz-tutoria-results');
        criteriaEl = document.getElementById('quiz-tutoria-criteria');

        gradeBtn.addEventListener('click', runGrading);
        applyBtn.addEventListener('click', applyGrades);
        bootHelp();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
}());
