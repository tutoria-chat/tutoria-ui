// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Client for the Tutoria AI grading report.
 *
 * Plain (non-AMD) JavaScript loaded via $PAGE->requires->js(), so the plugin
 * needs no build step and works exactly as shipped. Flow: start a Tutoria job,
 * poll it (the server saves the drafts when it finishes), then show an editable
 * table of the drafts; the teacher reads each answer, decides the grade and
 * applies. In feedback mode the mark always starts empty; in score mode
 * (corporate training only) it starts with the AI suggestion and flagged rows
 * form a review queue.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
(function () {
    'use strict';

    var POLL_INTERVAL_MS = 4000;
    var POLL_MAX_MS = 10 * 60 * 1000;
    var HELP_STATE_KEY = 'quiz_tutoria_help';

    // Declared here, assigned in boot() once the DOM is ready — so the script is
    // correct whether it is loaded in the page footer or (defensively) the head.
    var root, cfg, STR, gradeBtn, applyBtn, statusEl, resultsEl, criteriaEl, filterEl, filterWrap;

    // "feedback" (never a grade) or "score" (corporate only) — as Tutoria reports it.
    var mode = 'feedback';
    // The rows currently shown for review.
    var rows = [];

    // ---- small helpers ------------------------------------------------------

    /**
     * Format a string with {$a} or {$a->key} placeholders, Moodle style.
     * @param {string} tpl
     * @param {(Object|string|number)} a
     * @returns {string}
     */
    function fmt(tpl, a) {
        if (typeof tpl !== 'string') {
            return '';
        }
        if (a === undefined) {
            return tpl;
        }
        if (typeof a === 'object') {
            return tpl.replace(/\{\$a->([a-zA-Z0-9_]+)\}/g, function (m, k) {
                return a[k] !== undefined ? a[k] : m;
            });
        }
        return tpl.replace(/\{\$a\}/g, a);
    }

    /**
     * Set the status line.
     * @param {string} text
     * @param {string} [level] one of info|success|danger
     */
    function setStatus(text, level) {
        statusEl.className = 'quiz-tutoria-status alert alert-' + (level || 'info');
        statusEl.textContent = text;
    }

    /**
     * POST an action to the plugin's ajax endpoint.
     * @param {string} action
     * @param {Object} params
     * @returns {Promise<Object>}
     */
    function call(action, params) {
        var body = new URLSearchParams();
        body.set('action', action);
        body.set('cmid', cfg.cmid);
        body.set('sesskey', cfg.sesskey);
        Object.keys(params || {}).forEach(function (k) {
            body.set(k, params[k]);
        });

        return fetch(cfg.ajaxurl, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: body.toString()
        }).then(function (resp) {
            return resp.text().then(function (text) {
                var data;
                try {
                    data = text ? JSON.parse(text) : {};
                } catch (e) {
                    throw new Error(STR.error || 'Error');
                }
                if (!resp.ok) {
                    throw new Error(data.message || (STR.error || 'Error'));
                }
                return data;
            });
        });
    }

    function escapeHtml(s) {
        return String(s === null || s === undefined ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    /**
     * Normalize a numeric string from the API to a dot-decimal the browser and
     * parseFloat accept — the grader may return a locale decimal comma (e.g. 7,5).
     * @param {*} v
     * @returns {string}
     */
    function toNum(v) {
        return String(v === null || v === undefined ? '' : v).trim().replace(',', '.');
    }

    function truncate(s, n) {
        s = String(s || '');
        return s.length > n ? s.slice(0, n - 1) + '…' : s;
    }

    // ---- flow ---------------------------------------------------------------

    /**
     * Whether a score-mode row should go to a person before anything else.
     * @param {Object} r
     * @returns {boolean}
     */
    function needsReview(r) {
        return r.mode === 'score' &&
            ((r.review && r.review.length) || r.suggestedmark === null || r.confidence !== 'alta');
    }

    /**
     * Turn saved drafts into review-table rows.
     * @param {Array<Object>} items from ajax.php?action=drafts
     */
    function rowsFromItems(items) {
        rows = (items || []).map(function (it) {
            var isscore = it.mode === 'score';
            var comment = it.feedback || '';
            if (isscore && it.rationale) {
                comment += '\n\n' + STR.rationalelabel + ' ' + it.rationale;
            }
            var row = {
                attemptid: it.attemptid,
                slot: it.slot,
                maxmark: it.maxmark,
                name: it.name,
                question: it.question,
                answer: it.answer,
                mode: isscore ? 'score' : 'feedback',
                suggestedmark: isscore ? it.suggestedmark : null,
                confidence: it.confidence || '',
                review: it.review || [],
                rationale: it.rationale || '',
                // Feedback mode (every MEC/CNE institution): the AI never supplies a
                // grade, so the mark starts empty for the teacher to decide. Score mode
                // (corporate training only) pre-fills the suggestion for confirmation.
                mark: (isscore && it.suggestedmark !== null) ? String(it.suggestedmark) : '',
                comment: comment
            };
            row.confirmed = isscore ? !needsReview(row) : true;
            return row;
        });
        if (mode === 'score') {
            // Review queue first.
            rows.sort(function (a, b) {
                return (needsReview(b) ? 1 : 0) - (needsReview(a) ? 1 : 0);
            });
        }
    }

    function reviewBadges(r) {
        if (r.mode !== 'score') {
            return '';
        }
        var html = '';
        var conf = STR['conf_' + r.confidence];
        if (conf) {
            var cls = r.confidence === 'alta' ? 'badge-success bg-success' :
                (r.confidence === 'media' ? 'badge-warning bg-warning text-dark' : 'badge-danger bg-danger');
            html += '<span class="badge quiz-tutoria-badge ' + cls + '">' + escapeHtml(fmt(STR.confidence, conf)) + '</span> ';
        }
        (r.review || []).forEach(function (code) {
            html += '<span class="badge quiz-tutoria-badge badge-warning bg-warning text-dark">' +
                escapeHtml(STR['review_' + code] || code) + '</span> ';
        });
        if (r.suggestedmark !== null) {
            html += '<div class="small text-muted">' +
                escapeHtml(fmt(STR.suggested, {mark: r.suggestedmark, max: r.maxmark})) + '</div>';
        }
        return html;
    }

    /**
     * Render the editable review table.
     */
    function renderTable() {
        if (!rows.length) {
            resultsEl.innerHTML = '';
            applyBtn.style.display = 'none';
            return;
        }
        var isscore = mode === 'score';
        var onlyreview = isscore && filterEl && filterEl.checked;
        var queued = rows.filter(needsReview).length;

        var html = '<p class="quiz-tutoria-hint">' + escapeHtml(isscore ? STR.tablehintscore : STR.tablehint) + '</p>';
        if (isscore) {
            html += '<p class="small"><strong>' + escapeHtml(fmt(STR.queuecount, {n: queued, total: rows.length})) +
                '</strong></p>';
        }
        html += '<table class="table quiz-tutoria-table"><thead><tr>' +
            (isscore ? '<th style="width:4rem;">' + escapeHtml(STR.colconfirm) + '</th>' : '') +
            '<th style="width:14%;">' + escapeHtml(STR.colstudent) + '</th>' +
            '<th style="width:26%;">' + escapeHtml(STR.colquestion) + '</th>' +
            '<th style="width:11rem;">' + escapeHtml(isscore ? STR.colmarkscore : STR.colmark) + '</th>' +
            '<th>' + escapeHtml(STR.colcomment) + '</th>' +
            '</tr></thead><tbody>';

        var cols = isscore ? 5 : 4;
        rows.forEach(function (r, i) {
            if (onlyreview && !needsReview(r)) {
                return;
            }
            var detailid = 'quiz-tutoria-detail-' + i;
            var attempturl = cfg.reviewurl ?
                cfg.reviewurl + '?attempt=' + encodeURIComponent(r.attemptid) : '';
            html += '<tr id="quiz-tutoria-row-' + i + '"' + (needsReview(r) ? ' class="quiz-tutoria-needsreview"' : '') + '>' +
                (isscore ? '<td><input type="checkbox" class="form-check-input quiz-tutoria-confirm" data-i="' + i +
                    '"' + (r.confirmed ? ' checked' : '') + ' aria-label="' + escapeHtml(STR.colconfirm) + '"></td>' : '') +
                '<td>' + escapeHtml(r.name) + '</td>' +
                '<td><div title="' + escapeHtml(r.question) + '">' + escapeHtml(truncate(r.question, 80)) + '</div>' +
                    '<button type="button" class="btn btn-link btn-sm p-0 quiz-tutoria-toggle" data-i="' + i +
                    '" aria-expanded="false" aria-controls="' + detailid + '">' + escapeHtml(STR.viewanswer) +
                    '</button></td>' +
                '<td><div class="quiz-tutoria-markwrap"><input type="number" step="0.01" min="0" max="' +
                    escapeHtml(r.maxmark) + '" class="form-control quiz-tutoria-mark" data-i="' + i +
                    '" value="' + escapeHtml(r.mark) + '"> <small class="text-muted">/ ' +
                    escapeHtml(r.maxmark) + '</small></div>' + reviewBadges(r) +
                    '<div class="quiz-tutoria-rowerror-msg" id="quiz-tutoria-rowerror-' + i + '"></div></td>' +
                '<td><textarea class="form-control quiz-tutoria-comment" data-i="' + i + '" rows="3">' +
                    escapeHtml(r.comment) + '</textarea></td>' +
                '</tr>' +
                // What the student wrote — the teacher reads this before grading.
                '<tr class="quiz-tutoria-detail" id="' + detailid + '" hidden><td colspan="' + cols + '">' +
                    '<div class="quiz-tutoria-detail-label">' + escapeHtml(STR.questionlabel) + '</div>' +
                    '<div class="quiz-tutoria-text">' + escapeHtml(r.question) + '</div>' +
                    '<div class="quiz-tutoria-detail-label">' + escapeHtml(STR.answerlabel) + '</div>' +
                    '<div class="quiz-tutoria-text quiz-tutoria-answer">' +
                        escapeHtml(r.answer ? r.answer : STR.noanswer) + '</div>' +
                    (attempturl ? '<a href="' + escapeHtml(attempturl) + '" target="_blank" rel="noopener">' +
                        escapeHtml(STR.openattempt) + ' ↗</a>' : '') +
                '</td></tr>';
        });
        html += '</tbody></table>';
        resultsEl.innerHTML = html;

        resultsEl.querySelectorAll('.quiz-tutoria-toggle').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var detail = document.getElementById(btn.getAttribute('aria-controls'));
                var open = detail.hidden;
                detail.hidden = !open;
                btn.setAttribute('aria-expanded', open ? 'true' : 'false');
                btn.textContent = open ? STR.hideanswer : STR.viewanswer;
            });
        });

        // Keep the in-memory rows in sync with edits.
        resultsEl.querySelectorAll('.quiz-tutoria-mark').forEach(function (el) {
            el.addEventListener('input', function () {
                rows[parseInt(el.getAttribute('data-i'), 10)].mark = el.value;
            });
        });
        resultsEl.querySelectorAll('.quiz-tutoria-comment').forEach(function (el) {
            el.addEventListener('input', function () {
                rows[parseInt(el.getAttribute('data-i'), 10)].comment = el.value;
            });
        });
        resultsEl.querySelectorAll('.quiz-tutoria-confirm').forEach(function (el) {
            el.addEventListener('change', function () {
                rows[parseInt(el.getAttribute('data-i'), 10)].confirmed = el.checked;
            });
        });

        applyBtn.style.display = '';
    }

    /**
     * Poll a job until the server has saved its drafts.
     * @param {string} jobid
     * @returns {Promise}
     */
    function poll(jobid) {
        var deadline = Date.now() + POLL_MAX_MS;
        function tick() {
            return call('poll', {jobid: jobid}).then(function (data) {
                if (data.done) {
                    return data;
                }
                if (Date.now() > deadline) {
                    throw new Error(STR.error);
                }
                if (data.total) {
                    setStatus(fmt(STR.gradingn, {processed: data.processed, total: data.total}), 'info');
                } else {
                    setStatus(STR.grading, 'info');
                }
                return new Promise(function (resolve) {
                    setTimeout(resolve, POLL_INTERVAL_MS);
                }).then(tick);
            });
        }
        return tick();
    }

    /**
     * Load the saved drafts (also after a reload, or when they were generated from
     * the floating panel) and render them.
     * @param {boolean} [resume] resume polling a running job.
     * @returns {Promise}
     */
    function loadDrafts(resume) {
        return call('drafts', {}).then(function (data) {
            mode = data.mode === 'score' ? 'score' : 'feedback';
            applyMode(data);
            rowsFromItems(data.items);
            renderTable();
            if (rows.length) {
                setStatus(fmt(STR.done, rows.length), 'success');
            }
            if (resume && data.job && data.job.status === 'running') {
                gradeBtn.disabled = true;
                setStatus(STR.grading, 'info');
                return poll(data.job.jobid).then(function () {
                    return loadDrafts(false);
                }).then(function () {
                    gradeBtn.disabled = false;
                });
            }
            return null;
        });
    }

    /**
     * Show the notice and filter that match the mode Tutoria reports.
     * @param {Object} data
     */
    function applyMode(data) {
        var notice = document.getElementById('quiz-tutoria-notice');
        if (notice) {
            notice.textContent = mode === 'score' ? STR.noticescore : STR.noticefeedback;
            notice.className = 'alert ' + (mode === 'score' ? 'alert-warning' : 'alert-info');
        }
        var keyhint = document.getElementById('quiz-tutoria-needskey');
        if (keyhint) {
            keyhint.hidden = !data.needsinstitutionkey;
        }
        if (filterWrap) {
            filterWrap.hidden = mode !== 'score';
        }
    }

    /**
     * Run the whole grading flow.
     */
    function runGrading() {
        gradeBtn.disabled = true;
        applyBtn.style.display = 'none';
        resultsEl.innerHTML = '';
        setStatus(STR.starting, 'info');

        call('start', {criteria: criteriaEl ? criteriaEl.value : ''}).then(function (data) {
            setStatus(STR.grading, 'info');
            return poll(data.jobid);
        }).then(function () {
            return loadDrafts(false);
        }).then(function () {
            if (!rows.length) {
                setStatus(STR.nostudents, 'danger');
            }
        }).catch(function (err) {
            setStatus((err && err.message) ? err.message : STR.error, 'danger');
        }).then(function () {
            gradeBtn.disabled = false;
        });
    }

    /**
     * Apply the reviewed grades.
     */
    function applyGrades() {
        // rowof[n] = the table row items[n] came from, to flag the rows that fail.
        var rowof = [];
        var items = [];
        rows.forEach(function (r, i) {
            if (r.mark === '' || r.mark === null || isNaN(parseFloat(toNum(r.mark)))) {
                return;
            }
            // Score mode: only rows the person ticked as confirmed.
            if (r.mode === 'score' && !r.confirmed) {
                return;
            }
            rowof.push(i);
            items.push({
                attemptid: r.attemptid,
                slot: r.slot,
                mark: parseFloat(toNum(r.mark)),
                comment: r.comment || ''
            });
        });

        if (!items.length) {
            setStatus(STR.nogrades, 'danger');
            return;
        }
        if (!window.confirm(fmt(STR.confirmapply, items.length))) {
            return;
        }

        applyBtn.disabled = true;
        setStatus(STR.applying, 'info');
        clearRowErrors();

        call('apply', {items: JSON.stringify(items)}).then(function (data) {
            var errors = data.errors ? Object.keys(data.errors).length : 0;
            Object.keys(data.errors || {}).forEach(function (n) {
                markRowError(rowof[parseInt(n, 10)], data.errors[n]);
            });
            if (errors) {
                setStatus(fmt(STR.applyerrors, {applied: data.applied, errors: errors}), 'danger');
            } else {
                setStatus(fmt(STR.applied, data.applied), 'success');
            }
        }).catch(function (err) {
            setStatus((err && err.message) ? err.message : STR.error, 'danger');
        }).then(function () {
            applyBtn.disabled = false;
        });
    }

    /**
     * Flag a table row whose grade could not be applied, with the reason.
     * @param {number} i row index
     * @param {string} message
     */
    function markRowError(i, message) {
        var tr = document.getElementById('quiz-tutoria-row-' + i);
        var msg = document.getElementById('quiz-tutoria-rowerror-' + i);
        if (tr) {
            tr.classList.add('quiz-tutoria-rowerror');
        }
        if (msg) {
            msg.textContent = fmt(STR.rowerror, message);
        }
    }

    function clearRowErrors() {
        resultsEl.querySelectorAll('.quiz-tutoria-rowerror').forEach(function (tr) {
            tr.classList.remove('quiz-tutoria-rowerror');
        });
        resultsEl.querySelectorAll('.quiz-tutoria-rowerror-msg').forEach(function (el) {
            el.textContent = '';
        });
    }

    /**
     * The how-to panel starts open; once a teacher closes it, keep it closed.
     */
    function bootHelp() {
        var help = document.getElementById('quiz-tutoria-help');
        if (!help) {
            return;
        }
        try {
            if (window.localStorage.getItem(HELP_STATE_KEY) === 'closed') {
                help.removeAttribute('open');
            }
        } catch (e) {
            // Storage blocked — the panel just stays open.
        }
        help.addEventListener('toggle', function () {
            try {
                window.localStorage.setItem(HELP_STATE_KEY, help.open ? 'open' : 'closed');
            } catch (e) {
                // Ignore.
            }
        });
    }

    /**
     * Wire everything up once the container is in the DOM.
     */
    function boot() {
        root = document.getElementById('quiz-tutoria-app');
        if (!root) {
            return;
        }
        cfg = {
            cmid: root.getAttribute('data-cmid'),
            sesskey: root.getAttribute('data-sesskey'),
            ajaxurl: root.getAttribute('data-ajaxurl'),
            reviewurl: root.getAttribute('data-reviewurl')
        };
        STR = JSON.parse(root.getAttribute('data-strings') || '{}');

        gradeBtn = document.getElementById('quiz-tutoria-grade');
        applyBtn = document.getElementById('quiz-tutoria-apply');
        statusEl = document.getElementById('quiz-tutoria-status');
        resultsEl = document.getElementById('quiz-tutoria-results');
        criteriaEl = document.getElementById('quiz-tutoria-criteria');
        filterEl = document.getElementById('quiz-tutoria-onlyreview');
        filterWrap = document.getElementById('quiz-tutoria-filter');

        gradeBtn.addEventListener('click', runGrading);
        applyBtn.addEventListener('click', applyGrades);
        if (filterEl) {
            filterEl.addEventListener('change', renderTable);
        }
        bootHelp();
        // Drafts are saved on the server: show the last ones and resume a running job.
        loadDrafts(true).catch(function (err) {
            setStatus((err && err.message) ? err.message : STR.error, 'danger');
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
}());
