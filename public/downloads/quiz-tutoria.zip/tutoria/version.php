<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Version details for the Tutoria AI grading quiz report.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'quiz_tutoria';
$plugin->version   = 2026100201;
$plugin->requires  = 2023042400;   // Moodle 4.2 — first release with mod_quiz\local\reports\report_base.
$plugin->supported = [402, 502];   // Moodle 4.2 through 5.2.
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.3.0';      // In-page how-to guide; read each student's answer in the review table.
