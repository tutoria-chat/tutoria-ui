<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Brazilian Portuguese strings for quiz_tutoria.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Assistente de Correção (Tutoria)';
$string['compliance_notice'] = 'Conforme as Diretrizes do CNE para IA na Educação, a IA não corrige nem atribui notas em avaliações dissertativas. Este assistente apenas organiza as respostas e sugere rascunhos de feedback formativo — a avaliação e a nota são de responsabilidade do professor.';
// Rótulo curto do relatório na navegação/menu Resultados do questionário.
// O Moodle busca get_string('tutoria','quiz_tutoria') — o nome puro do
// relatório — em toda página de relatório do questionário; precisa existir.
$string['tutoria'] = 'Assistente de Correção';
$string['tutoriareport'] = 'Assistente de Correção (Tutoria)';
$string['tutoria:view'] = 'Usar a correção com IA da Tutoria em um questionário';

// Interface do relatório.
$string['intro'] = 'O assistente organiza as respostas dissertativas deste questionário e prepara rascunhos de feedback formativo para agilizar a sua correção. Ele não atribui notas — a avaliação e a nota são sempre suas.';
$string['noessay'] = 'Este questionário não tem questões dissertativas, então não há o que corrigir com IA.';
$string['criteria'] = 'Critérios de correção / rubrica (você define)';
$string['criteria_placeholder'] = 'Descreva o que uma boa resposta deve conter (não instruções de nota). Ex.: deve apresentar uma tese clara, dois argumentos de apoio e citar a fonte. A IA verifica cada ponto e escreve o rascunho do feedback — a nota é sempre sua.';
$string['grade_button'] = 'Analisar com IA';
$string['apply_button'] = 'Lançar notas e feedback';
$string['col_student'] = 'Aluno';
$string['col_question'] = 'Questão';
$string['col_mark'] = 'Nota (você atribui)';
$string['col_comment'] = 'Rascunho de feedback da IA';

// Configurações.
$string['settings_setup'] = 'Conexão com a Tutoria';
$string['settings_setup_desc'] = 'Conecte este Moodle ao serviço de correção da Tutoria. Estas configurações são definidas uma vez para todo o site — não há configuração por curso ou por questionário. Copie os três valores do painel da Tutoria: <strong>Configuração do AVA → Assistente de Correção</strong>.';
$string['settings_baseurl'] = 'URL base da API';
$string['settings_baseurl_desc'] = 'O endereço da API da Tutoria. Copie do painel da Tutoria (Configuração do AVA → Assistente de Correção).';
$string['settings_apikey'] = 'Chave da API';
$string['settings_apikey_desc'] = 'A chave da sua instituição (começa com tgk_), gerada no painel da Tutoria (Configuração do AVA → Assistente de Correção). Ela aparece só uma vez — se perder, revogue-a lá e crie uma nova.';
$string['settings_universityid'] = 'ID da instituição';
$string['settings_universityid_desc'] = 'O número da sua instituição na Tutoria, exibido no painel da Tutoria (Configuração do AVA → Assistente de Correção).';
$string['settings_timeout'] = 'Tempo limite por requisição (segundos)';
$string['settings_timeout_desc'] = 'Quanto tempo esperar pela API da Tutoria em cada chamada antes de desistir (1–300).';
$string['settings_defaultcriteria'] = 'Orientações de correção padrão';
$string['settings_defaultcriteria_desc'] = 'Orientação opcional enviada em toda correção. O professor pode substituí-la a cada uso.';

// Erros (servidor).
$string['error_notconfigured'] = 'A correção com IA da Tutoria ainda não foi configurada. Um administrador precisa informar a URL da API, a chave e o id da instituição nas configurações do site.';
$string['error_startfailed'] = 'Não foi possível iniciar a correção. {$a}';
$string['error_nojobid'] = 'O serviço de correção aceitou a requisição, mas não retornou um id de trabalho.';
$string['error_jobfailed'] = 'A correção falhou. {$a}';
$string['error_pollfailed'] = 'Não foi possível verificar o progresso da correção. {$a}';
$string['error_transport'] = 'Não foi possível contatar o serviço da Tutoria: {$a}';
$string['error_nosubmissions'] = 'Não há tentativas finalizadas com respostas dissertativas para corrigir.';
$string['error_baditems'] = 'Dados de nota malformados.';
$string['error_badaction'] = 'Ação desconhecida.';
$string['error_unexpected'] = 'Ocorreu um erro inesperado.';
$string['error_nomark'] = 'Nenhuma nota informada.';
$string['error_attemptnotinquiz'] = 'Essa tentativa não pertence a este questionário.';
$string['error_notallowed'] = 'Você não tem permissão para corrigir este aluno neste questionário.';
$string['error_attemptnotfinished'] = 'A tentativa não está finalizada.';
$string['error_slotmissing'] = 'A questão {$a} não faz parte dessa tentativa.';
$string['error_markrange'] = 'A nota {$a->mark} está fora do intervalo permitido [{$a->min}–{$a->max}].';

// Dicas de HTTP.
$string['httperr_401'] = 'A chave da API foi rejeitada (401). Confira se ela foi colada inteira, ou crie uma nova chave no painel da Tutoria (Configuração do AVA → Assistente de Correção).';
$string['httperr_403'] = 'Acesso negado (403): a correção com IA pode não estar habilitada para esta instituição, ou a chave pertence a outra instituição — confira o ID da instituição.';
$string['httperr_404'] = 'Curso ou instituição não encontrados (404). Verifique se o "id da instituição" e a "URL da API" nas configurações do plugin Tutoria apontam para o ambiente correto.';
$string['httperr_422'] = 'O trabalho de correção falhou (422).';
$string['httperr_503'] = 'O serviço de correção não está configurado no servidor (503).';
$string['httperr_generic'] = 'O serviço de correção retornou HTTP {$a}.';

// Guia de uso na própria página.
$string['help_title'] = 'Como usar este assistente — passo a passo';
$string['help_steps_title'] = 'Passo a passo';
$string['help_step1'] = '(Opcional) Em “Critérios de correção / rubrica”, escreva o que uma boa resposta deve conter. Não escreva instruções de nota.';
$string['help_step2'] = 'Clique em “Analisar com IA” e espere a mensagem “Correção em andamento… X de Y” terminar. Pode levar alguns minutos — não feche esta página.';
$string['help_step3'] = 'Aparece uma tabela. Cada linha é a resposta de um aluno a uma questão. Clique em “Ver resposta” para ler o que o aluno escreveu.';
$string['help_step4'] = 'Digite a nota no campo “Nota (você atribui)” e, se quiser, ajuste o rascunho de feedback.';
$string['help_step5'] = 'Clique em “Lançar notas e feedback” e confirme. Só as linhas com nota são lançadas — dá para corrigir aos poucos e lançar mais de uma vez.';
$string['help_step6'] = 'Para conferir, abra Resultados → Notas ou o Diário de notas da disciplina. O aluno vê a nota e o comentário ao revisar a tentativa.';
$string['help_columns_title'] = 'Como ler cada linha da tabela';
$string['help_col_student'] = 'De quem é a resposta.';
$string['help_col_question'] = 'O enunciado da questão, resumido. O texto inteiro aparece em “Ver resposta”.';
$string['help_col_answer'] = 'Mostra o enunciado inteiro e o que o aluno escreveu. “Abrir tentativa” abre a prova completa do aluno no Moodle, em outra aba.';
$string['help_col_mark'] = 'Começa em branco — a IA nunca sugere nota. O número depois da barra (ex.: / 10) é o valor máximo da questão.';
$string['help_col_comment'] = 'Um comentário para o aluno, escrito pela IA como ponto de partida. Edite ou apague à vontade: ao lançar, o aluno vê exatamente o que estiver neste campo.';
$string['help_problems_title'] = 'Deu algum erro?';
$string['help_problem_config'] = 'Mensagem sobre a chave da API, acesso negado ou plugin não configurado:';
$string['help_fix_config'] = 'é configuração do site, não da sua prova. Avise o administrador do Moodle — o passo a passo dele está no painel da Tutoria, em Configuração do AVA → Assistente de Correção.';
$string['help_problem_nostudents'] = '“Nenhuma tentativa finalizada…”:';
$string['help_fix_nostudents'] = 'nenhum aluno enviou a prova ainda. Só tentativas finalizadas aparecem.';
$string['help_problem_rowerror'] = 'Linha marcada em vermelho depois de lançar:';
$string['help_fix_rowerror'] = 'a nota dessa linha não foi lançada (o motivo aparece embaixo da nota — por exemplo, passou do valor da questão). As outras já foram salvas: corrija a linha e clique em “Lançar notas e feedback” de novo.';
$string['help_problem_slow'] = 'Demorou demais ou apareceu “Algo deu errado”:';
$string['help_fix_slow'] = 'clique em “Analisar com IA” de novo. Nada chega aos alunos até você clicar em “Lançar notas e feedback”.';
$string['help_fullguide'] = 'Guia completo com imagens (PDF) ↗';

// Strings dinâmicas do JS.
$string['js_collecting'] = 'Coletando respostas dissertativas…';
$string['js_nostudents'] = 'Nenhuma tentativa finalizada com respostas dissertativas foi encontrada.';
$string['js_starting'] = 'Enviando respostas para correção…';
$string['js_grading'] = 'Correção em andamento…';
$string['js_gradingn'] = 'Correção em andamento… {$a->processed} de {$a->total}';
$string['js_done'] = 'Concluído — {$a} resposta(s) analisada(s). Revise cada uma e atribua a sua nota e o feedback.';
$string['js_applying'] = 'Aplicando notas…';
$string['js_applied'] = '{$a} nota(s) aplicada(s).';
$string['js_applyerrors'] = '{$a->applied} nota(s) aplicada(s); {$a->errors} não puderam ser aplicadas.';
$string['js_confirmapply'] = 'Lançar {$a} nota(s) e comentário(s)? As notas são as que você definiu.';
$string['js_nogrades'] = 'Informe ao menos uma nota antes de lançar.';
$string['js_error'] = 'Algo deu errado. Tente novamente.';
$string['js_viewanswer'] = 'Ver resposta';
$string['js_hideanswer'] = 'Ocultar resposta';
$string['js_openattempt'] = 'Abrir tentativa';
$string['js_questionlabel'] = 'Enunciado';
$string['js_answerlabel'] = 'Resposta do aluno';
$string['js_noanswer'] = '(o aluno não escreveu nada)';
$string['js_tablehint'] = 'Cada linha é a resposta de um aluno a uma questão: clique em “Ver resposta”, digite a nota e ajuste o rascunho. Linhas sem nota não são lançadas.';
$string['js_rowerror'] = 'Não lançada: {$a}';

// Eventos (registro de auditoria — Relatórios → Logs).
$string['event_feedback_requested'] = 'Rascunhos de feedback da IA solicitados';
$string['event_grades_confirmed'] = 'Notas confirmadas pelo professor';

// Privacidade.
$string['privacy:metadata:tutoria_external'] = 'Para corrigir respostas dissertativas com IA, as respostas e informações de identificação são enviadas ao serviço externo Tutoria.';
$string['privacy:metadata:tutoria_external:name'] = 'O nome completo do aluno, para que o professor reconheça de quem é a resposta sendo corrigida.';
$string['privacy:metadata:tutoria_external:studentid'] = 'O número de identificação (matrícula) ou nome de usuário do aluno, usado para vincular a nota retornada à tentativa correta.';
$string['privacy:metadata:tutoria_external:email'] = 'O e-mail do aluno, usado para vincular a nota retornada à tentativa correta.';
$string['privacy:metadata:tutoria_external:answer'] = 'O texto da resposta dissertativa do aluno, que é o que a IA corrige.';

// Modo de nota sugerida — SÓ para treinamento corporativo fora do sistema MEC.
// A Tutoria liga esse modo por instituição; universidades e escolas ficam sempre no
// modo de feedback (a IA não sugere nota — Diretrizes do CNE).
$string['compliance_notice_score'] = 'Treinamento corporativo: a IA sugere uma nota a partir da rubrica, com a evidência de cada critério e o nível de confiança. Uma pessoa confere e confirma cada nota antes de lançar — nada é lançado sozinho.';
$string['intro_score'] = 'O assistente lê as respostas dissertativas deste questionário, sugere a nota de cada uma pela rubrica e prepara o feedback. As respostas que precisam de um olhar humano aparecem primeiro, na fila de revisão.';
$string['needs_institution_key'] = 'A Tutoria ativou a nota sugerida para esta instituição, mas este Moodle ainda usa a chave antiga compartilhada, que só permite feedback. Peça ao administrador para trocar pela chave da instituição (começa com tgk_) no painel da Tutoria.';
$string['panel_hint'] = 'Dica: na página “Avaliação manual” do Moodle aparece uma janela flutuante da Tutoria com o rascunho de cada resposta, para você corrigir sem sair de lá.';
$string['only_review'] = 'Mostrar só a fila de revisão';
$string['col_mark_score'] = 'Nota (sugerida — confira)';
$string['col_confirm'] = 'Confirmar';
$string['js_tablehintscore'] = 'A fila de revisão vem primeiro. Leia a resposta, ajuste a nota se precisar e marque “Confirmar”. Só linhas confirmadas são lançadas.';
$string['js_queuecount'] = '{$a->n} de {$a->total} resposta(s) na fila de revisão.';
$string['help_score_step1'] = '(Opcional, recomendado) Na edição de cada questão dissertativa, escreva a rubrica em “Informações para avaliadores”, com os pontos de cada critério. Sem rubrica, a IA monta os critérios a partir do enunciado e da resposta de referência.';
$string['help_score_step2'] = 'Clique em “Analisar com IA” e espere a mensagem “Correção em andamento… X de Y” terminar. Pode sair da página: o resultado fica salvo.';
$string['help_score_step3'] = 'A tabela mostra primeiro a fila de revisão: confiança baixa ou média, possível tentativa de manipular a correção, resposta vazia ou participante perto da nota de aprovação.';
$string['help_score_step4'] = 'Revise essas linhas: leia a resposta, ajuste a nota e marque “Confirmar”. As outras já vêm marcadas — desmarque qualquer uma que quiser deixar para depois.';
$string['help_score_step5'] = 'Clique em “Lançar notas e feedback” e confirme. Só linhas confirmadas e com nota são lançadas; o registro guarda quantas notas você alterou.';
$string['help_score_step6'] = 'Para conferir, abra Resultados → Notas ou o Diário de notas. O participante vê a nota, o feedback e os critérios ao revisar a tentativa.';
$string['help_col_mark_score'] = 'Vem com a nota sugerida pela IA (soma dos pontos de cada critério). Confira e ajuste: a nota lançada é sempre a que estiver neste campo.';
$string['criteria_rationale_label'] = 'Critérios:';
$string['conf_alta'] = 'alta';
$string['conf_media'] = 'média';
$string['conf_baixa'] = 'baixa';
$string['review_confianca_baixa'] = 'Confiança baixa';
$string['review_confianca_media'] = 'Confiança média';
$string['review_possivel_manipulacao'] = 'Possível tentativa de manipular a correção';
$string['review_resposta_vazia'] = 'Resposta vazia';
$string['review_erro'] = 'Erro ao analisar';
$string['review_nao_avaliado'] = 'Não analisada';
$string['review_sem_criterios'] = 'Sem critérios para calcular a nota';
$string['review_perto_da_aprovacao'] = 'Perto da nota de aprovação';
$string['error_unknownjob'] = 'Essa correção não pertence a este questionário.';

// Janela flutuante na página de avaliação manual do Moodle.
$string['panel_title'] = 'Assistente de Correção';
$string['panel_open'] = 'Assistente de Correção';
$string['panel_close'] = 'Fechar';
$string['panel_minimize'] = 'Minimizar';
$string['panel_notice_feedback'] = 'A IA não atribui nota (Diretrizes do CNE). Ela só sugere o rascunho do feedback — a nota é sua.';
$string['panel_notice_score'] = 'Notas sugeridas pela IA a partir da rubrica. Confira cada uma antes de salvar.';
$string['panel_generate'] = 'Gerar rascunhos para este questionário';
$string['panel_regenerate'] = 'Gerar de novo';
$string['panel_criteria'] = 'Critérios / rubrica (opcional)';
$string['panel_nodrafts'] = 'Ainda não há rascunhos para este questionário. Clique em “Gerar rascunhos”.';
$string['panel_nodraft_attempt'] = 'Sem rascunho para esta tentativa (só a tentativa que conta para a nota é analisada).';
$string['panel_insert'] = 'Inserir no comentário';
$string['panel_inserted'] = 'Inserido. Revise e clique em Salvar no Moodle.';
$string['panel_usemark'] = 'Usar nota sugerida';
$string['panel_markused'] = 'Nota preenchida. Confira e clique em Salvar no Moodle.';
$string['panel_insertall'] = 'Inserir todos os comentários desta página';
$string['panel_fillmarks'] = 'Preencher notas sem alerta';
$string['panel_insertedn'] = '{$a->n} comentário(s) inserido(s); {$a->skipped} já tinham texto e foram mantidos.';
$string['panel_filledn'] = '{$a} nota(s) preenchida(s).';
$string['panel_suggested'] = 'Nota sugerida: {$a->mark} / {$a->max}';
$string['panel_confidence'] = 'Confiança {$a}';
$string['panel_rationale'] = 'Ver critérios e evidências';
$string['panel_noeditor'] = 'Nenhum campo de comentário editável nesta página.';
$string['panel_savehint'] = 'Nada é gravado até você clicar em Salvar no Moodle.';
$string['panel_question'] = 'Questão {$a}';
$string['panel_goto'] = 'Ir até esta resposta na página';
$string['panel_needskey'] = 'A nota sugerida está ativada, mas este Moodle usa a chave antiga. Peça ao administrador a chave da instituição (tgk_).';
$string['panel_running'] = 'Gerando rascunhos…';
$string['panel_onpage'] = '{$a->n} de {$a->total} resposta(s) desta página têm rascunho.';
$string['panel_reviewonly'] = 'Preenche só as respostas com confiança alta e sem alerta, e só onde a nota está vazia.';
$string['panel_replacecomment'] = 'Este comentário já tem texto. Substituir pelo rascunho da IA?';

// Privacidade (tabelas locais) e limpeza.
$string['privacy:metadata:quiz_tutoria_drafts'] = 'Rascunhos da IA salvos por tentativa e questão, até o professor usá-los. Não são notas.';
$string['privacy:metadata:quiz_tutoria_drafts:userid'] = 'O aluno a quem a resposta pertence.';
$string['privacy:metadata:quiz_tutoria_drafts:attemptid'] = 'A tentativa do questionário.';
$string['privacy:metadata:quiz_tutoria_drafts:feedback'] = 'O rascunho de feedback escrito pela IA.';
$string['privacy:metadata:quiz_tutoria_drafts:suggestedmark'] = 'A nota sugerida pela IA (só em treinamento corporativo).';
$string['privacy:metadata:quiz_tutoria_drafts:rationale'] = 'Os pontos e evidências de cada critério (só em treinamento corporativo).';
$string['privacy:metadata:quiz_tutoria_drafts:timecreated'] = 'Quando o rascunho foi gerado.';
$string['privacy:metadata:quiz_tutoria_jobs'] = 'Correções com IA iniciadas por um professor.';
$string['privacy:metadata:quiz_tutoria_jobs:userid'] = 'O professor que iniciou a correção.';
$string['privacy:metadata:quiz_tutoria_jobs:timecreated'] = 'Quando a correção foi iniciada.';
$string['task_cleanup'] = 'Apagar rascunhos antigos do Assistente de Correção';
$string['settings_retentiondays'] = 'Guardar rascunhos por (dias)';
$string['settings_retentiondays_desc'] = 'Rascunhos da IA mais antigos que isso são apagados automaticamente (as notas e comentários já lançados não são afetados).';
$string['panel_dock'] = 'Fixar na lateral';
$string['panel_undock'] = 'Soltar (ou arraste pela barra de título)';
