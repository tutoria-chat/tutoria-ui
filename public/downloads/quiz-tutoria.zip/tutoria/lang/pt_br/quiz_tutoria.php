<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Brazilian Portuguese strings for quiz_tutoria.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Assistente de Correção (Tutoria)';
$string['compliance_notice'] = 'Conforme as Diretrizes do CNE para IA na Educação, a IA não corrige nem atribui notas em avaliações dissertativas. Este assistente apenas organiza as respostas e sugere rascunhos de feedback formativo — a avaliação e a nota são de responsabilidade do professor.';
// Rótulo curto do relatório na navegação/menu Resultados do questionário.
// O Moodle busca get_string('tutoria','quiz_tutoria') — o nome puro do
// relatório — em toda página de relatório do questionário; precisa existir.
$string['tutoria'] = 'Assistente de Correção';
$string['tutoriareport'] = 'Assistente de Correção (Tutoria)';
$string['tutoria:view'] = 'Usar a correção com IA da Tutoria em um questionário';

// Interface do relatório.
$string['intro'] = 'O assistente organiza as respostas dissertativas deste questionário e prepara rascunhos de feedback formativo para agilizar a sua correção. Ele não atribui notas — a avaliação e a nota são sempre suas.';
$string['noessay'] = 'Este questionário não tem questões dissertativas, então não há o que corrigir com IA.';
$string['criteria'] = 'Critérios de correção / rubrica (você define)';
$string['criteria_placeholder'] = 'Descreva o que uma boa resposta deve conter (não instruções de nota). Ex.: deve apresentar uma tese clara, dois argumentos de apoio e citar a fonte. A IA verifica cada ponto e escreve o rascunho do feedback — a nota é sempre sua.';
$string['grade_button'] = 'Analisar com IA';
$string['apply_button'] = 'Lançar notas e feedback';
$string['col_student'] = 'Aluno';
$string['col_question'] = 'Questão';
$string['col_mark'] = 'Nota (você atribui)';
$string['col_comment'] = 'Rascunho de feedback da IA';

// Configurações.
$string['settings_setup'] = 'Conexão com a Tutoria';
$string['settings_setup_desc'] = 'Conecte este Moodle ao serviço de correção da Tutoria. Estas configurações são definidas uma vez para todo o site — não há configuração por curso ou por questionário. Copie os três valores do painel da Tutoria: <strong>Configuração do AVA → Assistente de Correção</strong>.';
$string['settings_baseurl'] = 'URL base da API';
$string['settings_baseurl_desc'] = 'O endereço da API da Tutoria. Copie do painel da Tutoria (Configuração do AVA → Assistente de Correção).';
$string['settings_apikey'] = 'Chave da API';
$string['settings_apikey_desc'] = 'A chave da sua instituição (começa com tgk_), gerada no painel da Tutoria (Configuração do AVA → Assistente de Correção). Ela aparece só uma vez — se perder, revogue-a lá e crie uma nova.';
$string['settings_universityid'] = 'ID da instituição';
$string['settings_universityid_desc'] = 'O número da sua instituição na Tutoria, exibido no painel da Tutoria (Configuração do AVA → Assistente de Correção).';
$string['settings_timeout'] = 'Tempo limite por requisição (segundos)';
$string['settings_timeout_desc'] = 'Quanto tempo esperar pela API da Tutoria em cada chamada antes de desistir (1–300).';
$string['settings_defaultcriteria'] = 'Orientações de correção padrão';
$string['settings_defaultcriteria_desc'] = 'Orientação opcional enviada em toda correção. O professor pode substituí-la a cada uso.';

// Erros (servidor).
$string['error_notconfigured'] = 'A correção com IA da Tutoria ainda não foi configurada. Um administrador precisa informar a URL da API, a chave e o id da instituição nas configurações do site.';
$string['error_startfailed'] = 'Não foi possível iniciar a correção. {$a}';
$string['error_nojobid'] = 'O serviço de correção aceitou a requisição, mas não retornou um id de trabalho.';
$string['error_jobfailed'] = 'A correção falhou. {$a}';
$string['error_pollfailed'] = 'Não foi possível verificar o progresso da correção. {$a}';
$string['error_transport'] = 'Não foi possível contatar o serviço da Tutoria: {$a}';
$string['error_nosubmissions'] = 'Não há tentativas finalizadas com respostas dissertativas para corrigir.';
$string['error_baditems'] = 'Dados de nota malformados.';
$string['error_badaction'] = 'Ação desconhecida.';
$string['error_unexpected'] = 'Ocorreu um erro inesperado.';
$string['error_nomark'] = 'Nenhuma nota informada.';
$string['error_attemptnotinquiz'] = 'Essa tentativa não pertence a este questionário.';
$string['error_notallowed'] = 'Você não tem permissão para corrigir este aluno neste questionário.';
$string['error_attemptnotfinished'] = 'A tentativa não está finalizada.';
$string['error_slotmissing'] = 'A questão {$a} não faz parte dessa tentativa.';
$string['error_markrange'] = 'A nota {$a->mark} está fora do intervalo permitido [{$a->min}–{$a->max}].';

// Dicas de HTTP.
$string['httperr_401'] = 'A chave da API foi rejeitada (401). Confira se ela foi colada inteira, ou crie uma nova chave no painel da Tutoria (Configuração do AVA → Assistente de Correção).';
$string['httperr_403'] = 'Acesso negado (403): a correção com IA pode não estar habilitada para esta instituição, ou a chave pertence a outra instituição — confira o ID da instituição.';
$string['httperr_404'] = 'Curso ou instituição não encontrados (404). Verifique se o "id da instituição" e a "URL da API" nas configurações do plugin Tutoria apontam para o ambiente correto.';
$string['httperr_422'] = 'O trabalho de correção falhou (422).';
$string['httperr_503'] = 'O serviço de correção não está configurado no servidor (503).';
$string['httperr_generic'] = 'O serviço de correção retornou HTTP {$a}.';

// Guia de uso na própria página.
$string['help_title'] = 'Como usar este assistente — passo a passo';
$string['help_steps_title'] = 'Passo a passo';
$string['help_step1'] = '(Opcional) Em “Critérios de correção / rubrica”, escreva o que uma boa resposta deve conter. Não escreva instruções de nota.';
$string['help_step2'] = 'Clique em “Analisar com IA” e espere a mensagem “Correção em andamento… X de Y” terminar. Pode levar alguns minutos — não feche esta página.';
$string['help_step3'] = 'Aparece uma tabela. Cada linha é a resposta de um aluno a uma questão. Clique em “Ver resposta” para ler o que o aluno escreveu.';
$string['help_step4'] = 'Digite a nota no campo “Nota (você atribui)” e, se quiser, ajuste o rascunho de feedback.';
$string['help_step5'] = 'Clique em “Lançar notas e feedback” e confirme. Só as linhas com nota são lançadas — dá para corrigir aos poucos e lançar mais de uma vez.';
$string['help_step6'] = 'Para conferir, abra Resultados → Notas ou o Diário de notas da disciplina. O aluno vê a nota e o comentário ao revisar a tentativa.';
$string['help_columns_title'] = 'Como ler cada linha da tabela';
$string['help_col_student'] = 'De quem é a resposta.';
$string['help_col_question'] = 'O enunciado da questão, resumido. O texto inteiro aparece em “Ver resposta”.';
$string['help_col_answer'] = 'Mostra o enunciado inteiro e o que o aluno escreveu. “Abrir tentativa” abre a prova completa do aluno no Moodle, em outra aba.';
$string['help_col_mark'] = 'Começa em branco — a IA nunca sugere nota. O número depois da barra (ex.: / 10) é o valor máximo da questão.';
$string['help_col_comment'] = 'Um comentário para o aluno, escrito pela IA como ponto de partida. Edite ou apague à vontade: ao lançar, o aluno vê exatamente o que estiver neste campo.';
$string['help_problems_title'] = 'Deu algum erro?';
$string['help_problem_config'] = 'Mensagem sobre a chave da API, acesso negado ou plugin não configurado:';
$string['help_fix_config'] = 'é configuração do site, não da sua prova. Avise o administrador do Moodle — o passo a passo dele está no painel da Tutoria, em Configuração do AVA → Assistente de Correção.';
$string['help_problem_nostudents'] = '“Nenhuma tentativa finalizada…”:';
$string['help_fix_nostudents'] = 'nenhum aluno enviou a prova ainda. Só tentativas finalizadas aparecem.';
$string['help_problem_rowerror'] = 'Linha marcada em vermelho depois de lançar:';
$string['help_fix_rowerror'] = 'a nota dessa linha não foi lançada (o motivo aparece embaixo da nota — por exemplo, passou do valor da questão). As outras já foram salvas: corrija a linha e clique em “Lançar notas e feedback” de novo.';
$string['help_problem_slow'] = 'Demorou demais ou apareceu “Algo deu errado”:';
$string['help_fix_slow'] = 'clique em “Analisar com IA” de novo. Nada chega aos alunos até você clicar em “Lançar notas e feedback”.';
$string['help_fullguide'] = 'Guia completo com imagens (PDF) ↗';

// Strings dinâmicas do JS.
$string['js_collecting'] = 'Coletando respostas dissertativas…';
$string['js_nostudents'] = 'Nenhuma tentativa finalizada com respostas dissertativas foi encontrada.';
$string['js_starting'] = 'Enviando respostas para correção…';
$string['js_grading'] = 'Correção em andamento…';
$string['js_gradingn'] = 'Correção em andamento… {$a->processed} de {$a->total}';
$string['js_done'] = 'Concluído — {$a} resposta(s) analisada(s). Revise cada uma e atribua a sua nota e o feedback.';
$string['js_applying'] = 'Aplicando notas…';
$string['js_applied'] = '{$a} nota(s) aplicada(s).';
$string['js_applyerrors'] = '{$a->applied} nota(s) aplicada(s); {$a->errors} não puderam ser aplicadas.';
$string['js_confirmapply'] = 'Lançar {$a} nota(s) e comentário(s)? As notas são as que você definiu.';
$string['js_nogrades'] = 'Informe ao menos uma nota antes de lançar.';
$string['js_error'] = 'Algo deu errado. Tente novamente.';
$string['js_viewanswer'] = 'Ver resposta';
$string['js_hideanswer'] = 'Ocultar resposta';
$string['js_openattempt'] = 'Abrir tentativa';
$string['js_questionlabel'] = 'Enunciado';
$string['js_answerlabel'] = 'Resposta do aluno';
$string['js_noanswer'] = '(o aluno não escreveu nada)';
$string['js_tablehint'] = 'Cada linha é a resposta de um aluno a uma questão: clique em “Ver resposta”, digite a nota e ajuste o rascunho. Linhas sem nota não são lançadas.';
$string['js_rowerror'] = 'Não lançada: {$a}';

// Eventos (registro de auditoria — Relatórios → Logs).
$string['event_feedback_requested'] = 'Rascunhos de feedback da IA solicitados';
$string['event_grades_confirmed'] = 'Notas confirmadas pelo professor';

// Privacidade.
$string['privacy:metadata:tutoria_external'] = 'Para corrigir respostas dissertativas com IA, as respostas e informações de identificação são enviadas ao serviço externo Tutoria.';
$string['privacy:metadata:tutoria_external:name'] = 'O nome completo do aluno, para que o professor reconheça de quem é a resposta sendo corrigida.';
$string['privacy:metadata:tutoria_external:studentid'] = 'O número de identificação (matrícula) ou nome de usuário do aluno, usado para vincular a nota retornada à tentativa correta.';
$string['privacy:metadata:tutoria_external:email'] = 'O e-mail do aluno, usado para vincular a nota retornada à tentativa correta.';
$string['privacy:metadata:tutoria_external:answer'] = 'O texto da resposta dissertativa do aluno, que é o que a IA corrige.';
