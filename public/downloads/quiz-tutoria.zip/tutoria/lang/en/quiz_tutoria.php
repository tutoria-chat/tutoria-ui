<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * English strings for quiz_tutoria.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Grading assistant (Tutoria)';
$string['compliance_notice'] = 'Under the CNE Guidelines for AI in Education, AI does not correct or assign grades on essay assessments. This assistant only organises answers and suggests formative feedback drafts — the assessment and the grade are the teacher’s responsibility.';
// Short label used as the report's node in the quiz Results navigation and
// dropdown. Moodle looks this up as get_string('tutoria','quiz_tutoria') — the
// BARE report name — on every quiz report page, so it must exist.
$string['tutoria'] = 'Grading assistant';
$string['tutoriareport'] = 'Grading assistant (Tutoria)';
$string['tutoria:view'] = 'Use Tutoria AI grading in a quiz';

// Report UI.
$string['intro'] = 'This assistant organises the essay answers in this quiz and prepares formative feedback drafts to speed up your correction. It does not assign grades — the assessment and the grade are always yours.';
$string['noessay'] = 'This quiz has no essay questions, so there is nothing for AI grading to do.';
$string['criteria'] = 'Correction criteria / rubric (you define)';
$string['criteria_placeholder'] = 'Describe what a good answer should contain (not grade instructions). E.g. it should state a clear thesis, give two supporting arguments, and cite a source. The AI checks each point and drafts feedback — you always assign the grade.';
$string['grade_button'] = 'Analyse with AI';
$string['apply_button'] = 'Save grades & feedback';
$string['col_student'] = 'Student';
$string['col_question'] = 'Question';
$string['col_mark'] = 'Grade (you decide)';
$string['col_comment'] = 'AI feedback draft';

// Settings.
$string['settings_setup'] = 'Tutoria connection';
$string['settings_setup_desc'] = 'Connect this Moodle to the Tutoria grading service. These are set once for the whole site — there is no per-course or per-quiz configuration. Copy all three values from the Tutoria dashboard: <strong>AVA setup → Grading assistant</strong>.';
$string['settings_baseurl'] = 'API base URL';
$string['settings_baseurl_desc'] = 'The Tutoria API address. Copy it from the Tutoria dashboard (AVA setup → Grading assistant).';
$string['settings_apikey'] = 'API key';
$string['settings_apikey_desc'] = 'Your institution\'s key (starts with tgk_), generated in the Tutoria dashboard (AVA setup → Grading assistant). It\'s shown only once — if you lose it, revoke it there and create a new one.';
$string['settings_universityid'] = 'Institution ID';
$string['settings_universityid_desc'] = 'Your institution\'s number in Tutoria, shown in the Tutoria dashboard (AVA setup → Grading assistant).';
$string['settings_timeout'] = 'Request timeout (seconds)';
$string['settings_timeout_desc'] = 'How long to wait for the Tutoria API on each call before giving up (1–300).';
$string['settings_defaultcriteria'] = 'Default grading guidance';
$string['settings_defaultcriteria_desc'] = 'Optional guidance sent with every grading job. Teachers can override it per run.';

// Errors (server).
$string['error_notconfigured'] = 'Tutoria AI grading is not configured yet. An administrator must set the API URL, key and institution id in the site settings.';
$string['error_startfailed'] = 'Could not start grading. {$a}';
$string['error_nojobid'] = 'The grading service accepted the request but returned no job id.';
$string['error_jobfailed'] = 'Grading failed. {$a}';
$string['error_pollfailed'] = 'Could not check grading progress. {$a}';
$string['error_transport'] = 'Could not reach the Tutoria service: {$a}';
$string['error_nosubmissions'] = 'There are no finished attempts with essay answers to grade.';
$string['error_baditems'] = 'Malformed grade data.';
$string['error_badaction'] = 'Unknown action.';
$string['error_unexpected'] = 'An unexpected error occurred.';
$string['error_nomark'] = 'No mark given.';
$string['error_attemptnotinquiz'] = 'That attempt does not belong to this quiz.';
$string['error_notallowed'] = 'You are not allowed to grade this student in this quiz.';
$string['error_attemptnotfinished'] = 'The attempt is not finished.';
$string['error_slotmissing'] = 'Question {$a} is not part of that attempt.';
$string['error_markrange'] = 'Mark {$a->mark} is outside the allowed range [{$a->min}–{$a->max}].';

// HTTP hints.
$string['httperr_401'] = 'The API key was rejected (401). Check it was pasted in full, or create a new key in the Tutoria dashboard (AVA setup → Grading assistant).';
$string['httperr_403'] = 'Not allowed (403): AI grading may not be enabled for this institution, or the key belongs to a different institution — check the Institution ID.';
$string['httperr_404'] = 'Course or institution not found (404). Check that the "institution id" and "API URL" in the Tutoria plugin settings point to the correct environment.';
$string['httperr_422'] = 'The grading job failed (422).';
$string['httperr_503'] = 'The grading service is not configured on the server (503).';
$string['httperr_generic'] = 'The grading service returned HTTP {$a}.';

// JS dynamic strings.
$string['js_collecting'] = 'Collecting essay answers…';
$string['js_nostudents'] = 'No finished attempts with essay answers were found.';
$string['js_starting'] = 'Sending answers for grading…';
$string['js_grading'] = 'Grading in progress…';
$string['js_gradingn'] = 'Grading in progress… {$a->processed} of {$a->total}';
$string['js_done'] = 'Done — {$a} answer(s) analysed. Review each, then set your grade and feedback.';
$string['js_applying'] = 'Applying grades…';
$string['js_applied'] = 'Applied {$a} grade(s).';
$string['js_applyerrors'] = 'Applied {$a->applied} grade(s); {$a->errors} could not be applied.';
$string['js_confirmapply'] = 'Save {$a} grade(s) and comment(s)? The grades are the ones you set.';
$string['js_nogrades'] = 'Enter at least one grade before saving.';
$string['js_error'] = 'Something went wrong. Please try again.';

// Events (audit log — Reports → Logs).
$string['event_feedback_requested'] = 'AI feedback drafts requested';
$string['event_grades_confirmed'] = 'Grades confirmed by teacher';

// Privacy.
$string['privacy:metadata:tutoria_external'] = 'To grade essay answers with AI, answers and identifying information are sent to the external Tutoria service.';
$string['privacy:metadata:tutoria_external:name'] = 'The student\'s full name, so a teacher can recognise whose answer is being graded.';
$string['privacy:metadata:tutoria_external:studentid'] = 'The student\'s ID number (or username), used to match the returned grade back to the right attempt.';
$string['privacy:metadata:tutoria_external:email'] = 'The student\'s email address, used to match the returned grade back to the right attempt.';
$string['privacy:metadata:tutoria_external:answer'] = 'The text of the student\'s essay answer, which is what the AI grades.';
