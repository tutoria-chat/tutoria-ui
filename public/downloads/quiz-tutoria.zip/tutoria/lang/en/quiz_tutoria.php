<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * English strings for quiz_tutoria.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Grading assistant (Tutoria)';
$string['compliance_notice'] = 'Under the CNE Guidelines for AI in Education, AI does not correct or assign grades on essay assessments. This assistant only organises answers and suggests formative feedback drafts — the assessment and the grade are the teacher’s responsibility.';
// Short label used as the report's node in the quiz Results navigation and
// dropdown. Moodle looks this up as get_string('tutoria','quiz_tutoria') — the
// BARE report name — on every quiz report page, so it must exist.
$string['tutoria'] = 'Grading assistant';
$string['tutoriareport'] = 'Grading assistant (Tutoria)';
$string['tutoria:view'] = 'Use Tutoria AI grading in a quiz';

// Report UI.
$string['intro'] = 'This assistant organises the essay answers in this quiz and prepares formative feedback drafts to speed up your correction. It does not assign grades — the assessment and the grade are always yours.';
$string['noessay'] = 'This quiz has no essay questions, so there is nothing for AI grading to do.';
$string['criteria'] = 'Correction criteria / rubric (you define)';
$string['criteria_placeholder'] = 'Describe what a good answer should contain (not grade instructions). E.g. it should state a clear thesis, give two supporting arguments, and cite a source. The AI checks each point and drafts feedback — you always assign the grade.';
$string['grade_button'] = 'Analyse with AI';
$string['apply_button'] = 'Save grades & feedback';
$string['col_student'] = 'Student';
$string['col_question'] = 'Question';
$string['col_mark'] = 'Grade (you decide)';
$string['col_comment'] = 'AI feedback draft';

// Settings.
$string['settings_setup'] = 'Tutoria connection';
$string['settings_setup_desc'] = 'Connect this Moodle to the Tutoria grading service. These are set once for the whole site — there is no per-course or per-quiz configuration. Copy all three values from the Tutoria dashboard: <strong>AVA setup → Grading assistant</strong>.';
$string['settings_baseurl'] = 'API base URL';
$string['settings_baseurl_desc'] = 'The Tutoria API address. Copy it from the Tutoria dashboard (AVA setup → Grading assistant).';
$string['settings_apikey'] = 'API key';
$string['settings_apikey_desc'] = 'Your institution\'s key (starts with tgk_), generated in the Tutoria dashboard (AVA setup → Grading assistant). It\'s shown only once — if you lose it, revoke it there and create a new one.';
$string['settings_universityid'] = 'Institution ID';
$string['settings_universityid_desc'] = 'Your institution\'s number in Tutoria, shown in the Tutoria dashboard (AVA setup → Grading assistant).';
$string['settings_timeout'] = 'Request timeout (seconds)';
$string['settings_timeout_desc'] = 'How long to wait for the Tutoria API on each call before giving up (1–300).';
$string['settings_defaultcriteria'] = 'Default grading guidance';
$string['settings_defaultcriteria_desc'] = 'Optional guidance sent with every grading job. Teachers can override it per run.';

// Errors (server).
$string['error_notconfigured'] = 'Tutoria AI grading is not configured yet. An administrator must set the API URL, key and institution id in the site settings.';
$string['error_startfailed'] = 'Could not start grading. {$a}';
$string['error_nojobid'] = 'The grading service accepted the request but returned no job id.';
$string['error_jobfailed'] = 'Grading failed. {$a}';
$string['error_pollfailed'] = 'Could not check grading progress. {$a}';
$string['error_transport'] = 'Could not reach the Tutoria service: {$a}';
$string['error_nosubmissions'] = 'There are no finished attempts with essay answers to grade.';
$string['error_baditems'] = 'Malformed grade data.';
$string['error_badaction'] = 'Unknown action.';
$string['error_unexpected'] = 'An unexpected error occurred.';
$string['error_nomark'] = 'No mark given.';
$string['error_attemptnotinquiz'] = 'That attempt does not belong to this quiz.';
$string['error_notallowed'] = 'You are not allowed to grade this student in this quiz.';
$string['error_attemptnotfinished'] = 'The attempt is not finished.';
$string['error_slotmissing'] = 'Question {$a} is not part of that attempt.';
$string['error_markrange'] = 'Mark {$a->mark} is outside the allowed range [{$a->min}–{$a->max}].';

// HTTP hints.
$string['httperr_401'] = 'The API key was rejected (401). Check it was pasted in full, or create a new key in the Tutoria dashboard (AVA setup → Grading assistant).';
$string['httperr_403'] = 'Not allowed (403): AI grading may not be enabled for this institution, or the key belongs to a different institution — check the Institution ID.';
$string['httperr_404'] = 'Course or institution not found (404). Check that the "institution id" and "API URL" in the Tutoria plugin settings point to the correct environment.';
$string['httperr_422'] = 'The grading job failed (422).';
$string['httperr_503'] = 'The grading service is not configured on the server (503).';
$string['httperr_generic'] = 'The grading service returned HTTP {$a}.';

// In-page how-to guide.
$string['help_title'] = 'How to use this assistant — step by step';
$string['help_steps_title'] = 'Step by step';
$string['help_step1'] = '(Optional) In “Correction criteria / rubric”, describe what a good answer should contain. Do not write grading instructions.';
$string['help_step2'] = 'Click “Analyse with AI” and wait for the “Grading in progress… X of Y” message to finish. It can take a few minutes — keep this page open.';
$string['help_step3'] = 'A table appears. Each row is one student’s answer to one question. Click “View answer” to read what the student wrote.';
$string['help_step4'] = 'Type the grade in the “Grade (you decide)” field and, if you like, edit the feedback draft.';
$string['help_step5'] = 'Click “Save grades & feedback” and confirm. Only rows with a grade are saved — you can grade a few at a time and save more than once.';
$string['help_step6'] = 'To check, open Results → Grades or the course gradebook. The student sees the grade and comment when reviewing their attempt.';
$string['help_columns_title'] = 'How to read each row of the table';
$string['help_col_student'] = 'Whose answer it is.';
$string['help_col_question'] = 'The question text, shortened. The full text is under “View answer”.';
$string['help_col_answer'] = 'Shows the full question and what the student wrote. “Open attempt” opens the student’s whole attempt in Moodle, in a new tab.';
$string['help_col_mark'] = 'Starts empty — the AI never suggests a grade. The number after the slash (e.g. / 10) is the question’s maximum mark.';
$string['help_col_comment'] = 'A comment for the student, drafted by the AI as a starting point. Edit or delete it freely: once saved, the student sees exactly what is in this field.';
$string['help_problems_title'] = 'Something went wrong?';
$string['help_problem_config'] = 'A message about the API key, access denied, or the plugin not being configured:';
$string['help_fix_config'] = 'that is a site setting, not your quiz. Tell your Moodle administrator — their step-by-step is on the Tutoria dashboard, under Configuração do AVA → Assistente de Correção.';
$string['help_problem_nostudents'] = '“No finished attempts…”:';
$string['help_fix_nostudents'] = 'no student has submitted yet. Only finished attempts are listed.';
$string['help_problem_rowerror'] = 'A row turned red after saving:';
$string['help_fix_rowerror'] = 'that row’s grade was not saved (the reason is shown under the grade — e.g. it is above the question’s maximum). The others were saved: fix the row and click “Save grades & feedback” again.';
$string['help_problem_slow'] = 'It took too long, or “Something went wrong” appeared:';
$string['help_fix_slow'] = 'click “Analyse with AI” again. Nothing reaches students until you click “Save grades & feedback”.';
$string['help_fullguide'] = 'Full illustrated guide (PDF, Portuguese) ↗';

// JS dynamic strings.
$string['js_collecting'] = 'Collecting essay answers…';
$string['js_nostudents'] = 'No finished attempts with essay answers were found.';
$string['js_starting'] = 'Sending answers for grading…';
$string['js_grading'] = 'Grading in progress…';
$string['js_gradingn'] = 'Grading in progress… {$a->processed} of {$a->total}';
$string['js_done'] = 'Done — {$a} answer(s) analysed. Review each, then set your grade and feedback.';
$string['js_applying'] = 'Applying grades…';
$string['js_applied'] = 'Applied {$a} grade(s).';
$string['js_applyerrors'] = 'Applied {$a->applied} grade(s); {$a->errors} could not be applied.';
$string['js_confirmapply'] = 'Save {$a} grade(s) and comment(s)? The grades are the ones you set.';
$string['js_nogrades'] = 'Enter at least one grade before saving.';
$string['js_error'] = 'Something went wrong. Please try again.';
$string['js_viewanswer'] = 'View answer';
$string['js_hideanswer'] = 'Hide answer';
$string['js_openattempt'] = 'Open attempt';
$string['js_questionlabel'] = 'Question';
$string['js_answerlabel'] = 'Student’s answer';
$string['js_noanswer'] = '(the student wrote nothing)';
$string['js_tablehint'] = 'Each row is one student’s answer to one question: click “View answer”, type the grade and edit the draft. Rows without a grade are not saved.';
$string['js_rowerror'] = 'Not saved: {$a}';

// Events (audit log — Reports → Logs).
$string['event_feedback_requested'] = 'AI feedback drafts requested';
$string['event_grades_confirmed'] = 'Grades confirmed by teacher';

// Privacy.
$string['privacy:metadata:tutoria_external'] = 'To grade essay answers with AI, answers and identifying information are sent to the external Tutoria service.';
$string['privacy:metadata:tutoria_external:name'] = 'The student\'s full name, so a teacher can recognise whose answer is being graded.';
$string['privacy:metadata:tutoria_external:studentid'] = 'The student\'s ID number (or username), used to match the returned grade back to the right attempt.';
$string['privacy:metadata:tutoria_external:email'] = 'The student\'s email address, used to match the returned grade back to the right attempt.';
$string['privacy:metadata:tutoria_external:answer'] = 'The text of the student\'s essay answer, which is what the AI grades.';

// Suggested-grade mode — ONLY for corporate training outside the MEC system.
// Tutoria turns it on per institution; universities and schools always stay in
// feedback mode (the AI never suggests a grade — CNE Guidelines).
$string['compliance_notice_score'] = 'Corporate training: the AI suggests a grade from the rubric, with the evidence for each criterion and a confidence level. A person checks and confirms every grade before it is saved — nothing is saved on its own.';
$string['intro_score'] = 'The assistant reads the essay answers in this quiz, suggests each grade from the rubric and drafts the feedback. Answers that need a human look come first, in the review queue.';
$string['needs_institution_key'] = 'Tutoria turned on suggested grades for this institution, but this Moodle still uses the old shared key, which only allows feedback. Ask the administrator to switch to the institution key (starts with tgk_) from the Tutoria dashboard.';
$string['panel_hint'] = 'Tip: on Moodle\'s "Manual grading" page a floating Tutoria window shows the draft for each answer, so you can grade without leaving it.';
$string['only_review'] = 'Show only the review queue';
$string['col_mark_score'] = 'Mark (suggested — check it)';
$string['col_confirm'] = 'Confirm';
$string['js_tablehintscore'] = 'The review queue comes first. Read the answer, adjust the mark if needed and tick "Confirm". Only confirmed rows are saved.';
$string['js_queuecount'] = '{$a->n} of {$a->total} answer(s) in the review queue.';
$string['help_score_step1'] = '(Optional, recommended) When editing each essay question, write the rubric in "Information for graders", with the points for each criterion. Without one, the AI builds criteria from the question and its reference answer.';
$string['help_score_step2'] = 'Click "Analyse with AI" and wait for "Grading in progress… X of Y" to finish. You can leave the page: the result is saved.';
$string['help_score_step3'] = 'The table shows the review queue first: low or medium confidence, a possible attempt to manipulate the grading, an empty answer, or a participant close to the pass mark.';
$string['help_score_step4'] = 'Review those rows: read the answer, adjust the mark and tick "Confirm". The others come ticked — untick any you want to leave for later.';
$string['help_score_step5'] = 'Click "Save grades & feedback" and confirm. Only confirmed rows with a mark are saved; the log records how many marks you changed.';
$string['help_score_step6'] = 'To check, open Results → Grades or the course gradebook. The participant sees the grade, the feedback and the criteria when reviewing the attempt.';
$string['help_col_mark_score'] = 'Starts with the AI-suggested mark (the sum of the points per criterion). Check and adjust it: the saved mark is always what is in this field.';
$string['criteria_rationale_label'] = 'Criteria:';
$string['conf_alta'] = 'high';
$string['conf_media'] = 'medium';
$string['conf_baixa'] = 'low';
$string['review_confianca_baixa'] = 'Low confidence';
$string['review_confianca_media'] = 'Medium confidence';
$string['review_possivel_manipulacao'] = 'Possible attempt to manipulate the grading';
$string['review_resposta_vazia'] = 'Empty answer';
$string['review_erro'] = 'Error while analysing';
$string['review_nao_avaliado'] = 'Not analysed';
$string['review_sem_criterios'] = 'No criteria to compute the mark';
$string['review_perto_da_aprovacao'] = 'Close to the pass mark';
$string['error_unknownjob'] = 'That grading job does not belong to this quiz.';

// Floating window on Moodle's manual grading page.
$string['panel_title'] = 'Grading assistant';
$string['panel_open'] = 'Grading assistant';
$string['panel_close'] = 'Close';
$string['panel_minimize'] = 'Minimise';
$string['panel_notice_feedback'] = 'The AI does not assign grades (CNE Guidelines). It only drafts the feedback — the grade is yours.';
$string['panel_notice_score'] = 'Grades suggested by the AI from the rubric. Check each one before saving.';
$string['panel_generate'] = 'Generate drafts for this quiz';
$string['panel_regenerate'] = 'Generate again';
$string['panel_criteria'] = 'Criteria / rubric (optional)';
$string['panel_nodrafts'] = 'No drafts for this quiz yet. Click "Generate drafts".';
$string['panel_nodraft_attempt'] = 'No draft for this attempt (only the attempt that counts for the grade is analysed).';
$string['panel_insert'] = 'Insert into comment';
$string['panel_inserted'] = 'Inserted. Review it and click Save in Moodle.';
$string['panel_usemark'] = 'Use suggested mark';
$string['panel_markused'] = 'Mark filled in. Check it and click Save in Moodle.';
$string['panel_insertall'] = 'Insert all comments on this page';
$string['panel_fillmarks'] = 'Fill marks without alerts';
$string['panel_insertedn'] = '{$a->n} comment(s) inserted; {$a->skipped} already had text and were kept.';
$string['panel_filledn'] = '{$a} mark(s) filled in.';
$string['panel_suggested'] = 'Suggested mark: {$a->mark} / {$a->max}';
$string['panel_confidence'] = 'Confidence {$a}';
$string['panel_rationale'] = 'See criteria and evidence';
$string['panel_noeditor'] = 'No editable comment field on this page.';
$string['panel_savehint'] = 'Nothing is saved until you click Save in Moodle.';
$string['panel_question'] = 'Question {$a}';
$string['panel_goto'] = 'Go to this answer on the page';
$string['panel_needskey'] = 'Suggested grades are on, but this Moodle uses the old key. Ask the administrator for the institution key (tgk_).';
$string['panel_running'] = 'Generating drafts…';
$string['panel_onpage'] = '{$a->n} of {$a->total} answer(s) on this page have a draft.';
$string['panel_reviewonly'] = 'Fills only high-confidence answers without alerts, and only where the mark is empty.';
$string['panel_replacecomment'] = 'This comment already has text. Replace it with the AI draft?';

// Privacy (local tables) and cleanup.
$string['privacy:metadata:quiz_tutoria_drafts'] = 'AI drafts saved per attempt and question until the teacher uses them. They are not grades.';
$string['privacy:metadata:quiz_tutoria_drafts:userid'] = 'The student the answer belongs to.';
$string['privacy:metadata:quiz_tutoria_drafts:attemptid'] = 'The quiz attempt.';
$string['privacy:metadata:quiz_tutoria_drafts:feedback'] = 'The feedback draft written by the AI.';
$string['privacy:metadata:quiz_tutoria_drafts:suggestedmark'] = 'The AI-suggested mark (corporate training only).';
$string['privacy:metadata:quiz_tutoria_drafts:rationale'] = 'The points and evidence for each criterion (corporate training only).';
$string['privacy:metadata:quiz_tutoria_drafts:timecreated'] = 'When the draft was generated.';
$string['privacy:metadata:quiz_tutoria_jobs'] = 'AI grading runs started by a teacher.';
$string['privacy:metadata:quiz_tutoria_jobs:userid'] = 'The teacher who started the run.';
$string['privacy:metadata:quiz_tutoria_jobs:timecreated'] = 'When the run was started.';
$string['task_cleanup'] = 'Delete old grading assistant drafts';
$string['settings_retentiondays'] = 'Keep drafts for (days)';
$string['settings_retentiondays_desc'] = 'AI drafts older than this are deleted automatically (grades and comments already saved are not affected).';
$string['panel_dock'] = 'Dock to the side';
$string['panel_undock'] = 'Float (or drag the title bar)';
