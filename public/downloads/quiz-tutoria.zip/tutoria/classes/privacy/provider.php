<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Privacy provider for quiz_tutoria.
 *
 * The plugin stores no personal data in Moodle. It transmits essay answers and
 * identifying details to the external Tutoria service to produce grades, which
 * is declared here.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace quiz_tutoria\privacy;

use core_privacy\local\metadata\collection;


/**
 * Declares the external data flow to Tutoria.
 */
class provider implements \core_privacy\local\metadata\provider {

    /**
     * Describe the personal data that leaves Moodle for the Tutoria service.
     *
     * @param collection $collection the collection to add to.
     * @return collection
     */
    public static function get_metadata(collection $collection): collection {
        $collection->add_external_location_link(
            'tutoria_external',
            [
                'name'      => 'privacy:metadata:tutoria_external:name',
                'studentid' => 'privacy:metadata:tutoria_external:studentid',
                'email'     => 'privacy:metadata:tutoria_external:email',
                'answer'    => 'privacy:metadata:tutoria_external:answer',
            ],
            'privacy:metadata:tutoria_external'
        );
        return $collection;
    }
}
