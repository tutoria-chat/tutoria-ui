<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Privacy provider for quiz_tutoria.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace quiz_tutoria\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\approved_userlist;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\transform;
use core_privacy\local\request\userlist;
use core_privacy\local\request\writer;

/**
 * Declares the data sent to Tutoria and the AI drafts kept in Moodle, and exports
 * and deletes those drafts on request (LGPD / GDPR).
 */
class provider implements
        \core_privacy\local\metadata\provider,
        \core_privacy\local\request\plugin\provider,
        \core_privacy\local\request\core_userlist_provider {

    /**
     * Describe the personal data.
     *
     * @param collection $collection the collection to add to.
     * @return collection
     */
    public static function get_metadata(collection $collection): collection {
        $collection->add_external_location_link(
            'tutoria_external',
            [
                'name'      => 'privacy:metadata:tutoria_external:name',
                'studentid' => 'privacy:metadata:tutoria_external:studentid',
                'email'     => 'privacy:metadata:tutoria_external:email',
                'answer'    => 'privacy:metadata:tutoria_external:answer',
            ],
            'privacy:metadata:tutoria_external'
        );
        $collection->add_database_table('quiz_tutoria_drafts', [
            'userid'        => 'privacy:metadata:quiz_tutoria_drafts:userid',
            'attemptid'     => 'privacy:metadata:quiz_tutoria_drafts:attemptid',
            'feedback'      => 'privacy:metadata:quiz_tutoria_drafts:feedback',
            'suggestedmark' => 'privacy:metadata:quiz_tutoria_drafts:suggestedmark',
            'rationale'     => 'privacy:metadata:quiz_tutoria_drafts:rationale',
            'timecreated'   => 'privacy:metadata:quiz_tutoria_drafts:timecreated',
        ], 'privacy:metadata:quiz_tutoria_drafts');
        $collection->add_database_table('quiz_tutoria_jobs', [
            'userid'      => 'privacy:metadata:quiz_tutoria_jobs:userid',
            'timecreated' => 'privacy:metadata:quiz_tutoria_jobs:timecreated',
        ], 'privacy:metadata:quiz_tutoria_jobs');
        return $collection;
    }

    /** SQL joining a draft/job's quiz to its module context. */
    private const CONTEXT_JOIN = "JOIN {course_modules} cm ON cm.instance = t.quizid
                                  JOIN {modules} m ON m.id = cm.module AND m.name = 'quiz'
                                  JOIN {context} ctx ON ctx.instanceid = cm.id AND ctx.contextlevel = :modlevel";

    /**
     * Quiz contexts holding data about this user.
     *
     * @param int $userid the user.
     * @return contextlist
     */
    public static function get_contexts_for_userid(int $userid): contextlist {
        $list = new contextlist();
        foreach (['quiz_tutoria_drafts', 'quiz_tutoria_jobs'] as $table) {
            $list->add_from_sql("SELECT ctx.id FROM {{$table}} t " . self::CONTEXT_JOIN . " WHERE t.userid = :userid",
                ['modlevel' => CONTEXT_MODULE, 'userid' => $userid]);
        }
        return $list;
    }

    /**
     * Users with data in a context.
     *
     * @param userlist $userlist the list to fill.
     */
    public static function get_users_in_context(userlist $userlist) {
        $context = $userlist->get_context();
        if (!$context instanceof \context_module) {
            return;
        }
        foreach (['quiz_tutoria_drafts', 'quiz_tutoria_jobs'] as $table) {
            $userlist->add_from_sql('userid', "SELECT t.userid FROM {{$table}} t " . self::CONTEXT_JOIN .
                " WHERE ctx.id = :ctxid", ['modlevel' => CONTEXT_MODULE, 'ctxid' => $context->id]);
        }
    }

    /**
     * Export the user's drafts and jobs.
     *
     * @param approved_contextlist $contextlist the approved contexts.
     */
    public static function export_user_data(approved_contextlist $contextlist) {
        global $DB;
        $userid = (int) $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            $quizid = self::quiz_for_context($context);
            if (!$quizid) {
                continue;
            }
            $drafts = $DB->get_records('quiz_tutoria_drafts', ['quizid' => $quizid, 'userid' => $userid], 'id');
            $jobs = $DB->get_records('quiz_tutoria_jobs', ['quizid' => $quizid, 'userid' => $userid], 'id');
            if (!$drafts && !$jobs) {
                continue;
            }
            writer::with_context($context)->export_data(
                [get_string('pluginname', 'quiz_tutoria')],
                (object) [
                    'drafts' => array_values(array_map(function($d) {
                        return (object) [
                            'attemptid'     => $d->attemptid,
                            'slot'          => $d->slot,
                            'feedback'      => $d->feedback,
                            'suggestedmark' => $d->suggestedmark,
                            'rationale'     => $d->rationale,
                            'timecreated'   => transform::datetime($d->timecreated),
                        ];
                    }, $drafts)),
                    'jobs' => array_values(array_map(function($j) {
                        return (object) ['jobid' => $j->jobid, 'timecreated' => transform::datetime($j->timecreated)];
                    }, $jobs)),
                ]
            );
        }
    }

    /**
     * Delete everything in a context.
     *
     * @param \context $context the context.
     */
    public static function delete_data_for_all_users_in_context(\context $context) {
        global $DB;
        $quizid = self::quiz_for_context($context);
        if ($quizid) {
            $DB->delete_records('quiz_tutoria_drafts', ['quizid' => $quizid]);
            $DB->delete_records('quiz_tutoria_jobs', ['quizid' => $quizid]);
        }
    }

    /**
     * Delete one user's data in the approved contexts.
     *
     * @param approved_contextlist $contextlist the approved contexts.
     */
    public static function delete_data_for_user(approved_contextlist $contextlist) {
        global $DB;
        $userid = (int) $contextlist->get_user()->id;
        foreach ($contextlist->get_contexts() as $context) {
            $quizid = self::quiz_for_context($context);
            if ($quizid) {
                $DB->delete_records('quiz_tutoria_drafts', ['quizid' => $quizid, 'userid' => $userid]);
                $DB->delete_records('quiz_tutoria_jobs', ['quizid' => $quizid, 'userid' => $userid]);
            }
        }
    }

    /**
     * Delete several users' data in one context.
     *
     * @param approved_userlist $userlist the approved users.
     */
    public static function delete_data_for_users(approved_userlist $userlist) {
        global $DB;
        $quizid = self::quiz_for_context($userlist->get_context());
        $userids = $userlist->get_userids();
        if (!$quizid || !$userids) {
            return;
        }
        [$insql, $params] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED);
        $params['quizid'] = $quizid;
        $DB->delete_records_select('quiz_tutoria_drafts', "quizid = :quizid AND userid {$insql}", $params);
        $DB->delete_records_select('quiz_tutoria_jobs', "quizid = :quizid AND userid {$insql}", $params);
    }

    /**
     * The quiz id behind a module context, or 0.
     *
     * @param \context $context the context.
     * @return int
     */
    private static function quiz_for_context(\context $context): int {
        if (!$context instanceof \context_module) {
            return 0;
        }
        $cm = get_coursemodule_from_id('quiz', $context->instanceid);
        return $cm ? (int) $cm->instance : 0;
    }
}
