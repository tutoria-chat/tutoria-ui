<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

namespace quiz_tutoria\local;



/**
 * Thin client for the Tutoria external grading API.
 *
 * Contract (unchanged from the existing integration):
 *   POST {base}/api/external/grading/{universityId}/{courseId}?criteria=&coursename=
 *        body: submissions JSON  → 202 {jobId}
 *   GET  {base}/api/external/grading/{universityId}/{courseId}/{jobId}
 *        → 202 {status,processed,total} while running
 *        → 200 text/csv when done  (matricula,email,cmid,slot,comentario)
 *          The AI returns no grade — the teacher assigns it (CNE Guidelines).
 *        → 422 {status:"failed"} on failure
 *
 * Every call is bounded by a timeout and logged, so a slow or unreachable API
 * fails fast with a clear message instead of tying up a PHP worker silently.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class client {

    /** @var string API base URL, no trailing slash. */
    protected $baseurl;

    /** @var string The X-Api-Key value. */
    protected $apikey;

    /** @var int Tutoria institution id this Moodle maps to. */
    protected $universityid;

    /** @var int Per-request timeout in seconds. */
    protected $timeout;

    /**
     * Build a client from the site configuration, or throw if it is incomplete.
     *
     * @return self
     * @throws \moodle_exception when the plugin has not been configured.
     */
    public static function from_config(): self {
        $baseurl      = get_config('quiz_tutoria', 'baseurl');
        $apikey       = get_config('quiz_tutoria', 'apikey');
        $universityid = get_config('quiz_tutoria', 'universityid');
        $timeout      = (int) get_config('quiz_tutoria', 'timeout');

        if (empty($baseurl) || empty($apikey) || $universityid === false || $universityid === ''
                || (int) $universityid <= 0) {
            throw new \moodle_exception('error_notconfigured', 'quiz_tutoria');
        }

        $client = new self();
        $client->baseurl      = rtrim($baseurl, '/');
        $client->apikey       = $apikey;
        $client->universityid = (int) $universityid;
        $client->timeout      = ($timeout > 0 && $timeout <= 300) ? $timeout : 30;
        return $client;
    }

    /**
     * Start a grading job.
     *
     * @param int $courseid the Moodle course id (the Tutoria course is provisioned from it).
     * @param string $coursename the Moodle course full name (names an auto-created Tutoria course).
     * @param string $payloadjson the submissions JSON.
     * @param string $criteria optional grading guidance.
     * @return string the job id.
     * @throws \moodle_exception on transport failure or a non-2xx response.
     */
    public function start_job(int $courseid, string $coursename, string $payloadjson, string $criteria): string {
        $query = ['coursename' => $coursename];
        if ($criteria !== '') {
            $query['criteria'] = $criteria;
        }
        $url = $this->endpoint($courseid) . '?' . http_build_query($query);

        [$httpcode, $body, $ctype] = $this->request('POST', $url, $payloadjson);

        if ($httpcode < 200 || $httpcode >= 300) {
            throw new \moodle_exception('error_startfailed', 'quiz_tutoria', '',
                $this->friendly_http($httpcode));
        }

        $data = json_decode($body, true);
        $jobid = $data['jobId'] ?? ($data['jobid'] ?? null);
        if (empty($jobid)) {
            $this->log("start_job: 2xx with no jobId in response: " . substr($body, 0, 500), true);
            throw new \moodle_exception('error_nojobid', 'quiz_tutoria');
        }
        return (string) $jobid;
    }

    /**
     * Poll a grading job.
     *
     * @param int $courseid the Moodle course id.
     * @param string $jobid the job id.
     * @return array{done: bool, csv: ?string, processed: int, total: int}
     * @throws \moodle_exception on transport failure or a failed job (422).
     */
    public function poll_job(int $courseid, string $jobid): array {
        $url = $this->endpoint($courseid) . '/' . rawurlencode($jobid);

        [$httpcode, $body, $ctype] = $this->request('GET', $url, null);

        if ($httpcode === 200) {
            return ['done' => true, 'csv' => $body, 'processed' => 0, 'total' => 0];
        }
        if ($httpcode === 202) {
            $data = json_decode($body, true) ?: [];
            return [
                'done'      => false,
                'csv'       => null,
                'processed' => (int) ($data['processed'] ?? 0),
                'total'     => (int) ($data['total'] ?? 0),
            ];
        }
        if ($httpcode === 422) {
            $data = json_decode($body, true) ?: [];
            throw new \moodle_exception('error_jobfailed', 'quiz_tutoria', '',
                (string) ($data['message'] ?? ''));
        }

        throw new \moodle_exception('error_pollfailed', 'quiz_tutoria', '', $this->friendly_http($httpcode));
    }

    /**
     * The grading endpoint for a course, without the trailing job id / query.
     *
     * @param int $courseid Moodle course id.
     * @return string
     */
    protected function endpoint(int $courseid): string {
        return $this->baseurl . '/api/external/grading/'
            . rawurlencode((string) $this->universityid) . '/' . rawurlencode((string) $courseid);
    }

    /**
     * Perform one HTTP request with a bounded timeout, returning the raw result.
     *
     * @param string $method GET or POST.
     * @param string $url absolute URL.
     * @param string|null $body request body for POST.
     * @return array{0:int,1:string,2:string} [http code, body, content-type]
     * @throws \moodle_exception on a transport-level failure.
     */
    protected function request(string $method, string $url, ?string $body): array {
        global $CFG;
        require_once($CFG->libdir . '/filelib.php'); // Moodle \curl (guarded, cheap).

        $curl = new \curl();
        $curl->setHeader('X-Api-Key: ' . $this->apikey);
        $options = [
            'CURLOPT_TIMEOUT'        => $this->timeout,
            'CURLOPT_CONNECTTIMEOUT' => min(15, $this->timeout),
        ];

        if ($method === 'POST') {
            $curl->setHeader('Content-Type: application/json');
            $response = $curl->post($url, (string) $body, $options);
        } else {
            $response = $curl->get($url, [], $options);
        }

        if ($curl->errno) {
            $this->log("{$method} {$url} — transport error {$curl->errno}: {$curl->error}", true);
            throw new \moodle_exception('error_transport', 'quiz_tutoria', '', $curl->error);
        }

        $info     = $curl->get_info();
        $httpcode = isset($info['http_code']) ? (int) $info['http_code'] : 0;
        $ctype    = $info['content_type'] ?? 'application/json';

        if ($httpcode >= 400) {
            $this->log("{$method} {$url} — HTTP {$httpcode}: " . substr((string) $response, 0, 500), true);
        }
        return [$httpcode, (string) $response, $ctype];
    }

    /**
     * Map an HTTP status from the Tutoria API to a short human hint.
     *
     * @param int $code HTTP status code.
     * @return string
     */
    protected function friendly_http(int $code): string {
        switch ($code) {
            case 401: return get_string('httperr_401', 'quiz_tutoria');
            case 403: return get_string('httperr_403', 'quiz_tutoria');
            case 404: return get_string('httperr_404', 'quiz_tutoria');
            case 422: return get_string('httperr_422', 'quiz_tutoria');
            case 503: return get_string('httperr_503', 'quiz_tutoria');
            default:  return get_string('httperr_generic', 'quiz_tutoria', $code);
        }
    }

    /**
     * Write a line to the Moodle log. Errors are always recorded; other lines
     * only when developer debugging is on.
     *
     * @param string $message the message.
     * @param bool $iserror whether this is an error worth always logging.
     */
    protected function log(string $message, bool $iserror = false): void {
        if ($iserror) {
            debugging('quiz_tutoria: ' . $message, DEBUG_NORMAL);
            // Also to the server error log, so failures are visible without dev mode.
            error_log('quiz_tutoria: ' . $message);
        } else {
            debugging('quiz_tutoria: ' . $message, DEBUG_DEVELOPER);
        }
    }
}
