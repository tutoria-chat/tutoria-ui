<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

namespace quiz_tutoria\local;

use question_engine;

/**
 * Reads essay answers from one quiz and writes manual grades back.
 *
 * Pure question-engine — the same path a teacher's manual grading takes, so
 * grades land on the real question attempts and the gradebook, with nothing
 * bolted on beside them. Everything here is scoped to a single quiz, and — when
 * the quiz uses separate groups and the teacher cannot access all groups — to
 * the set of students that teacher is allowed to see.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class grader {

    /** Moodle's QUIZ_ATTEMPTFIRST grade method. Hard-coded to avoid loading mod/quiz/lib.php. */
    const GRADEMETHOD_FIRST = 3;

    /** @var \stdClass The quiz record. */
    protected $quiz;

    /**
     * @var int[]|null User ids the caller may act on, or null for "no restriction".
     * An empty array means "restricted to nobody" (separate groups, no visible group).
     */
    protected $alloweduserids;

    /**
     * @param \stdClass $quiz the quiz database record.
     * @param int[]|null $alloweduserids restrict to these users, or null for all.
     */
    public function __construct(\stdClass $quiz, ?array $alloweduserids = null) {
        $this->quiz = $quiz;
        $this->alloweduserids = $alloweduserids;
    }

    /**
     * Whether this quiz can contain essay questions to grade.
     *
     * Covers both directly-placed essay questions and quizzes that draw questions
     * randomly from a category (whose draw may be an essay, resolved per attempt).
     * A false result means there is genuinely nothing for AI grading to do.
     *
     * @return bool
     */
    public function has_essay_questions(): bool {
        global $DB;

        // Directly placed essay questions (4.x/5.x question bank).
        $directsql = "SELECT 1
                        FROM {quiz_slots} qs
                        JOIN {question_references} qr
                             ON qr.component = 'mod_quiz'
                            AND qr.questionarea = 'slot'
                            AND qr.itemid = qs.id
                        JOIN {question_bank_entries} qbe ON qbe.id = qr.questionbankentryid
                        JOIN {question_versions} qv ON qv.questionbankentryid = qbe.id
                        JOIN {question} q ON q.id = qv.questionid
                       WHERE qs.quizid = :quizid AND q.qtype = 'essay'";
        if ($DB->record_exists_sql($directsql, ['quizid' => $this->quiz->id])) {
            return true;
        }

        // Random slots may draw an essay; allow the report so the actual answers
        // decide, rather than blocking with a false "no essay questions".
        $randomsql = "SELECT 1
                        FROM {quiz_slots} qs
                        JOIN {question_set_references} qsr
                             ON qsr.component = 'mod_quiz'
                            AND qsr.questionarea = 'slot'
                            AND qsr.itemid = qs.id
                       WHERE qs.quizid = :quizid";
        return $DB->record_exists_sql($randomsql, ['quizid' => $this->quiz->id]);
    }

    /**
     * The finished, non-preview attempts to grade — one per user, choosing the
     * attempt that counts for the quiz grade method (first attempt when the method
     * is "first attempt", otherwise the most recent). Restricted to the allowed
     * user set when separate groups apply.
     *
     * @return \stdClass[]
     */
    protected function finished_attempts(): array {
        global $DB;

        $where = 'quiz = :quizid AND state = :state AND preview = 0';
        $params = ['quizid' => $this->quiz->id, 'state' => 'finished'];

        if ($this->alloweduserids !== null) {
            if (empty($this->alloweduserids)) {
                return [];
            }
            [$insql, $inparams] = $DB->get_in_or_equal($this->alloweduserids, SQL_PARAMS_NAMED, 'au');
            $where .= " AND userid {$insql}";
            $params += $inparams;
        }

        // Pick the grade-defining attempt per user: oldest for "first attempt",
        // newest otherwise. collect_submissions() keeps the first row seen per user.
        $isfirst = ((int) ($this->quiz->grademethod ?? 0)) === self::GRADEMETHOD_FIRST;
        $order = $isfirst ? 'userid ASC, attempt ASC' : 'userid ASC, attempt DESC';

        return $DB->get_records_select('quiz_attempts', $where, $params, $order);
    }

    /**
     * Collect every essay answer to grade, grouped by student, in the shape the
     * Tutoria grading API expects.
     *
     * @return array a list of student objects with their essay questions.
     */
    public function collect_submissions(): array {
        $out = [];
        $seenusers = [];

        foreach ($this->finished_attempts() as $attempt) {
            if (isset($seenusers[$attempt->userid])) {
                continue;
            }

            $user = \core_user::get_user($attempt->userid);
            if (!$user) {
                continue;
            }

            $quba = question_engine::load_questions_usage_by_activity($attempt->uniqueid);
            $questions = [];

            foreach ($quba->get_slots() as $slot) {
                $question = $quba->get_question($slot, false);
                if ($question->get_type_name() !== 'essay') {
                    continue;
                }

                $qa      = $quba->get_question_attempt($slot);
                $maxmark = (float) $qa->get_max_mark();
                $mark    = $qa->get_mark();

                $questions[] = [
                    'slot'          => (int) $slot,
                    'attemptid'     => (int) $attempt->id,
                    'question_text' => self::plain($question->questiontext, (int) $question->questiontextformat),
                    'answer'        => (string) ($qa->get_response_summary() ?? ''),
                    'feedback'      => self::plain($question->generalfeedback, (int) $question->generalfeedbackformat),
                    'max_mark'      => $maxmark,
                    'current_mark'  => $mark === null ? null : round((float) $mark, 2),
                    'min_grade'     => $qa->get_min_fraction() * $maxmark,
                    'max_grade'     => $qa->get_max_fraction() * $maxmark,
                ];
            }

            if (!$questions) {
                continue;
            }

            $seenusers[$attempt->userid] = true;
            $out[] = [
                'attempt'   => (int) $attempt->attempt,
                'name'      => fullname($user),
                'id'        => ($user->idnumber !== '' ? $user->idnumber : $user->username),
                'email'     => $user->email,
                'questions' => $questions,
            ];
        }

        return $out;
    }

    /**
     * Apply a set of grades in one transaction.
     *
     * Each item is validated: the attempt must belong to THIS quiz, be finished,
     * be for a student the caller may act on, have the slot, and the mark must be
     * within the question's allowed range. Invalid items are reported and skipped
     * rather than aborting the whole batch.
     *
     * @param array $items list of ['attemptid'=>int,'slot'=>int,'mark'=>float,'comment'=>string]
     * @return array{applied:int, errors:array<int,string>}
     */
    public function apply_grades(array $items): array {
        global $DB;

        $applied = 0;
        $errors = [];
        $touchedusers = [];

        $transaction = $DB->start_delegated_transaction();

        foreach ($items as $i => $item) {
            $attemptid = (int) ($item['attemptid'] ?? 0);
            $slot      = (int) ($item['slot'] ?? 0);
            $mark      = isset($item['mark']) ? (float) $item['mark'] : null;
            $comment   = (string) ($item['comment'] ?? '');

            if ($mark === null) {
                $errors[$i] = get_string('error_nomark', 'quiz_tutoria');
                continue;
            }

            $attempt = $DB->get_record('quiz_attempts', ['id' => $attemptid]);
            if (!$attempt || (int) $attempt->quiz !== (int) $this->quiz->id) {
                $errors[$i] = get_string('error_attemptnotinquiz', 'quiz_tutoria');
                continue;
            }
            if ($this->alloweduserids !== null
                    && !in_array((int) $attempt->userid, $this->alloweduserids, true)) {
                // Separate groups: never write to a student outside the caller's groups.
                $errors[$i] = get_string('error_notallowed', 'quiz_tutoria');
                continue;
            }
            if ($attempt->state !== 'finished') {
                $errors[$i] = get_string('error_attemptnotfinished', 'quiz_tutoria');
                continue;
            }

            $quba = question_engine::load_questions_usage_by_activity($attempt->uniqueid);
            if (!in_array($slot, $quba->get_slots(), true)) {
                $errors[$i] = get_string('error_slotmissing', 'quiz_tutoria', $slot);
                continue;
            }

            $qa  = $quba->get_question_attempt($slot);
            $max = $qa->get_max_fraction() * $qa->get_max_mark();
            $min = $qa->get_min_fraction() * $qa->get_max_mark();
            if ($mark > $max || $mark < $min) {
                $errors[$i] = get_string('error_markrange', 'quiz_tutoria',
                    (object) ['mark' => $mark, 'min' => $min, 'max' => $max]);
                continue;
            }

            $quba->manual_grade($slot, $comment, $mark, FORMAT_HTML);
            question_engine::save_questions_usage_by_activity($quba);

            $update = new \stdClass();
            $update->id           = $attempt->id;
            $update->timemodified = time();
            $update->sumgrades    = $quba->get_total_mark();
            $DB->update_record('quiz_attempts', $update);

            $touchedusers[$attempt->userid] = true;
            $applied++;
        }

        $transaction->allow_commit();

        foreach (array_keys($touchedusers) as $userid) {
            $this->recompute_final_grade((int) $userid);
        }

        return ['applied' => $applied, 'errors' => $errors];
    }

    /**
     * Recompute a user's final quiz grade in the gradebook.
     *
     * @param int $userid the user id.
     */
    protected function recompute_final_grade(int $userid): void {
        global $CFG, $DB;

        if (class_exists('\mod_quiz\quiz_settings')) {
            $calculator = \mod_quiz\quiz_settings::create($this->quiz->id)->get_grade_calculator();
            if (method_exists($calculator, 'recompute_final_grade')) {
                // Signature is recompute_final_grade(?int $userid = null, ...) — pass the id.
                $calculator->recompute_final_grade($userid);
                return;
            }
        }

        // Fallback for cores older than the plugin's 4.2 minimum.
        require_once($CFG->dirroot . '/mod/quiz/locallib.php');
        if (function_exists('quiz_save_best_grade')) {
            quiz_save_best_grade($this->quiz, $userid);
        }
    }

    /**
     * Convert an HTML question field to plain text for display and for the AI
     * payload — filters off so no pluginfile rewriting or filter side effects.
     *
     * @param string|null $html raw field content.
     * @param int $format one of the FORMAT_* constants.
     * @return string
     */
    protected static function plain(?string $html, int $format): string {
        if ($html === null || $html === '') {
            return '';
        }
        $html = str_replace('@@PLUGINFILE@@/', '', $html);
        return trim(html_to_text(format_text($html, $format, ['filter' => false]), 0, false));
    }
}
