<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

namespace quiz_tutoria\local;

/**
 * Which kind of help the assistant gives this site — decided by Tutoria, never here.
 *
 *   feedback (default) — feedback drafts only; the AI never suggests a grade. This is
 *            the only mode for institutions under MEC/CNE (CNE Guidelines for AI in
 *            Education forbid AI grade suggestions on essays, even as a draft).
 *   score    — corporate training outside the MEC system: the AI also suggests a
 *            grade from the rubric, with evidence and confidence; a person confirms.
 *
 * Tutoria only reports score for an institution a Tutoria admin set up as corporate,
 * and only to that institution's own API key. Even then this class only changes
 * labels: a suggested grade appears only when the result itself carries one, which
 * the server produces only in score mode.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class mode {

    /** Feedback drafts only, never a grade. */
    const FEEDBACK = 'feedback';

    /** Suggested grades for a person to confirm (corporate only). */
    const SCORE = 'score';

    /** Seconds the mode read from the API is trusted before asking again. */
    const TTL = 600;

    /**
     * The current mode, from a short cache or the API. Falls back to the last known
     * value when the API cannot be reached, and to feedback when nothing is known.
     *
     * @param bool $refresh skip the cache.
     * @return array{gradingmode: string, needsinstitutionkey: bool}
     */
    public static function get(bool $refresh = false): array {
        $cached = (string) get_config('quiz_tutoria', 'gradingmode_cache');
        $checked = (int) get_config('quiz_tutoria', 'gradingmode_checkedat');
        $needskey = (bool) get_config('quiz_tutoria', 'gradingmode_needskey');

        if (!$refresh && $cached !== '' && (time() - $checked) < self::TTL) {
            return ['gradingmode' => self::normalize($cached), 'needsinstitutionkey' => $needskey];
        }

        try {
            $config = client::from_config()->get_config();
            set_config('gradingmode_cache', $config['gradingmode'], 'quiz_tutoria');
            set_config('gradingmode_checkedat', time(), 'quiz_tutoria');
            set_config('gradingmode_needskey', $config['needsinstitutionkey'] ? 1 : 0, 'quiz_tutoria');
            return $config;
        } catch (\Throwable $e) {
            // An older API without /config, or a network hiccup: keep the last answer.
            debugging('quiz_tutoria: could not read the grading mode: ' . $e->getMessage(), DEBUG_DEVELOPER);
            return ['gradingmode' => self::normalize($cached), 'needsinstitutionkey' => $needskey];
        }
    }

    /**
     * Whether this site is in score mode.
     *
     * @return bool
     */
    public static function is_score(): bool {
        return self::get()['gradingmode'] === self::SCORE;
    }

    /**
     * Anything unknown is feedback.
     *
     * @param string|null $value raw value.
     * @return string
     */
    public static function normalize(?string $value): string {
        return $value === self::SCORE ? self::SCORE : self::FEEDBACK;
    }

    /**
     * Forget the cached mode (after the admin changes the API key or institution).
     */
    public static function reset(): void {
        unset_config('gradingmode_cache', 'quiz_tutoria');
        unset_config('gradingmode_checkedat', 'quiz_tutoria');
        unset_config('gradingmode_needskey', 'quiz_tutoria');
    }
}
