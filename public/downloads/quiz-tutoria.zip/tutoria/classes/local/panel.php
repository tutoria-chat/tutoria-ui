<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

namespace quiz_tutoria\local;

use moodle_url;

/**
 * The floating assistant panel shown on Moodle's own manual grading pages, so a
 * teacher grading there sees the AI drafts beside each answer without switching
 * to the Tutoria tab.
 *
 * Pages: the quiz "Manual grading" report (report.php?mode=grading) and the
 * single-question "Make comment or override mark" page (comment.php).
 *
 * The panel only FILLS Moodle's form fields (comment, and in score mode the mark
 * when the teacher clicks "use suggested grade"); the grade is saved only when the
 * teacher clicks Moodle's own Save button.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class panel {

    /** Strings the panel JS needs. */
    const STRINGS = [
        'panel_title', 'panel_open', 'panel_dock', 'panel_undock', 'panel_close', 'panel_minimize', 'panel_notice_feedback',
        'panel_notice_score', 'panel_generate', 'panel_regenerate', 'panel_criteria',
        'panel_nodrafts', 'panel_nodraft_attempt', 'panel_insert', 'panel_inserted', 'panel_usemark',
        'panel_markused', 'panel_insertall', 'panel_fillmarks', 'panel_insertedn', 'panel_filledn',
        'panel_suggested', 'panel_confidence', 'panel_rationale', 'panel_noeditor', 'panel_savehint',
        'panel_question', 'panel_goto', 'panel_needskey', 'panel_running', 'panel_onpage',
        'panel_reviewonly', 'panel_replacecomment', 'js_starting', 'js_grading', 'js_gradingn', 'js_error', 'js_nostudents',
        'conf_alta', 'conf_media', 'conf_baixa',
        'review_confianca_baixa', 'review_confianca_media', 'review_possivel_manipulacao',
        'review_resposta_vazia', 'review_erro', 'review_nao_avaliado', 'review_sem_criterios',
        'review_perto_da_aprovacao', 'criteria_rationale_label',
    ];

    /**
     * The panel's container HTML for the current page, or '' when this page does
     * not get the panel. Also queues the panel script.
     *
     * @return string
     */
    public static function render_for_page(): string {
        global $PAGE;

        try {
            if (!self::is_grading_page()) {
                return '';
            }
            $cm = $PAGE->cm;
            if (empty($cm) || $cm->modname !== 'quiz') {
                return '';
            }
            $context = \context_module::instance($cm->id);
            if (!has_capability('quiz/tutoria:view', $context)) {
                return '';
            }
            if (!self::is_configured()) {
                return '';
            }

            $strings = [];
            foreach (self::STRINGS as $key) {
                $strings[$key] = get_string($key, 'quiz_tutoria');
            }

            $PAGE->requires->js(new moodle_url('/mod/quiz/report/tutoria/js/panel.js'));

            return \html_writer::div('', 'quiz-tutoria-panel-root', [
                'id'           => 'quiz-tutoria-panel-root',
                'data-cmid'    => $cm->id,
                'data-sesskey' => sesskey(),
                'data-ajaxurl' => (new moodle_url('/mod/quiz/report/tutoria/ajax.php'))->out(false),
                'data-reporturl' => (new moodle_url('/mod/quiz/report.php', ['id' => $cm->id, 'mode' => 'tutoria']))->out(false),
                'data-defaultcriteria' => (string) get_config('quiz_tutoria', 'defaultcriteria'),
                'data-strings' => json_encode($strings),
            ]);
        } catch (\Throwable $e) {
            // Never break Moodle's grading page because of the assistant.
            debugging('quiz_tutoria panel: ' . $e->getMessage(), DEBUG_DEVELOPER);
            return '';
        }
    }

    /**
     * Whether the current page is one of Moodle's manual grading pages.
     *
     * @return bool
     */
    protected static function is_grading_page(): bool {
        global $PAGE;
        $pagetype = (string) $PAGE->pagetype;
        if ($pagetype === 'mod-quiz-comment') {
            return true;
        }
        if ($pagetype === 'mod-quiz-report') {
            return optional_param('mode', '', PARAM_ALPHA) === 'grading';
        }
        return false;
    }

    /**
     * Whether the site settings needed to call Tutoria are present.
     *
     * @return bool
     */
    protected static function is_configured(): bool {
        return !empty(get_config('quiz_tutoria', 'baseurl'))
            && !empty(get_config('quiz_tutoria', 'apikey'))
            && (int) get_config('quiz_tutoria', 'universityid') > 0;
    }
}
