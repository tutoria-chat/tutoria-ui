<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

namespace quiz_tutoria\local;

/**
 * Saved AI drafts and job tracking for one quiz.
 *
 * Drafts are only suggestions: nothing in {quiz_tutoria_drafts} is a grade. A grade
 * exists only when a teacher saves it — through the review table here or through
 * Moodle's own manual grading page (where the floating panel only fills the form).
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class drafts {

    /** Review reason added here (the worker adds the others). */
    const REVIEW_NEAR_PASS = 'perto_da_aprovacao';

    /** Students whose estimated grade is within this share of the quiz grade from the pass mark are flagged. */
    const NEAR_PASS_SHARE = 0.10;

    /** @var grader */
    protected $grader;

    /** @var \stdClass */
    protected $quiz;

    /**
     * @param grader $grader the grader for this quiz (already scoped to the caller's groups).
     */
    public function __construct(grader $grader) {
        $this->grader = $grader;
        $this->quiz = $grader->get_quiz();
    }

    // ---- jobs ---------------------------------------------------------------

    /**
     * Remember a job just started for this quiz.
     *
     * @param string $jobid Tutoria job id.
     * @param string $gradingmode the mode the API accepted it under.
     * @param int $userid the teacher.
     */
    public function record_job(string $jobid, string $gradingmode, int $userid): void {
        global $DB;
        $now = time();
        $DB->insert_record('quiz_tutoria_jobs', (object) [
            'quizid'       => $this->quiz->id,
            'jobid'        => $jobid,
            'gradingmode'  => mode::normalize($gradingmode),
            'status'       => 'running',
            'userid'       => $userid,
            'timecreated'  => $now,
            'timemodified' => $now,
        ]);
    }

    /**
     * The job record for this quiz, or null when the job is not this quiz's.
     *
     * @param string $jobid Tutoria job id.
     * @return \stdClass|null
     */
    public function get_job(string $jobid): ?\stdClass {
        global $DB;
        // Newest first, in case an id was ever reused (e.g. a different Tutoria environment).
        $recs = $DB->get_records('quiz_tutoria_jobs', ['quizid' => $this->quiz->id, 'jobid' => $jobid],
            'timecreated DESC, id DESC', '*', 0, 1);
        return $recs ? reset($recs) : null;
    }

    /**
     * The newest job started for this quiz.
     *
     * @return \stdClass|null
     */
    public function latest_job(): ?\stdClass {
        global $DB;
        $recs = $DB->get_records('quiz_tutoria_jobs', ['quizid' => $this->quiz->id], 'timecreated DESC, id DESC', '*', 0, 1);
        return $recs ? reset($recs) : null;
    }

    /**
     * Set a job's status.
     *
     * @param string $jobid Tutoria job id.
     * @param string $status running | done | failed
     */
    public function set_job_status(string $jobid, string $status): void {
        global $DB;
        $rec = $this->get_job($jobid);
        if ($rec) {
            $DB->update_record('quiz_tutoria_jobs', (object) [
                'id' => $rec->id, 'status' => $status, 'timemodified' => time(),
            ]);
        }
    }

    // ---- saving a finished job's result --------------------------------------

    /**
     * Parse a finished job's CSV and save one draft per attempt/question, replacing
     * older drafts for the same attempt and question.
     *
     * A suggested mark is kept ONLY when the job ran in score mode (as the API told
     * us when it accepted the job) AND the row carries one. In feedback mode the
     * result has no grade column and suggestedmark is always null.
     *
     * @param string $jobid Tutoria job id.
     * @param string $csv the result CSV.
     * @return int number of drafts saved.
     */
    public function save_from_csv(string $jobid, string $csv): int {
        global $DB;

        $job = $this->get_job($jobid);
        $jobmode = $job ? mode::normalize($job->gradingmode) : mode::FEEDBACK;

        // Map each answer the caller may see: by attempt id, then by email / id number.
        $byattempt = [];
        $bykey = [];
        foreach ($this->grader->collect_submissions() as $s) {
            foreach ($s['questions'] as $q) {
                $meta = ['attemptid' => $q['attemptid'], 'uniqueid' => $q['uniqueid'], 'slot' => $q['slot'],
                    'userid' => $s['userid'], 'min' => $q['min_grade'], 'max' => $q['max_grade']];
                $byattempt[$q['attemptid'] . '|' . $q['slot']] = $meta;
                if (!empty($s['email'])) {
                    $bykey[\core_text::strtolower($s['email']) . '|' . $q['slot']] = $meta;
                }
                if ((string) $s['id'] !== '') {
                    $bykey[\core_text::strtolower((string) $s['id']) . '|' . $q['slot']] = $meta;
                }
            }
        }

        $rows = self::parse_csv($csv);
        $now = time();
        $saved = [];
        foreach ($rows as $row) {
            $slot = (int) ($row['slot'] ?? 0);
            $meta = null;
            if (!empty($row['attemptid'])) {
                $meta = $byattempt[(int) $row['attemptid'] . '|' . $slot] ?? null;
            }
            if (!$meta && !empty($row['email'])) {
                $meta = $bykey[\core_text::strtolower($row['email']) . '|' . $slot] ?? null;
            }
            if (!$meta && !empty($row['matricula'])) {
                $meta = $bykey[\core_text::strtolower($row['matricula']) . '|' . $slot] ?? null;
            }
            if (!$meta) {
                continue; // Not an answer of this quiz the caller may see.
            }

            $suggested = null;
            $confidence = null;
            $review = null;
            $rationale = null;
            if ($jobmode === mode::SCORE && array_key_exists('nota', $row)) {
                $raw = trim(str_replace(',', '.', (string) $row['nota']));
                if ($raw !== '' && is_numeric($raw)) {
                    // Never outside the question's allowed range.
                    $suggested = max((float) $meta['min'], min((float) $raw, (float) $meta['max']));
                }
                $confidence = in_array($row['confianca'] ?? '', ['alta', 'media', 'baixa'], true)
                    ? $row['confianca'] : 'baixa';
                $review = self::clean_review((string) ($row['revisar'] ?? ''));
                $rationale = (string) ($row['justificativa'] ?? '');
            }

            $record = (object) [
                'quizid'        => $this->quiz->id,
                'attemptid'     => $meta['attemptid'],
                'uniqueid'      => $meta['uniqueid'],
                'slot'          => $slot,
                'userid'        => $meta['userid'],
                'jobid'         => $jobid,
                'gradingmode'   => $jobmode,
                'feedback'      => (string) ($row['comentario'] ?? ''),
                'suggestedmark' => $suggested,
                'confidence'    => $confidence,
                'review'        => $review,
                'rationale'     => $rationale,
                'timecreated'   => $now,
            ];
            $saved[$meta['attemptid'] . '|' . $slot] = $record;
        }

        if ($jobmode === mode::SCORE) {
            $this->flag_near_pass($saved);
        }

        $transaction = $DB->start_delegated_transaction();
        foreach ($saved as $record) {
            $DB->delete_records('quiz_tutoria_drafts', ['attemptid' => $record->attemptid, 'slot' => $record->slot]);
            $DB->insert_record('quiz_tutoria_drafts', $record);
        }
        $transaction->allow_commit();

        return count($saved);
    }

    /**
     * Score mode: add "near the pass mark" to every draft of a student whose quiz
     * grade, with the suggested marks applied, lands close to the pass mark.
     *
     * @param \stdClass[] $records drafts keyed "attemptid|slot" (changed in place).
     */
    protected function flag_near_pass(array $records): void {
        $gradepass = $this->pass_mark();
        $grade = (float) ($this->quiz->grade ?? 0);
        if ($gradepass === null || $grade <= 0) {
            return;
        }
        $byusage = [];
        foreach ($records as $r) {
            if ($r->suggestedmark !== null) {
                $byusage[$r->uniqueid][$r->slot] = $r->suggestedmark;
            }
        }
        foreach ($byusage as $uniqueid => $marks) {
            $estimate = $this->grader->estimate_quiz_grade((int) $uniqueid, $marks);
            if ($estimate === null || abs($estimate - $gradepass) > self::NEAR_PASS_SHARE * $grade) {
                continue;
            }
            foreach ($records as $r) {
                if ((int) $r->uniqueid === (int) $uniqueid) {
                    $reasons = array_filter(explode(';', (string) $r->review));
                    $reasons[] = self::REVIEW_NEAR_PASS;
                    $r->review = implode(';', array_unique($reasons));
                }
            }
        }
    }

    /**
     * The quiz's pass mark from the gradebook, or null when none is set.
     *
     * @return float|null
     */
    public function pass_mark(): ?float {
        global $DB;
        $pass = $DB->get_field('grade_items', 'gradepass', [
            'itemtype' => 'mod', 'itemmodule' => 'quiz', 'iteminstance' => $this->quiz->id,
            'itemnumber' => 0, 'courseid' => $this->quiz->course,
        ]);
        return ($pass !== false && (float) $pass > 0) ? (float) $pass : null;
    }

    // ---- reading ---------------------------------------------------------------

    /**
     * The saved drafts the caller may see, joined with each student's answer and
     * current mark, in the order Moodle collects attempts.
     *
     * @return array list of items for the JS (review table and floating panel).
     */
    public function for_quiz(): array {
        global $DB;

        $drafts = [];
        foreach ($DB->get_records('quiz_tutoria_drafts', ['quizid' => $this->quiz->id]) as $d) {
            $drafts[$d->attemptid . '|' . $d->slot] = $d;
        }
        if (!$drafts) {
            return [];
        }

        $items = [];
        foreach ($this->grader->collect_submissions() as $s) {
            foreach ($s['questions'] as $q) {
                $d = $drafts[$q['attemptid'] . '|' . $q['slot']] ?? null;
                if (!$d) {
                    continue;
                }
                $isscore = $d->gradingmode === mode::SCORE;
                $items[] = [
                    'attemptid'     => (int) $q['attemptid'],
                    'uniqueid'      => (int) $q['uniqueid'],
                    'slot'          => (int) $q['slot'],
                    'name'          => $s['name'],
                    'question'      => $q['question_text'],
                    'answer'        => $q['answer'],
                    'maxmark'       => $q['max_mark'],
                    'currentmark'   => $q['current_mark'],
                    'feedback'      => (string) $d->feedback,
                    'mode'          => $isscore ? mode::SCORE : mode::FEEDBACK,
                    // Never sent for feedback-mode drafts, whatever the table holds.
                    'suggestedmark' => ($isscore && $d->suggestedmark !== null) ? round((float) $d->suggestedmark, 2) : null,
                    'confidence'    => $isscore ? (string) $d->confidence : '',
                    'review'        => $isscore ? array_values(array_filter(explode(';', (string) $d->review))) : [],
                    'rationale'     => $isscore ? (string) $d->rationale : '',
                    'timecreated'   => (int) $d->timecreated,
                ];
            }
        }
        return $items;
    }

    /**
     * The saved suggested marks, keyed "attemptid|slot" (score mode only) — used to
     * count how many grades the teacher changed when confirming.
     *
     * @return array<string, float>
     */
    public function suggested_marks(): array {
        global $DB;
        $out = [];
        $recs = $DB->get_records_select('quiz_tutoria_drafts',
            'quizid = :quizid AND gradingmode = :mode AND suggestedmark IS NOT NULL',
            ['quizid' => $this->quiz->id, 'mode' => mode::SCORE], '', 'id, attemptid, slot, suggestedmark');
        foreach ($recs as $r) {
            $out[$r->attemptid . '|' . $r->slot] = (float) $r->suggestedmark;
        }
        return $out;
    }

    // ---- helpers -----------------------------------------------------------

    /**
     * Keep only known review reason ids.
     *
     * @param string $raw ; separated reasons from the worker.
     * @return string|null
     */
    protected static function clean_review(string $raw): ?string {
        $known = ['confianca_baixa', 'confianca_media', 'possivel_manipulacao', 'resposta_vazia',
            'erro', 'nao_avaliado', 'sem_criterios', self::REVIEW_NEAR_PASS];
        $reasons = array_values(array_intersect(array_map('trim', explode(';', $raw)), $known));
        return $reasons ? implode(';', $reasons) : null;
    }

    /**
     * Parse a CSV (RFC 4180, optional UTF-8 BOM) into rows keyed by lower-case header.
     *
     * @param string $csv the CSV text.
     * @return array<int, array<string, string>>
     */
    public static function parse_csv(string $csv): array {
        if (strncmp($csv, "\xEF\xBB\xBF", 3) === 0) {
            $csv = substr($csv, 3);
        }
        $fh = fopen('php://temp', 'r+');
        fwrite($fh, $csv);
        rewind($fh);

        $header = fgetcsv($fh, null, ',', '"', '');
        if (!$header) {
            fclose($fh);
            return [];
        }
        $header = array_map(function($h) {
            return \core_text::strtolower(trim((string) $h));
        }, $header);

        $rows = [];
        while (($r = fgetcsv($fh, null, ',', '"', '')) !== false) {
            if ($r === [null] || $r === ['']) {
                continue;
            }
            $row = [];
            foreach ($header as $i => $h) {
                $row[$h] = isset($r[$i]) ? (string) $r[$i] : '';
            }
            $rows[] = $row;
        }
        fclose($fh);
        return $rows;
    }
}
