<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

namespace quiz_tutoria\task;

/**
 * Deletes AI drafts and job records older than the retention period (data
 * minimisation). Grades and comments already saved in Moodle are untouched.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class cleanup_drafts extends \core\task\scheduled_task {

    /** Default retention when the setting is empty or invalid. */
    const DEFAULT_DAYS = 90;

    /**
     * Task name.
     *
     * @return string
     */
    public function get_name() {
        return get_string('task_cleanup', 'quiz_tutoria');
    }

    /**
     * Delete old rows.
     */
    public function execute() {
        global $DB;
        $days = (int) get_config('quiz_tutoria', 'retentiondays');
        if ($days <= 0) {
            $days = self::DEFAULT_DAYS;
        }
        $cutoff = time() - $days * DAYSECS;
        $DB->delete_records_select('quiz_tutoria_drafts', 'timecreated < :cutoff', ['cutoff' => $cutoff]);
        $DB->delete_records_select('quiz_tutoria_jobs', 'timecreated < :cutoff', ['cutoff' => $cutoff]);
        mtrace("quiz_tutoria: removed drafts and jobs older than {$days} day(s).");
    }
}
