<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

namespace quiz_tutoria\event;

defined('MOODLE_INTERNAL') || die();

/**
 * Event: a teacher confirmed and saved grades in the grading assistant.
 *
 * Part of the audit trail (CNE Guidelines / LGPD): the grade is always the
 * teacher's decision, never the AI's. This records WHO confirmed the grades,
 * for which quiz, HOW MANY were applied, and WHEN — the human accountability
 * counterpart to feedback_requested. Landing in Moodle's standard log store
 * makes it queryable and exportable in Reports → Logs.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class grades_confirmed extends \core\event\base {

    /**
     * Initialise the event data.
     */
    protected function init() {
        // Updates question/quiz grades; teacher-level activity.
        $this->data['crud'] = 'u';
        $this->data['edulevel'] = self::LEVEL_TEACHING;
    }

    /**
     * Human-readable event name (Reports → Logs).
     *
     * @return string
     */
    public static function get_name() {
        return get_string('event_grades_confirmed', 'quiz_tutoria');
    }

    /**
     * Description of what happened, for the log line.
     *
     * @return string
     */
    public function get_description() {
        $applied = (int) ($this->other['applied'] ?? 0);
        $errors = (int) ($this->other['errors'] ?? 0);
        $msg = "The user with id '{$this->userid}' confirmed and saved {$applied} teacher-decided grade(s) " .
            "in the quiz with course module id '{$this->contextinstanceid}'.";
        if ($errors > 0) {
            $msg .= " {$errors} item(s) could not be applied.";
        }
        return $msg;
    }

    /**
     * Where the action happened.
     *
     * @return \moodle_url
     */
    public function get_url() {
        return new \moodle_url('/mod/quiz/report.php', [
            'id'   => $this->contextinstanceid,
            'mode' => 'tutoria',
        ]);
    }
}
