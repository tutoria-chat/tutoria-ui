<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

namespace quiz_tutoria\event;

defined('MOODLE_INTERNAL') || die();

/**
 * Event: a teacher requested AI formative-feedback drafts for a quiz.
 *
 * Part of the audit trail (CNE Guidelines / LGPD): records WHO asked the AI to
 * generate feedback, for which quiz, and WHEN, linked to the external Tutoria
 * job id. The AI never assigns a grade — this only starts the feedback draft.
 * Landing in Moodle's standard log store makes it queryable and exportable in
 * Reports → Logs.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class feedback_requested extends \core\event\base {

    /**
     * Initialise the event data.
     */
    protected function init() {
        // Creates an external grading (feedback) job; teacher-level activity.
        $this->data['crud'] = 'c';
        $this->data['edulevel'] = self::LEVEL_TEACHING;
    }

    /**
     * Human-readable event name (Reports → Logs).
     *
     * @return string
     */
    public static function get_name() {
        return get_string('event_feedback_requested', 'quiz_tutoria');
    }

    /**
     * Description of what happened, for the log line.
     *
     * @return string
     */
    public function get_description() {
        $jobid = $this->other['jobid'] ?? '';
        $count = (int) ($this->other['essaycount'] ?? 0);
        return "The user with id '{$this->userid}' requested AI feedback drafts for {$count} essay answer(s) " .
            "in the quiz with course module id '{$this->contextinstanceid}' (Tutoria job '{$jobid}'). " .
            "No grade is produced by the AI.";
    }

    /**
     * Where the action happened.
     *
     * @return \moodle_url
     */
    public function get_url() {
        return new \moodle_url('/mod/quiz/report.php', [
            'id'   => $this->contextinstanceid,
            'mode' => 'tutoria',
        ]);
    }
}
