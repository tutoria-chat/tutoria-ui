# Assistente de Correção (Tutoria) — Moodle quiz report (`quiz_tutoria`)

Adds an **AI correction assistant** tab inside a Moodle quiz's results. For each
essay answer the assistant prepares a **formative feedback draft** the teacher
can edit — it **does not correct, evaluate or suggest a grade**. The teacher
reads the drafts, assigns the grade themselves, and publishes.

> **Regulatory note (BR).** Built to the **CNE Guidelines for AI in Education**
> (approved 01/09/2026), which prohibit AI from correcting, evaluating or
> *suggesting a grade* on essays/discursive assessments — even as a draft. This
> plugin never surfaces or applies an AI grade: the mark field is always filled
> by the teacher. The AI only organises answers and drafts feedback
> (*risco baixo/moderado* with mandatory human review).

## Why this design

- **Inside the Test — nothing added to the course.** It is a quiz *report
  subplugin* (`mod/quiz/report/tutoria`), the same kind of plugin as Moodle's
  own "Manual grading". It shows up as a tab under a quiz's **Results**, visible
  only to graders. No extra activity, no extra course, nothing students ever see.
- **No separate Tutoria course to create.** The first time a quiz is graded, the
  matching Tutoria course is provisioned automatically from the Moodle course.
  There is no course id to type and no mirror course to set up.
- **Grades land the normal way.** Marks are written through Moodle's own
  question engine (`manual_grade`), exactly as manual grading does, and the
  gradebook is recomputed. Nothing is written until the teacher clicks Apply.

## Requirements

- Moodle **4.2 or newer** (tested through 5.1). 4.2 is the first version with the
  `mod_quiz\local\reports\report_base` API this plugin builds on.
- A Tutoria account with the grading feature enabled for your institution, and an
  external API key.

## Install

1. Copy this folder to `mod/quiz/report/tutoria` in your Moodle (the folder
   **must** be named `tutoria`), or upload the ZIP via
   **Site administration → Plugins → Install plugins**.
2. Visit **Site administration → Notifications** to complete the install.

## One-time setup (administrator)

**Site administration → Plugins → Activity modules → Quiz → Assistente de Correção (Tutoria)**

All three connection values are on the Tutoria dashboard, page
**Configuração do AVA → Assistente de Correção**, with copy buttons:

| Setting | What it is |
| --- | --- |
| **API base URL** | The Tutoria API address shown on that page. |
| **API key** | Your institution's key (`tgk_…`), generated on that page. It is shown **once** and works only for your institution — if lost, revoke it and create another. |
| **Institution ID** | Your institution's number, shown on that page. |
| **Request timeout** | Seconds to wait per API call (default 30). |
| **Default grading guidance** | Optional guidance sent with every job. |

That is the entire setup. There is nothing to configure per course or per quiz.
(The legacy shared key from Tutoria still works, but prefer an institution key.)

## Teacher flow

1. Open a quiz → **Results** → **Assistente de Correção**.
2. (Optional) describe in **Critérios de correção / rubrica** what a good answer contains.
3. **Analisar com IA** — the essay answers are analysed and a review table appears,
   with an AI **feedback draft** per answer and an **empty grade field**.
4. **Ver resposta** on each row shows the full question and what the student
   wrote (**Abrir tentativa** opens the whole attempt in a new tab).
5. Edit any feedback, type each grade yourself (the AI never suggests one), then
   **Lançar notas e feedback**. Only rows with a grade are saved; a row that
   fails (e.g. grade above the maximum) turns red with the reason.

Only quizzes that contain essay questions show anything to grade.

The page carries its own how-to panel (**Como usar este assistente**: steps, how
to read a row, common errors, link to the full illustrated PDF guide). It starts
open and stays closed once a teacher closes it (per browser).

## How it works

```
Teacher clicks "Analisar com IA"
   → ajax.php collects the essay answers from this quiz (question engine)
   → POST  {api}/api/external/grading/{institutionId}/{courseId}?coursename=…
   → poll  GET  …/{jobId}  until the CSV of feedback drafts is ready
   → review table (feedback editable, grade typed by the teacher)
   → Save → question engine manual_grade() per answer, in one transaction
             → gradebook recomputed
```

The browser never holds authority over what gets graded: answers are re-collected
on the server at grading time, and every applied mark is re-validated server-side
(the attempt must belong to this quiz and the mark must be within range).

## Privacy

The plugin stores **no** data in Moodle. To grade, it sends each student's essay
answer plus their name, email and ID number to the Tutoria service; this is
declared through Moodle's Privacy API (see the site's plugin privacy registry).

## Notes for maintainers

- The client JS is plain (non-AMD) and loaded via `$PAGE->requires->js()`, so
  there is **no build step** — the plugin runs exactly as shipped.
- All Tutoria calls are bounded by the configured timeout and logged (errors go
  to the server log; verbose tracing only under developer debugging).
- Grades are applied in a single server-side transaction, one round-trip, rather
  than one HTTP request per grade.

## License

GNU GPL v3 or later.
