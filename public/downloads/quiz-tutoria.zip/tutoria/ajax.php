<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * AJAX endpoint for the Tutoria AI grading report.
 *
 * Actions (all require the quiz grading capability and a valid sesskey):
 *   collect  read the essay answers in this quiz (mapping for the review table)
 *   start    (re)collect on the server and start a Tutoria grading job
 *   poll     poll the job; returns the result CSV when ready
 *   apply    write a batch of grades back to the quiz attempts
 *
 * The server re-collects answers at 'start' rather than trusting anything the
 * browser holds, so the AI always grades the real submitted answers.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

define('AJAX_SCRIPT', true);

require(__DIR__ . '/../../../../config.php');

use quiz_tutoria\local\client;
use quiz_tutoria\local\grader;

$cmid   = required_param('cmid', PARAM_INT);
$action = required_param('action', PARAM_ALPHA);

[$course, $cm] = get_course_and_cm_from_cmid($cmid, 'quiz');
require_login($course, false, $cm);
require_sesskey();

$context = context_module::instance($cm->id);
require_capability('quiz/tutoria:view', $context);

$quiz = $DB->get_record('quiz', ['id' => $cm->instance], '*', MUST_EXIST);

// Respect separate groups: a teacher who cannot access all groups may only see
// and grade the students in the groups they belong to. null = no restriction.
$alloweduserids = null;
if (groups_get_activity_groupmode($cm, $course) == SEPARATEGROUPS
        && !has_capability('moodle/site:accessallgroups', $context)) {
    $alloweduserids = [];
    foreach (array_keys(groups_get_activity_allowed_groups($cm)) as $gid) {
        foreach (groups_get_members($gid, 'u.id') as $u) {
            $alloweduserids[(int) $u->id] = (int) $u->id;
        }
    }
    $alloweduserids = array_values($alloweduserids);
}

$grader = new grader($quiz, $alloweduserids);

/**
 * Emit a JSON response and stop.
 *
 * @param int $httpcode HTTP status.
 * @param array $data payload.
 * @return never
 */
function quiz_tutoria_json(int $httpcode, array $data) {
    http_response_code($httpcode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

try {
    switch ($action) {

        case 'collect':
            // Give the browser the per-student, per-slot map it needs to place
            // returned grades — but not authority over what gets sent for grading.
            $submissions = $grader->collect_submissions();
            $essaycount = 0;
            foreach ($submissions as $s) {
                $essaycount += count($s['questions']);
            }
            quiz_tutoria_json(200, [
                'students'    => $submissions,
                'studentcount' => count($submissions),
                'essaycount'  => $essaycount,
            ]);
            break;

        case 'start':
            $criteria = optional_param('criteria', '', PARAM_TEXT);
            if ($criteria === '') {
                $criteria = (string) get_config('quiz_tutoria', 'defaultcriteria');
            }

            // Authoritative collection on the server side.
            $submissions = $grader->collect_submissions();
            if (empty($submissions)) {
                quiz_tutoria_json(409, ['message' => get_string('error_nosubmissions', 'quiz_tutoria')]);
            }

            // Shape the payload for Tutoria: annotate each student and question with
            // the course id and quiz cmid the worker keys its CSV rows on.
            $payload = [];
            $essaycount = 0;
            foreach ($submissions as $s) {
                $questions = [];
                foreach ($s['questions'] as $q) {
                    $questions[] = [
                        'slot'          => $q['slot'],
                        'question_text' => $q['question_text'],
                        'answer'        => $q['answer'],
                        'max_mark'      => $q['max_mark'],
                        'feedback'      => $q['feedback'],
                        'quiz_cmid'     => (int) $cm->id,
                    ];
                }
                $essaycount += count($questions);
                $payload[] = [
                    'attempt'   => $s['attempt'],
                    'name'      => $s['name'],
                    'id'        => $s['id'],
                    'email'     => $s['email'],
                    'course_id' => (int) $course->id,
                    'quiz_cmid' => (int) $cm->id,
                    'questions' => $questions,
                ];
            }

            $client = client::from_config();
            $jobid = $client->start_job(
                (int) $course->id,
                format_string($course->fullname),
                json_encode($payload),
                trim($criteria)
            );

            // Audit trail (CNE / LGPD): record who asked the AI to generate
            // feedback drafts, for which quiz, and when — linked to the job id.
            \quiz_tutoria\event\feedback_requested::create([
                'context' => $context,
                'other'   => [
                    'jobid'        => (string) $jobid,
                    'studentcount' => count($payload),
                    'essaycount'   => $essaycount,
                ],
            ])->trigger();

            quiz_tutoria_json(202, ['jobid' => $jobid]);
            break;

        case 'poll':
            $jobid = required_param('jobid', PARAM_ALPHANUMEXT);
            $client = client::from_config();
            $result = $client->poll_job((int) $course->id, $jobid);
            quiz_tutoria_json(200, $result);
            break;

        case 'apply':
            $itemsjson = required_param('items', PARAM_RAW);
            $items = json_decode($itemsjson, true);
            if (!is_array($items)) {
                quiz_tutoria_json(400, ['message' => get_string('error_baditems', 'quiz_tutoria')]);
            }
            $result = $grader->apply_grades($items);

            // Audit trail (CNE / LGPD): the grade is the teacher's decision —
            // record who confirmed the grades, for which quiz, how many, and when.
            \quiz_tutoria\event\grades_confirmed::create([
                'context' => $context,
                'other'   => [
                    'applied' => (int) ($result['applied'] ?? 0),
                    'errors'  => is_array($result['errors'] ?? null) ? count($result['errors']) : 0,
                ],
            ])->trigger();

            quiz_tutoria_json(200, $result);
            break;

        default:
            quiz_tutoria_json(400, ['message' => get_string('error_badaction', 'quiz_tutoria')]);
    }

} catch (\moodle_exception $e) {
    // Configuration / transport / API failures surface as a clean message.
    quiz_tutoria_json(502, ['message' => $e->getMessage()]);
} catch (\Throwable $e) {
    debugging('quiz_tutoria ajax: ' . $e->getMessage(), DEBUG_DEVELOPER);
    quiz_tutoria_json(500, ['message' => get_string('error_unexpected', 'quiz_tutoria')]);
}
