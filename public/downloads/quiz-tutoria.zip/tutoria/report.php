<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * The Tutoria AI grading report — a tab inside a quiz's results.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use mod_quiz\local\reports\report_base;
use quiz_tutoria\local\grader;

defined('MOODLE_INTERNAL') || die();

/**
 * Renders the AI grading interface for one quiz.
 */
class quiz_tutoria_report extends report_base {

    /** The full illustrated guide (pt-BR PDF), served by the Tutoria dashboard. */
    const GUIDE_URL = 'https://app.tutoria.tec.br/downloads/guia-assistente-de-correcao.pdf';

    /**
     * Display the report.
     *
     * @param stdClass $quiz the quiz settings.
     * @param stdClass $cm the course_module.
     * @param stdClass $course the course.
     * @return bool
     */
    public function display($quiz, $cm, $course): bool {
        global $OUTPUT, $PAGE;

        $context = context_module::instance($cm->id);
        require_capability('quiz/tutoria:view', $context);

        $this->print_header_and_tabs($cm, $course, $quiz, 'tutoria');

        echo $OUTPUT->heading(get_string('pluginname', 'quiz_tutoria'));

        // Nothing to do if the plugin has not been configured yet.
        if (!$this->is_configured()) {
            echo $OUTPUT->notification(get_string('error_notconfigured', 'quiz_tutoria'), 'error');
            return true;
        }

        // Nothing to do if this quiz has no essay questions.
        $grader = new grader($quiz);
        if (!$grader->has_essay_questions()) {
            echo $OUTPUT->notification(get_string('noessay', 'quiz_tutoria'), 'info');
            return true;
        }

        echo $this->render_app($cm);

        // Plain JS — no AMD build step, so the plugin works as shipped in every
        // environment. Config and localized dynamic strings ride on data-*.
        // Load in the footer (not the head): the script must run after the
        // #quiz-tutoria-app container exists in the DOM. The script also guards
        // on DOM-ready, so it is safe either way.
        $PAGE->requires->js(new moodle_url('/mod/quiz/report/tutoria/js/grader.js'));

        return true;
    }

    /**
     * Whether the site settings needed to call Tutoria are all present.
     *
     * @return bool
     */
    protected function is_configured(): bool {
        $baseurl      = get_config('quiz_tutoria', 'baseurl');
        $apikey       = get_config('quiz_tutoria', 'apikey');
        $universityid = get_config('quiz_tutoria', 'universityid');
        return !empty($baseurl) && !empty($apikey) && (int) $universityid > 0;
    }

    /**
     * The interactive container. JS reads its data-* attributes and fills the
     * results table; the static chrome is rendered (and localized) here.
     *
     * @param \cm_info $cm the course module (as core passes it to display()).
     * @return string HTML.
     */
    protected function render_app($cm): string {
        $defaultcriteria = (string) get_config('quiz_tutoria', 'defaultcriteria');

        $strings = [
            'collecting'   => get_string('js_collecting', 'quiz_tutoria'),
            'nostudents'   => get_string('js_nostudents', 'quiz_tutoria'),
            'starting'     => get_string('js_starting', 'quiz_tutoria'),
            'grading'      => get_string('js_grading', 'quiz_tutoria'),
            'gradingn'     => get_string('js_gradingn', 'quiz_tutoria'),
            'done'         => get_string('js_done', 'quiz_tutoria'),
            'applying'     => get_string('js_applying', 'quiz_tutoria'),
            'applied'      => get_string('js_applied', 'quiz_tutoria'),
            'applyerrors'  => get_string('js_applyerrors', 'quiz_tutoria'),
            'confirmapply' => get_string('js_confirmapply', 'quiz_tutoria'),
            'nogrades'     => get_string('js_nogrades', 'quiz_tutoria'),
            'error'        => get_string('js_error', 'quiz_tutoria'),
            'colstudent'   => get_string('col_student', 'quiz_tutoria'),
            'colquestion'  => get_string('col_question', 'quiz_tutoria'),
            'colmark'      => get_string('col_mark', 'quiz_tutoria'),
            'colcomment'   => get_string('col_comment', 'quiz_tutoria'),
            'viewanswer'   => get_string('js_viewanswer', 'quiz_tutoria'),
            'hideanswer'   => get_string('js_hideanswer', 'quiz_tutoria'),
            'openattempt'  => get_string('js_openattempt', 'quiz_tutoria'),
            'questionlabel' => get_string('js_questionlabel', 'quiz_tutoria'),
            'answerlabel'  => get_string('js_answerlabel', 'quiz_tutoria'),
            'noanswer'     => get_string('js_noanswer', 'quiz_tutoria'),
            'tablehint'    => get_string('js_tablehint', 'quiz_tutoria'),
            'rowerror'     => get_string('js_rowerror', 'quiz_tutoria'),
        ];

        $root = html_writer::start_div('quiz-tutoria-app', [
            'id'                  => 'quiz-tutoria-app',
            'data-cmid'           => $cm->id,
            'data-sesskey'        => sesskey(),
            'data-ajaxurl'        => (new moodle_url('/mod/quiz/report/tutoria/ajax.php'))->out(false),
            'data-reviewurl'      => (new moodle_url('/mod/quiz/review.php'))->out(false),
            'data-strings'        => json_encode($strings),
        ]);

        // Persistent compliance notice (CNE Guidelines): the AI never grades.
        $root .= html_writer::div(
            get_string('compliance_notice', 'quiz_tutoria'),
            'alert alert-info',
            ['role' => 'note']
        );

        // Intro + criteria.
        $root .= html_writer::tag('p', get_string('intro', 'quiz_tutoria'), ['class' => 'text-muted']);
        $root .= $this->render_help();

        $root .= html_writer::start_div('form-group');
        $root .= html_writer::tag('label', get_string('criteria', 'quiz_tutoria'),
            ['for' => 'quiz-tutoria-criteria', 'class' => 'font-weight-bold']);
        $root .= html_writer::tag('textarea', s($defaultcriteria), [
            'id'          => 'quiz-tutoria-criteria',
            'class'       => 'form-control',
            'rows'        => 3,
            'placeholder' => get_string('criteria_placeholder', 'quiz_tutoria'),
        ]);
        $root .= html_writer::end_div();

        // Primary action + status line.
        $root .= html_writer::start_div('quiz-tutoria-actions');
        $root .= html_writer::tag('button', get_string('grade_button', 'quiz_tutoria'), [
            'type'  => 'button',
            'id'    => 'quiz-tutoria-grade',
            'class' => 'btn btn-primary',
        ]);
        $root .= html_writer::div('', 'quiz-tutoria-status', ['id' => 'quiz-tutoria-status']);
        $root .= html_writer::end_div();

        // Results table container + apply button (hidden until there are results).
        $root .= html_writer::div('', 'quiz-tutoria-results', ['id' => 'quiz-tutoria-results']);
        $root .= html_writer::tag('button', get_string('apply_button', 'quiz_tutoria'), [
            'type'  => 'button',
            'id'    => 'quiz-tutoria-apply',
            'class' => 'btn btn-success',
            'style' => 'display:none;',
        ]);

        $root .= html_writer::end_div();
        return $root;
    }

    /**
     * The in-page "how to use" guide: steps, how to read a row of the review
     * table, and what to do on common errors. Open by default; grader.js
     * remembers when a teacher closes it.
     *
     * @return string HTML.
     */
    protected function render_help(): string {
        $steps = '';
        for ($i = 1; $i <= 6; $i++) {
            $steps .= html_writer::tag('li', get_string('help_step' . $i, 'quiz_tutoria'));
        }

        // Column names come from the same strings as the table headers.
        $columns = '';
        $labels = [
            'student'  => get_string('col_student', 'quiz_tutoria'),
            'question' => get_string('col_question', 'quiz_tutoria'),
            'answer'   => get_string('js_viewanswer', 'quiz_tutoria'),
            'mark'     => get_string('col_mark', 'quiz_tutoria'),
            'comment'  => get_string('col_comment', 'quiz_tutoria'),
        ];
        foreach ($labels as $key => $label) {
            $columns .= html_writer::tag('dt', $label)
                . html_writer::tag('dd', get_string('help_col_' . $key, 'quiz_tutoria'));
        }

        $problems = '';
        foreach (['config', 'nostudents', 'rowerror', 'slow'] as $key) {
            $problems .= html_writer::tag('li',
                html_writer::tag('strong', get_string('help_problem_' . $key, 'quiz_tutoria')) . ' '
                . get_string('help_fix_' . $key, 'quiz_tutoria'));
        }

        $body = html_writer::tag('h4', get_string('help_steps_title', 'quiz_tutoria'))
            . html_writer::tag('ol', $steps)
            . html_writer::tag('h4', get_string('help_columns_title', 'quiz_tutoria'))
            . html_writer::tag('dl', $columns)
            . html_writer::tag('h4', get_string('help_problems_title', 'quiz_tutoria'))
            . html_writer::tag('ul', $problems)
            . html_writer::tag('p', html_writer::link(self::GUIDE_URL,
                get_string('help_fullguide', 'quiz_tutoria'), ['target' => '_blank', 'rel' => 'noopener']));

        return html_writer::tag('details',
            html_writer::tag('summary', get_string('help_title', 'quiz_tutoria'))
            . html_writer::div($body, 'quiz-tutoria-help-body'),
            ['class' => 'quiz-tutoria-help', 'id' => 'quiz-tutoria-help', 'open' => 'open']);
    }
}
