<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Capabilities for quiz_tutoria.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$capabilities = [

    // View and use the AI grading report. Cloned from the standard "grade quiz"
    // permission so whoever can grade a quiz can also use AI-assisted grading.
    'quiz/tutoria:view' => [
        // 'write' + RISK_XSS: using the report applies marks and stores HTML
        // teacher comments on attempts, and sends student answers/PII to the
        // external grader — it is not a read-only view. Mirrors mod/quiz:grade.
        'riskbitmask'  => RISK_XSS,
        'captype'      => 'write',
        'contextlevel' => CONTEXT_MODULE,
        'archetypes'   => [
            'teacher'        => CAP_ALLOW,
            'editingteacher' => CAP_ALLOW,
            'manager'        => CAP_ALLOW,
        ],
        'clonepermissionsfrom' => 'mod/quiz:grade',
    ],
];
