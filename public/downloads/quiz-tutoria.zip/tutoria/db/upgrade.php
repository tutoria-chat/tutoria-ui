<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Upgrade steps for quiz_tutoria.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * @param int $oldversion the version we are upgrading from.
 * @return bool
 */
function xmldb_quiz_tutoria_upgrade($oldversion) {
    global $DB;

    // Register the report for sites that installed an early build which lacked
    // db/install.php, so the Results tab starts appearing after this upgrade.
    if ($oldversion < 2026081502) {
        if (!$DB->record_exists('quiz_reports', ['name' => 'tutoria'])) {
            $record = new stdClass();
            $record->name         = 'tutoria';
            $record->displayorder = '7000';
            $record->capability   = 'quiz/tutoria:view';
            $DB->insert_record('quiz_reports', $record);
        }
        upgrade_plugin_savepoint(true, 2026081502, 'quiz', 'tutoria');
    }

    return true;
}
