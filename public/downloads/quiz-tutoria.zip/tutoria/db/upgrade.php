<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Upgrade steps for quiz_tutoria.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * @param int $oldversion the version we are upgrading from.
 * @return bool
 */
function xmldb_quiz_tutoria_upgrade($oldversion) {
    global $DB;

    // Register the report for sites that installed an early build which lacked
    // db/install.php, so the Results tab starts appearing after this upgrade.
    if ($oldversion < 2026081502) {
        if (!$DB->record_exists('quiz_reports', ['name' => 'tutoria'])) {
            $record = new stdClass();
            $record->name         = 'tutoria';
            $record->displayorder = '7000';
            $record->capability   = 'quiz/tutoria:view';
            $DB->insert_record('quiz_reports', $record);
        }
        upgrade_plugin_savepoint(true, 2026081502, 'quiz', 'tutoria');
    }

    // 1.4.0: saved AI drafts (so a reload or the floating panel can show them) and
    // job tracking (so a job started in one page can be resumed in another).
    if ($oldversion < 2026110900) {
        $dbman = $DB->get_manager();

        $table = new xmldb_table('quiz_tutoria_jobs');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('quizid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('jobid', XMLDB_TYPE_CHAR, '64', null, XMLDB_NOTNULL, null, null);
        $table->add_field('gradingmode', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'feedback');
        $table->add_field('status', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'running');
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_key('quizid', XMLDB_KEY_FOREIGN, ['quizid'], 'quiz', ['id']);
        $table->add_key('userid', XMLDB_KEY_FOREIGN, ['userid'], 'user', ['id']);
        $table->add_index('quizjob', XMLDB_INDEX_NOTUNIQUE, ['quizid', 'jobid']);
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        $table = new xmldb_table('quiz_tutoria_drafts');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('quizid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('attemptid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('uniqueid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('slot', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('jobid', XMLDB_TYPE_CHAR, '64', null, XMLDB_NOTNULL, null, null);
        $table->add_field('gradingmode', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'feedback');
        $table->add_field('feedback', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('suggestedmark', XMLDB_TYPE_NUMBER, '12, 5', null, null, null, null);
        $table->add_field('confidence', XMLDB_TYPE_CHAR, '10', null, null, null, null);
        $table->add_field('review', XMLDB_TYPE_CHAR, '255', null, null, null, null);
        $table->add_field('rationale', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $table->add_key('quizid', XMLDB_KEY_FOREIGN, ['quizid'], 'quiz', ['id']);
        $table->add_key('attemptid', XMLDB_KEY_FOREIGN, ['attemptid'], 'quiz_attempts', ['id']);
        $table->add_key('userid', XMLDB_KEY_FOREIGN, ['userid'], 'user', ['id']);
        $table->add_index('attemptslot', XMLDB_INDEX_UNIQUE, ['attemptid', 'slot']);
        $table->add_index('quizuniqueid', XMLDB_INDEX_NOTUNIQUE, ['quizid', 'uniqueid']);
        $table->add_index('timecreated', XMLDB_INDEX_NOTUNIQUE, ['timecreated']);
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        upgrade_plugin_savepoint(true, 2026110900, 'quiz', 'tutoria');
    }

    return true;
}
