<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Install-time setup for quiz_tutoria.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Register the report so it appears in a quiz's Results navigation.
 *
 * Quiz reports are only offered to teachers if they have a row in the
 * {quiz_reports} table (name, displayorder, capability) — exactly like the core
 * overview/grading/responses/statistics reports, each of which ships this same
 * install step. Without it the report installs but is unreachable.
 */
function xmldb_quiz_tutoria_install() {
    global $DB;

    if ($DB->record_exists('quiz_reports', ['name' => 'tutoria'])) {
        return;
    }

    $record = new stdClass();
    $record->name         = 'tutoria';
    $record->displayorder = '7000';                 // Just after "grading" (6000).
    $record->capability   = 'quiz/tutoria:view';
    $DB->insert_record('quiz_reports', $record);
}
