<?php
// This file is part of the quiz_tutoria plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Site-wide settings for quiz_tutoria.
 *
 * One-time setup for an administrator: point the plugin at the Tutoria API and
 * identify which Tutoria institution this Moodle belongs to. There is no
 * per-course or per-quiz configuration.
 *
 * @package     quiz_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

if ($ADMIN->fulltree) {

    $settings->add(new admin_setting_heading(
        'quiz_tutoria/setup',
        get_string('settings_setup', 'quiz_tutoria'),
        get_string('settings_setup_desc', 'quiz_tutoria')
    ));

    // Where the Tutoria API lives. Defaults to production; rarely changed.
    $settings->add(new admin_setting_configtext(
        'quiz_tutoria/baseurl',
        get_string('settings_baseurl', 'quiz_tutoria'),
        get_string('settings_baseurl_desc', 'quiz_tutoria'),
        'https://api.tutoria.tec.br',
        PARAM_URL
    ));

    // The shared external API key (X-Api-Key). A secret — stored unmasked.
    $settings->add(new admin_setting_configpasswordunmask(
        'quiz_tutoria/apikey',
        get_string('settings_apikey', 'quiz_tutoria'),
        get_string('settings_apikey_desc', 'quiz_tutoria'),
        ''
    ));

    // Which Tutoria institution this Moodle site maps to.
    $settings->add(new admin_setting_configtext(
        'quiz_tutoria/universityid',
        get_string('settings_universityid', 'quiz_tutoria'),
        get_string('settings_universityid_desc', 'quiz_tutoria'),
        '',
        PARAM_INT
    ));

    // How long to wait on a single call to the Tutoria API before giving up.
    $settings->add(new admin_setting_configtext(
        'quiz_tutoria/timeout',
        get_string('settings_timeout', 'quiz_tutoria'),
        get_string('settings_timeout_desc', 'quiz_tutoria'),
        '30',
        PARAM_INT
    ));

    // Default grading guidance sent with every job. Teachers can override per run.
    $settings->add(new admin_setting_configtextarea(
        'quiz_tutoria/defaultcriteria',
        get_string('settings_defaultcriteria', 'quiz_tutoria'),
        get_string('settings_defaultcriteria_desc', 'quiz_tutoria'),
        ''
    ));
}
