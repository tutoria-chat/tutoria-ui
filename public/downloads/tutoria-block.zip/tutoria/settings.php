<?php
// This file is part of the Tutoria block for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Site-wide admin settings for block_tutoria.
 *
 * @package     block_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

if ($ADMIN->fulltree) {
    $settings->add(new admin_setting_configtext(
        'block_tutoria/widgetbaseurl',
        get_string('widgetbaseurl', 'block_tutoria'),
        get_string('widgetbaseurl_desc', 'block_tutoria'),
        'https://tutoria-widget.vercel.app',
        PARAM_URL
    ));
}
