<?php
// This file is part of the Tutoria block for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * English strings for block_tutoria.
 *
 * @package     block_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Tutoria';
$string['defaulttitle'] = 'Tutor';
$string['tutoria:addinstance'] = 'Add a new Tutoria block';
$string['tutoria:myaddinstance'] = 'Add a new Tutoria block to the Dashboard';

$string['notconfigured'] = 'Paste the module access key in this block\'s settings to show the tutor.';

$string['configtitle'] = 'Block title';
$string['moduletoken'] = 'Module access key';
$string['moduletoken_help'] = 'The module access key (module_token) generated in the Tutoria dashboard for this module. It is both the identity and the credential — no separate login is needed.';

$string['displaymode'] = 'Display';
$string['displaymode_help'] = 'Embedded shows the chat inside the block. Floating bubble shows a launcher in the page corner that opens the tutor over the page — good when you want the tutor available everywhere without taking sidebar space.';
$string['displaymode_embed'] = 'Embedded in the block';
$string['displaymode_bubble'] = 'Floating chat bubble';

$string['height'] = 'Height (px)';

$string['darkmode'] = 'Theme';
$string['darkmode_auto'] = 'Match the device';
$string['darkmode_light'] = 'Light';
$string['darkmode_dark'] = 'Dark';

$string['passstudentid'] = 'Identify the student';
$string['passstudentid_label'] = 'Send the student\'s ID number (matrícula) to the tutor';
$string['passstudentid_help'] = 'When enabled, the block forwards the student\'s Moodle ID number (usually the matrícula), falling back to the internal user id, so the tutor can pre-fill verification and attribute analytics.';

$string['openwidget'] = 'Open the tutor';
$string['close'] = 'Close';

$string['widgetbaseurl'] = 'Widget base URL';
$string['widgetbaseurl_desc'] = 'Where the Tutoria widget is hosted, e.g. https://widget.tutoria.tec.br — the block appends the module access key and student parameters.';

$string['privacy:metadata:widget'] = 'The Tutoria block embeds the external Tutoria widget. To attribute the conversation, the student\'s ID number (or internal user id) may be sent to the widget as a URL parameter.';
$string['privacy:metadata:widget:studentid'] = 'The student ID number (matrícula) or internal user id, sent so the tutor can identify the student.';
