<?php
// This file is part of the Tutoria block for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Brazilian Portuguese strings for block_tutoria.
 *
 * @package     block_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Tutoria';
$string['defaulttitle'] = 'Tutor';
$string['tutoria:addinstance'] = 'Adicionar um bloco Tutoria';
$string['tutoria:myaddinstance'] = 'Adicionar um bloco Tutoria ao Painel';

$string['notconfigured'] = 'Cole a chave de acesso do módulo nas configurações deste bloco para exibir o tutor.';

$string['configtitle'] = 'Título do bloco';
$string['moduletoken'] = 'Chave de acesso do módulo';
$string['moduletoken_help'] = 'A chave de acesso do módulo (module_token) gerada no painel da Tutoria para este módulo. Ela é ao mesmo tempo a identidade e a credencial — não é preciso login separado.';

$string['displaymode'] = 'Exibição';
$string['displaymode_help'] = 'Incorporado mostra o chat dentro do bloco. Balão flutuante mostra um botão no canto da página que abre o tutor sobre o conteúdo — bom quando você quer o tutor disponível em todo lugar sem ocupar espaço na barra lateral.';
$string['displaymode_embed'] = 'Incorporado no bloco';
$string['displaymode_bubble'] = 'Balão de chat flutuante';

$string['height'] = 'Altura (px)';

$string['darkmode'] = 'Tema';
$string['darkmode_auto'] = 'Acompanhar o dispositivo';
$string['darkmode_light'] = 'Claro';
$string['darkmode_dark'] = 'Escuro';

$string['passstudentid'] = 'Identificar o aluno';
$string['passstudentid_label'] = 'Enviar a matrícula do aluno ao tutor';
$string['passstudentid_help'] = 'Quando ativado, o bloco envia o número de identificação do aluno no Moodle (geralmente a matrícula), usando o id interno como alternativa, para que o tutor já preencha a verificação e registre a análise de uso.';

$string['bubbleheader'] = 'Balão de chat';
$string['launcherimage'] = 'Imagem do balão (upload)';
$string['launcherimage_help'] = 'Opcional. Envie uma imagem pequena (por exemplo, um avatar) para usar como o botão flutuante de chat, no lugar do ícone padrão. Mantenha pequena — até 256 KB — pois ela é embutida na página. Envie uma nova imagem para substituir a atual.';
$string['launcherimageurl'] = '…ou URL da imagem';
$string['launcherimageurl_help'] = 'Opcional. Se preferir apenas apontar para uma imagem em vez de enviá-la, cole a URL aqui. Uma imagem enviada tem prioridade sobre a URL.';

$string['openwidget'] = 'Abrir o tutor';
$string['close'] = 'Fechar';

$string['widgetbaseurl'] = 'URL base do widget';
$string['widgetbaseurl_desc'] = 'Onde o widget da Tutoria está hospedado, ex.: https://widget.tutoria.tec.br — o bloco acrescenta a chave de acesso e os parâmetros do aluno.';

$string['privacy:metadata:widget'] = 'O bloco Tutoria incorpora o widget externo da Tutoria. Para atribuir a conversa, a matrícula do aluno (ou o id interno) pode ser enviada ao widget como parâmetro na URL.';
$string['privacy:metadata:widget:studentid'] = 'A matrícula do aluno ou o id interno, enviado para o tutor identificar o aluno.';
