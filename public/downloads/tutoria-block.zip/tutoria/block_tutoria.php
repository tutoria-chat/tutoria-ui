<?php
// This file is part of the Tutoria block for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * The Tutoria block — embeds the Tutoria AI tutor widget in a course, either
 * inline (a compact chat inside the block) or as a floating chat bubble.
 *
 * @package     block_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Tutoria block.
 */
class block_tutoria extends block_base {

    /** @var string Fallback widget base URL used when the admin setting is empty. */
    const DEFAULT_BASE_URL = 'https://tutoria-widget.vercel.app';

    /**
     * Initialise the block.
     */
    public function init() {
        $this->title = get_string('pluginname', 'block_tutoria');
    }

    /**
     * This block has site-wide settings (settings.php).
     *
     * @return bool
     */
    public function has_config() {
        return true;
    }

    /**
     * Allow the block anywhere.
     *
     * @return array
     */
    public function applicable_formats() {
        return ['all' => true];
    }

    /**
     * One instance is enough per page.
     *
     * @return bool
     */
    public function instance_allow_multiple() {
        return false;
    }

    /**
     * Use the admin-chosen title, if any.
     */
    public function specialization() {
        if (!empty($this->config) && !empty($this->config->title)) {
            $this->title = format_string($this->config->title);
        } else {
            $this->title = get_string('defaulttitle', 'block_tutoria');
        }
    }

    /**
     * In bubble mode the visible UI floats over the page, so the sidebar box
     * (and its header) is just noise — hide the header.
     *
     * @return bool
     */
    public function hide_header() {
        return isset($this->config->displaymode) && $this->config->displaymode === 'bubble';
    }

    /**
     * Build the block body.
     *
     * @return stdClass
     */
    public function get_content() {
        global $OUTPUT;

        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = new stdClass();
        $this->content->text = '';
        $this->content->footer = '';

        $token = isset($this->config->moduletoken) ? trim((string) $this->config->moduletoken) : '';
        if ($token === '') {
            // Only nag the teacher who can fix it; students see an empty block.
            if ($this->page->user_is_editing()) {
                $this->content->text = $OUTPUT->notification(
                    get_string('notconfigured', 'block_tutoria'), 'info');
            }
            return $this->content;
        }

        $url = $this->build_widget_url($token);
        $mode = $this->config->displaymode ?? 'embed';

        $this->content->text = ($mode === 'bubble')
            ? $this->render_bubble($url)
            : $this->render_embed($url);

        return $this->content;
    }

    /**
     * Turn an uploaded launcher image into a data URI stored in config, so the
     * bubble button can show it without a pluginfile route. If nothing new was
     * uploaded, keep whatever image was there before.
     *
     * @param stdClass $data
     * @param bool $nolongerused
     */
    public function instance_config_save($data, $nolongerused = false) {
        global $USER;

        if (!empty($data->launcherimage)) {
            $usercontext = context_user::instance($USER->id);
            $fs = get_file_storage();
            $files = $fs->get_area_files(
                $usercontext->id, 'user', 'draft', $data->launcherimage, 'id DESC', false);
            $file = $files ? reset($files) : null;
            if ($file && $file->get_filesize() > 0 && $file->get_filesize() <= 262144) {
                $data->launcherimagedata =
                    'data:' . $file->get_mimetype() . ';base64,' . base64_encode($file->get_content());
            }
        } else if (!empty($this->config->launcherimagedata)) {
            // No new upload — preserve the existing image across edits.
            $data->launcherimagedata = $this->config->launcherimagedata;
        }
        unset($data->launcherimage); // never store the transient draft id

        parent::instance_config_save($data, $nolongerused);
    }

    /**
     * Build the widget URL from the instance config and current user.
     *
     * @param string $token The module access key.
     * @return moodle_url
     */
    protected function build_widget_url(string $token): moodle_url {
        global $USER;

        $configured = trim((string) get_config('block_tutoria', 'widgetbaseurl'));
        $base = rtrim($configured !== '' ? $configured : self::DEFAULT_BASE_URL, '/');

        $params = ['module_token' => $token];

        $dark = $this->config->darkmode ?? 'auto';
        if (in_array($dark, ['auto', 'true', 'false'], true)) {
            $params['dark'] = $dark;
        }

        // Forward the matricula (idnumber) so the tutor knows who is asking;
        // fall back to the internal user id. Opt-out via config.
        $passid = !isset($this->config->passstudentid) || !empty($this->config->passstudentid);
        if ($passid && !isguestuser($USER) && !empty($USER->id)) {
            $studentid = !empty($USER->idnumber) ? $USER->idnumber : (string) $USER->id;
            if ($studentid !== '') {
                $params['student_id'] = $studentid;
            }
        }

        if (!empty($this->config->buttoncolor)) {
            $params['buttonColor'] = ltrim((string) $this->config->buttoncolor, '#');
        }

        return new moodle_url($base . '/', $params);
    }

    /**
     * Inline embed: a compact widget inside the block.
     *
     * @param moodle_url $url
     * @return string
     */
    protected function render_embed(moodle_url $url): string {
        $height = (int) ($this->config->height ?? 520);
        $height = max(320, min(1200, $height));

        return html_writer::tag('iframe', '', [
            'src'            => $url->out(false),
            'title'          => get_string('pluginname', 'block_tutoria'),
            'class'          => 'block_tutoria-embed',
            'style'          => 'width:100%; height:' . $height . 'px; border:0; border-radius:8px;',
            'loading'        => 'lazy',
            'allow'          => 'microphone; clipboard-write; clipboard-read',
            'referrerpolicy' => 'no-referrer-when-downgrade',
        ]);
    }

    /**
     * Floating chat bubble: a launcher fixed to the corner that opens a panel
     * holding the widget. Positioned over the whole page, not just the block.
     *
     * @param moodle_url $url
     * @return string
     */
    protected function render_bubble(moodle_url $url): string {
        $this->page->requires->js(new moodle_url('/blocks/tutoria/bubble.js'));

        $id = 'block_tutoria_' . $this->instance->id;
        $panelid = $id . '_panel';
        $title = !empty($this->config->title) ? format_string($this->config->title)
            : get_string('defaulttitle', 'block_tutoria');

        // Chat icon (inline SVG so no asset is needed).
        $icon = '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" '
            . 'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
            . '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>';
        $closeicon = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" '
            . 'stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>';

        $iframe = html_writer::tag('iframe', '', [
            'src'            => $url->out(false),
            'title'          => get_string('pluginname', 'block_tutoria'),
            'class'          => 'block_tutoria-bubble-iframe',
            'loading'        => 'lazy',
            'allow'          => 'microphone; clipboard-write; clipboard-read',
            'referrerpolicy' => 'no-referrer-when-downgrade',
        ]);

        $panel = html_writer::div(
            html_writer::div(
                html_writer::tag('span', $title, ['class' => 'block_tutoria-bubble-title']) .
                html_writer::tag('button', $closeicon, [
                    'type' => 'button',
                    'class' => 'block_tutoria-bubble-close',
                    'data-tutoria-close' => '1',
                    'aria-label' => get_string('close', 'block_tutoria'),
                ]),
                'block_tutoria-bubble-head'
            ) . $iframe,
            'block_tutoria-bubble-panel',
            ['id' => $panelid, 'hidden' => 'hidden']
        );

        // Custom launcher image: an uploaded file (stored as a data URI) wins
        // over a pasted URL; otherwise fall back to the default chat icon.
        $imgsrc = '';
        if (!empty($this->config->launcherimagedata)) {
            $imgsrc = $this->config->launcherimagedata;
        } else if (!empty($this->config->launcherimageurl)) {
            $imgsrc = $this->config->launcherimageurl;
        }
        $launchinner = $imgsrc
            ? html_writer::empty_tag('img', [
                'src' => $imgsrc,
                'alt' => '',
                'class' => 'block_tutoria-bubble-img',
            ])
            : $icon;

        $launch = html_writer::tag('button', $launchinner, [
            'type' => 'button',
            'class' => 'block_tutoria-bubble-btn' . ($imgsrc ? ' has-img' : ''),
            'data-tutoria-toggle' => '1',
            'aria-expanded' => 'false',
            'aria-controls' => $panelid,
            'aria-label' => get_string('openwidget', 'block_tutoria'),
        ]);

        return html_writer::div($launch . $panel, 'block_tutoria-bubble', ['id' => $id]);
    }
}
