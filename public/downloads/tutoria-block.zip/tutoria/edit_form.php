<?php
// This file is part of the Tutoria block for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Per-instance configuration form for block_tutoria.
 *
 * @package     block_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Configuration form shown when a teacher configures the block.
 */
class block_tutoria_edit_form extends block_edit_form {

    /**
     * Form fields (prefixed config_ so Moodle stores them in the instance config).
     *
     * @param MoodleQuickForm $mform
     */
    protected function specific_definition($mform) {
        $mform->addElement('header', 'configheader', get_string('blocksettings', 'block'));

        $mform->addElement('text', 'config_title', get_string('configtitle', 'block_tutoria'));
        $mform->setType('config_title', PARAM_TEXT);
        $mform->setDefault('config_title', get_string('defaulttitle', 'block_tutoria'));

        $mform->addElement('passwordunmask', 'config_moduletoken',
            get_string('moduletoken', 'block_tutoria'), ['size' => 72]);
        // base64url keys can contain (and start with) "-" and "_"; PARAM_ALPHANUM
        // would strip those and corrupt the key.
        $mform->setType('config_moduletoken', PARAM_ALPHANUMEXT);
        $mform->addRule('config_moduletoken', null, 'required', null, 'client');
        $mform->addHelpButton('config_moduletoken', 'moduletoken', 'block_tutoria');

        $modes = [
            'embed'  => get_string('displaymode_embed', 'block_tutoria'),
            'bubble' => get_string('displaymode_bubble', 'block_tutoria'),
        ];
        $mform->addElement('select', 'config_displaymode',
            get_string('displaymode', 'block_tutoria'), $modes);
        $mform->setDefault('config_displaymode', 'embed');
        $mform->addHelpButton('config_displaymode', 'displaymode', 'block_tutoria');

        $mform->addElement('text', 'config_height', get_string('height', 'block_tutoria'), ['size' => 6]);
        $mform->setType('config_height', PARAM_INT);
        $mform->setDefault('config_height', 520);
        $mform->hideIf('config_height', 'config_displaymode', 'eq', 'bubble');

        $darkmodes = [
            'auto'  => get_string('darkmode_auto', 'block_tutoria'),
            'false' => get_string('darkmode_light', 'block_tutoria'),
            'true'  => get_string('darkmode_dark', 'block_tutoria'),
        ];
        $mform->addElement('select', 'config_darkmode', get_string('darkmode', 'block_tutoria'), $darkmodes);
        $mform->setDefault('config_darkmode', 'auto');

        $mform->addElement('advcheckbox', 'config_passstudentid',
            get_string('passstudentid', 'block_tutoria'), get_string('passstudentid_label', 'block_tutoria'));
        $mform->setDefault('config_passstudentid', 1);
        $mform->addHelpButton('config_passstudentid', 'passstudentid', 'block_tutoria');
    }
}
