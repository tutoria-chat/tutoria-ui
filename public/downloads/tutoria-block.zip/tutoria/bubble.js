// Tutoria block — floating chat-bubble toggle.
//
// Plain, dependency-free JS (no build step). Uses event delegation on the
// document so it works no matter when the script loads relative to the block
// markup. Opens/closes the widget panel; Escape closes it.

(function () {
    'use strict';

    if (window.__blockTutoriaBubbleInit) {
        return;
    }
    window.__blockTutoriaBubbleInit = true;

    function rootOf(el) {
        return el.closest ? el.closest('.block_tutoria-bubble') : null;
    }

    function setState(root, isOpen) {
        var btn = root.querySelector('[data-tutoria-toggle]');
        var panel = root.querySelector('.block_tutoria-bubble-panel');
        if (!btn || !panel) {
            return;
        }
        panel.hidden = !isOpen;
        btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        root.classList.toggle('is-open', isOpen);
        if (!isOpen) {
            try {
                btn.focus();
            } catch (e) {
                // Ignore focus errors.
            }
        }
    }

    document.addEventListener('click', function (e) {
        if (!e.target || !e.target.closest) {
            return;
        }
        var toggle = e.target.closest('[data-tutoria-toggle]');
        if (toggle) {
            var root = rootOf(toggle);
            if (root) {
                var panel = root.querySelector('.block_tutoria-bubble-panel');
                setState(root, panel ? panel.hidden : true);
            }
            return;
        }
        var closeBtn = e.target.closest('[data-tutoria-close]');
        if (closeBtn) {
            var croot = rootOf(closeBtn);
            if (croot) {
                setState(croot, false);
            }
        }
    });

    document.addEventListener('keydown', function (e) {
        if (e.key !== 'Escape') {
            return;
        }
        var open = document.querySelector('.block_tutoria-bubble.is-open');
        if (open) {
            setState(open, false);
        }
    });
})();
