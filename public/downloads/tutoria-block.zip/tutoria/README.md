# Tutoria block (`block_tutoria`)

A Moodle **block** that puts the Tutoria AI tutor widget in a course — either
**embedded** inside the block, or as a **floating chat bubble** in the page
corner. Companion to the `mod_tutoria` activity (which shows the tutor on its
own activity page); this is for when you want the tutor available in the
sidebar / across the page instead.

- **Moodle:** 4.1 – 5.2. Installs to `blocks/tutoria/`, component `block_tutoria`.
- **Renders server-side**, so it survives Moodle's HTML sanitiser (unlike an
  iframe pasted into an HTML block by a non-trusted user).

## Activity or block?

Two ways to bring the tutor into Moodle — use either, or both:

| | **Block** (`block_tutoria`, this plugin) | **Activity** (`mod_tutoria`) |
| --- | --- | --- |
| Lives in | The sidebar, or a floating bubble | The course content, as an activity |
| Opens | Always visible in the sidebar, or a corner bubble on every course page | Its own page when the student clicks it |
| Best for | Keeping the tutor always at hand while students browse | A dedicated per-module Q&A that shows in activity reports |
| Access/completion logging | No (it's a visual shortcut) | Yes (it's a real activity) |

Use this **block** (floating-bubble mode) to keep the tutor one click away
anywhere in the course; use the **activity** for a clear "Module X tutor" inside
the content that also appears in activity reports. Both render server-side and
use the module access key the same way, so both work in courses that strip
iframes from HTML blocks.

## Install

1. *Site administration → Plugins → Install plugins* and upload the ZIP
   (root folder `tutoria/`), or copy the folder to `blocks/tutoria/`.
2. Complete the upgrade.
3. (Optional) *Site administration → Plugins → Blocks → Tutoria* → set the
   **Widget base URL** (e.g. `https://widget.tutoria.tec.br`).

## Use

1. In a course, turn editing on → **Add a block → Tutoria**.
2. Configure the block:
   - **Module access key** — the `module_token` from the Tutoria dashboard.
   - **Display** — *Embedded in the block* or *Floating chat bubble*.
   - Height (embed only), theme, accent colour, and whether to send the
     student's ID number (matrícula) to the tutor.

## Display modes

- **Embedded** — a compact chat inside the block. Best in a wide block region.
- **Floating bubble** — a launcher fixed to the corner that opens the tutor
  over the page. The block header is hidden; the bubble floats via
  `position: fixed`, so the tutor is reachable from anywhere the block is shown.

## Notes

- Microphone (voice dictation) is allowed on the iframe; the widget's read-aloud
  needs no permission.
- The block stores no personal data in Moodle; it only forwards the student's ID
  number to the widget as a URL parameter (see the privacy provider).
