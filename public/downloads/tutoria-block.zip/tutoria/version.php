<?php
// This file is part of the Tutoria block for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Plugin version and metadata for block_tutoria.
 *
 * @package     block_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'block_tutoria';
$plugin->version   = 2026090803;       // YYYYMMDDXX.
$plugin->requires  = 2022112800;       // Moodle 4.1 (LTS) or later.
$plugin->supported = [401, 502];       // Tested on Moodle 4.1 through 5.2.
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.0.2';
