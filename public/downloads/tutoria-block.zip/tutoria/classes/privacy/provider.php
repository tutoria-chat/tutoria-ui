<?php
// This file is part of the Tutoria block for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version. See <https://www.gnu.org/licenses/>.

/**
 * Privacy metadata for block_tutoria.
 *
 * The block stores no personal data in Moodle. It embeds the external Tutoria
 * widget and may forward the student's ID number (matrícula) to it as a URL
 * parameter so the tutor can identify the student.
 *
 * @package     block_tutoria
 * @copyright   2026 Tutoria
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_tutoria\privacy;

use core_privacy\local\metadata\collection;

defined('MOODLE_INTERNAL') || die();

/**
 * Declares the external data sent to the Tutoria widget.
 */
class provider implements \core_privacy\local\metadata\provider {

    /**
     * Describe the external transfer.
     *
     * @param collection $collection
     * @return collection
     */
    public static function get_metadata(collection $collection): collection {
        $collection->add_external_location_link('tutoria_widget', [
            'studentid' => 'privacy:metadata:widget:studentid',
        ], 'privacy:metadata:widget');

        return $collection;
    }
}
